from pathlib import Path
import shutil,xml.etree.ElementTree as E
T=Path('/workspace/hunter-fix-tools');OLD=Path('/workspace/deliverables164/zzzz_revolver_samson');P=Path('/workspace/deliverables165/zzzz_revolver_samson')
for name in ['compat','compat_eid','compat_items','rules','charge_ui','sword']:
 shutil.copy2(T/f'tainted_hunter_{name}165.lua',P/f'tainted_hunter_{name}.lua')
s=(OLD/'main.lua').read_text().replace('-- v1.64 - reliable hit groups and native-effect compatibility fixes','-- v1.65 - native Chocolate replacement, complete sword sweep and live projectile groups',1)
(P/'main.lua').write_text(s)
s=(OLD/'tainted_hunter_combat.lua').read_text().replace('        if not data.hunterKnifeApplied155 then return end','        if not data.hunterKnifeApplied155 or tear:IsDead()then return end',1)
(P/'tainted_hunter_combat.lua').write_text(s)
t=E.parse(OLD/'content/items.xml');E.SubElement(t.getroot(),'passive',{'name':'Hunter Chocolate Milk','description':'Rate-dependent knife damage','gfx':'collectibles_069_chocolatemilk.png','quality':'3','hidden':'true'});t.write(P/'content/items.xml',encoding='utf-8',xml_declaration=True)
t=E.parse(OLD/'metadata.xml');t.getroot().find('version').text='1.65';t.getroot().find('description').text='v1.65: native Chocolate Milk replaced with a charge-free passive; dead/live projectile-group cleanup restores native probabilistic Dead Eye misses; complete360 sword sweep; Trisagion native light hit16x; C Section damage one quarter of v1.64.';t.write(P/'metadata.xml',encoding='utf-8',xml_declaration=True)
print('Built v1.65')
