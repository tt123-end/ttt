from pathlib import Path
import ctypes,json,xml.etree.ElementTree as E
D=Path('/workspace/deliverables165');P=D/'zzzz_revolver_samson';OLD=Path('/workspace/deliverables162/zzzz_revolver_samson');T=Path('/workspace/hunter-fix-tools')
lib=ctypes.CDLL('liblua5.4.so.0');lib.luaL_newstate.restype=ctypes.c_void_p
lib.luaL_loadbufferx.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_size_t,ctypes.c_char_p,ctypes.c_char_p]
lib.lua_tolstring.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_void_p];lib.lua_tolstring.restype=ctypes.c_char_p
lib.lua_close.argtypes=[ctypes.c_void_p];lib.luaL_openlibs.argtypes=[ctypes.c_void_p]
lib.lua_pcallk.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_longlong,ctypes.c_void_p]
def lua(source,label,execute=False,expected_failure=None):
 data=source.encode();st=lib.luaL_newstate();lib.luaL_openlibs(st)
 assert lib.luaL_loadbufferx(st,data,len(data),label.encode(),None)==0,(label,lib.lua_tolstring(st,-1,None))
 if execute:
  result=lib.lua_pcallk(st,0,0,0,0,None)
  error=lib.lua_tolstring(st,-1,None)if result else None
  if expected_failure:assert result and expected_failure.encode()in error,(label,error)
  else:assert result==0,(label,error)
 lib.lua_close(st)
prefix='local MOD_ROOT='+json.dumps(str(P))+'\n'
for p in P.glob('*.lua'):lua(p.read_text(),p.name)
for p in list(P.rglob('*.xml'))+list(P.rglob('*.anm2')):E.parse(p)
lua(prefix+(T/'test_compat165.lua').read_text(),'integrated_compatibility165',True)
oldFixture=(T/'test_compat163.lua').read_text()
removeStart=oldFixture.index(' function e:Remove()');removeEnd=oldFixture.index('\n function e:TakeDamage',removeStart)
newFixture=(T/'test_compat165.lua').read_text()
mockStart=newFixture.index(' function e:Remove()');mockEnd=newFixture.index('\n function e:TakeDamage',mockStart)
oldFixture=oldFixture[:removeStart]+newFixture[mockStart:mockEnd]+oldFixture[removeEnd:]
oldPrefix='local MOD_ROOT="/workspace/deliverables163/zzzz_revolver_samson"\n'
tail=(T/'test_deadeye164_tail.lua').read_text()
lua(oldPrefix+oldFixture+'\n'+tail,'old_v163_rejected_tear_failure',True,'Rejected native tear must never reset Dead Eye')
second=tail[tail.index('local p=player({[373]=1});local root=nativeShot(p)'):]
lua(oldPrefix+oldFixture+'\n'+second,'old_v163_target_hp_restore_failure',True,'A hit must survive a stationary target restoring its HP')
lightRegression='''
local p=player({[533]=1});p.nativeFlags=TearFlags.TEAR_LASERSHOT
local root=nativeShot(p);local target=entity(10);target.HitPoints=1000
local light=entity(7,5,p);light.Parent=root;light.CollisionDamage=p.Damage/3
target:TakeDamage(light.CollisionDamage,8,EntityRef(light),0)
assert(math.abs(target.HitPoints-(1000-p.Damage/3*4))<1e-6,'Actual Trisagion light hit must be multiplied4')
'''
lua(oldPrefix+oldFixture+'\n'+lightRegression,'old_v163_light_laser_failure',True,'Actual Trisagion light hit must be multiplied4')
print('v163 confirmed failing both targeted Dead Eye regressions; v164 passes both')
v164prefix='local MOD_ROOT="/workspace/deliverables164/zzzz_revolver_samson"\n'
v164fixture=(T/'test_compat164.lua').read_text()
lua(v164prefix+v164fixture+'\n'+(T/'test_old165_regressions.lua').read_text(),'old_v164_dead_without_remove_failure',True,'Dead existing tear must request native miss reset')
leak="""
local p=player({[69]=1});p.input=Vector(1,0);tick(p)
local leak=p:FireTear(p.Position,Vector(16,0),true,false,false,p,1)
assert(leak.removed,'Native false-streak tap tear may not bypass the reload')
"""
lua(v164prefix+v164fixture+'\n'+leak,'old_v164_false_streak_chocolate_failure',True,'Native false-streak tap tear may not bypass the reload')
print('v164 confirmed failures: dead-without-remove miss and native Chocolate false-streak bypass; v165 passes both')
dummy='''
local p=player({[533]=1});p.nativeFlags=TearFlags.TEAR_LASERSHOT;local root=nativeShot(p)
local target=entity(10);target.HitPoints=1000;local recorded={}
mod:AddCallback(11,function(_,entity,amount)if entity==target then recorded[#recorded+1]=amount;return false end end)
target:TakeDamage(1,8,EntityRef(root),0)
assert(#recorded==1 and recorded[1]==4,'Dummy must receive the scaled native light hit before cancelling it')
'''
lua(v164prefix+v164fixture+'\n'+dummy,'old_v164_late_damage_observer_failure',True,'Dummy must receive the scaled native light hit before cancelling it')
statsRoot='/workspace/reference-stats-plus154/stats-plus_2729900570'
stats=(T/'test_stats161.lua').read_text()
stats+='''
mod.HunterCompat163={rules={blastCombo=function(p)return p:HasCollectible(52)and p:HasCollectible(149)end},flatDamage=function()return 1.5 end}
p.items[562]=nil;p.items[52]=1;p.items[149]=1;p.a=5;p.b=20;p.tearsBonus=0;settle(p)
approx(p.data.hunterTears161.capRate,.6);approx(p.Damage,6)
print('v163 forced-cap0.6 and +1.5-before-x1.2 damage passed')
'''
lua(prefix+'local OLD_ROOT="/workspace/deliverables160/zzzz_revolver_samson"\nlocal STATS_ROOT='+json.dumps(statsRoot)+'\n'+stats,'uploaded_stats_api_and_numeric_regression',True)
damage=(T/'test_red_damage157.lua').read_text()
damage=damage.replace(' function p:GetMaxHearts()return self.max end',' function p:GetMaxHearts()return self.max end\n function p:GetBoneHearts()return self.bone end',1)
damage=damage.replace('self.red=math.min(self.red,self.max)','self.red=math.min(self.red,self.max+self.bone*2)',1)
damage=damage.replace('local p=player(20,2,4);p.bone=1;p:TakeDamage(5,0,enemy,30);assert(p.red==1 and p.broken==1)',"local p=player(20,2,0);p.max=0;p.bone=1;p:TakeDamage(1,0,enemy,30);assert(p.red==1 and p.broken==0)",1)
lua(prefix+damage+'\n'+(T/'test_bone_containers162_tail.lua').read_text(),'red_damage_and_bone_regression',True)
eid=(T/'test_eid158.lua').read_text().replace('800%%','400%%')
eidprefix=prefix+'local ACTUAL_API='+json.dumps(str(T/'eid_actual_api158.lua'))+'\nlocal TEXT_ARTIFACT='+json.dumps(str(D/'eid_character_text_v165.txt'))+'\n'
lua(eidprefix+eid,'uploaded_character_eid_api',True)
lua(eidprefix+'local ACTUAL_ITEM_API='+json.dumps(str(T/'eid_item_api163.lua'))+'\n'+(T/'test_compat_eid165.lua').read_text(),'uploaded_item_eid_api',True)
eidItem=(T/'test_compat_eid165.lua').read_text()
eidItem+='''
p.kind=20;p.items={};EID.Config.Language='zh_cn'
local function text(id)return modifier.callback({ObjType=5,ObjVariant=100,ObjSubType=id}).Description end
assert(text(52):find('200%%')and text(52):find('不使用炸弹弹体'))
assert(text(149):find('主刀和爆炸各100%%'))
assert(text(579):find('实际攻击时')and text(579):find('360度'))
assert(text(533):find('16倍原生伤害'))
assert(text(678):find('25%%')and text(678):find('子实体不重复削减'))
assert(text(69):find('完全移除原版蓄力/点按攻击'))
EID.Config.Language='en_us';assert(text(52):find('200%%')and text(579):find('actual attack'))
print('v164 actual EID feedback wording and numeric overrides passed in both languages')
'''
lua(eidprefix+'local ACTUAL_ITEM_API='+json.dumps(str(T/'eid_item_api163.lua'))+'\n'+eidItem,'updated_item_eid_values',True)
preserved=0
for p in OLD.rglob('*'):
 if p.is_file()and p.suffix in {'.png','.anm2'}:
  assert p.read_bytes()==(P/p.relative_to(OLD)).read_bytes(),p
  preserved+=1
assert (OLD/'tainted_hunter_damage.lua').read_bytes()==(P/'tainted_hunter_damage.lua').read_bytes()
previous=Path('/workspace/deliverables163/zzzz_revolver_samson')
changed={'main.lua','metadata.xml','tainted_hunter_combat.lua','tainted_hunter_compat.lua','tainted_hunter_compat_eid.lua','tainted_hunter_rules.lua','tainted_hunter_charge_ui.lua','tainted_hunter_compat_items.lua','items.xml'}
for p in previous.rglob('*'):
 if p.is_file()and p.name not in changed:assert p.read_bytes()==(P/p.relative_to(previous)).read_bytes(),p
main164=(P/'main.lua').read_text().replace('\ninclude("tainted_hunter_charge_ui")(mod, TAINTED_PLAYER_TYPE, mod.HunterCompat163.rules)','',1)
assert main164.splitlines()[1:]==(previous/'main.lua').read_text().splitlines()[1:]
oldMain=(OLD/'main.lua').read_text();newMain=(P/'main.lua').read_text()
assert oldMain.split('local taintedStats = include')[0].splitlines()[1:]==newMain.split('mod.HunterCompat163 = include')[0].splitlines()[1:]
report={'version':'1.65','workbook_decision_rows':1497,'custom_decision_rows':39,'lua_syntax_files':len(list(P.glob('*.lua'))),'xml_anm2':'PASS','integrated_compatibility':'PASS: deterministic engine-contract model, not game runtime','stats_plus':'PASS: uploaded cap function/display, validators and multiplier middleware; baseline210 monotonic cases; explicit Dr Fetus+Ipecac cap0.6','damage':'PASS: prior red-heart/payment/shield cases plus dedicated bone-container regressions; damage module byte-identical to v162','eid':'PASS: uploaded character API and item modifier/collectible registration API;25 localized item overrides','visual_assets_preserved':preserved,'game_runtime':'NOT RUN; no Isaac executable available','known_limits':['Rock Bottom: no safe exact readonly native-cap API in vanilla; sampling disabled and last safe cap reference retained, Stats+ may show UNKNOWN','Godhead aura attribution, native fetal knives/spin collision, active/auxiliary source timing and complex combinations need in-game validation','Default rows generally delegate native behavior through shared adapters; this is not721 individually game-tested items']}
report['targeted_regressions']={'v164':'Confirmed failures on dead-but-existing tear group completion and untagged native false-streak Chocolate shots','v165':'PASS: native probabilistic-clear delegation once/group, dead-without-remove and expired lifecycle, delayed descendants and fire/poop/wall; Chocolate inventory replacement,190 tap/hold attempts, temporary-effect/error/type cleanup; C Section actual damage quarter on root/child/knife/laser once;360-degree swept collision on four directions and no outside hit; actual light hit16x with direct/player/child source, DOT and aura isolation'}
report['values']={'Trisagion':'16*native actual light hit (v164 multiplier times4 again)','C_Section':'0.25*v164 actual primary/descendant hit; no repeated carrier+child quarter','Spirit_Sword':'Scripted360-degree sweep with native sword art; spin damage8*panel+10 and reflection4*panel+4; full-health beam retained','Chocolate_Milk':'Native69 replaced by hidden passive; same rate/cap curve; normal chamber/reload remains','Dead_Eye':'Native ClearDeadEyeCharge called once only after complete all-miss group; native probability is not replaced by guaranteed clear'}
report['native_charge_UI']='Chocolate replacement has no native charge capability and no longer needs the global charge-UI switch; other instant native charged weapons retain v164 scoped option behavior.'
report['sword_render_limit']='Vanilla has no public native spin-state setter. Sword360 motion/collision and projectile reflection are script-driven, native sword art is independently rendered; exact appearance requires in-game verification.'
report['game_runtime']='NOT RUN. The three uploaded videos were reviewed; targeted logic/interface checks are not game-runtime validation.'
report['targeted_regressions']['v164']+='; default-priority cancelling dummy can stop LATE light scaling before it runs'
report['targeted_regressions']['v165']+='; early scaling precedes a cancelling dummy and it sees exactly one transformed damage event'
(D/'validation_v165.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('Integrated checks completed')
