-- The old tests only called Remove(). Native death can precede removal forever
-- when an Idle-only custom sprite keeps overriding the native death animation.
local p=player({[373]=1});local t=nativeShot(p);t.dead=true
assert(t:Exists());tick(p,3)
assert(p.clears==1,'Dead-but-existing tear must finish the miss group without a Remove callback')
local p=player({[373]=1});local t=nativeShot(p)
t.dead=true;t.sprite:Play('Death');call(40,t);assert(t.sprite:GetAnimation()=='Death')
tick(p,2);call(40,t);assert(t.removed,'Dead custom knives must be cleaned up')
-- Keep a delayed child alive after its parent dies: no premature reset.
local p=player({[373]=1,[104]=1});local root=nativeShot(p);root.dead=true;tick(p)
local child=p:FireTear(root.Position,Vector(4,0),false,false,false,root,.5)
tick(p,3);assert(p.clears==0)
child.dead=true;tick(p,3);assert(p.clears==1)
-- Request the original native probabilistic clear, exactly once per missed volley.
local p=player({[373]=1});p.bonus=1;p.nativeRequests=0
function p:ClearDeadEyeCharge()
 self.nativeRequests=self.nativeRequests+1
 -- Stand-in for native RNG, not a reimplementation in production code.
 if self.nativeRequests==3 then self.bonus=0 end
end
for i=1,3 do
 local t=nativeShot(p);t.dead=true;tick(p,63)
 assert(p.nativeRequests==i);assert(p.bonus==(i<3 and 1 or 0))
end
local t=nativeShot(p);local target=entity(10);target.HitPoints=1000
call(42,t,target);t.dead=true;tick(p,63);assert(p.nativeRequests==3)
-- Fireplaces count as hits even when IsVulnerableEnemy excludes environmental NPCs.
local p=player({[373]=1});local t=nativeShot(p);local fire=entity(33);fire.HitPoints=10;fire.invulnerable=true
call(42,t,fire);t.dead=true;tick(p,3);assert(p.clears==0)
-- Poop collision counts, a plain wall collision does not.
local getRoom=game.GetRoom;local grid
function game:GetRoom()
 local room=getRoom(self)
 function room:GetGridEntityFromPos(pos)if grid and(pos-grid.Position):Length()<24 then return grid end end
 return room
end
local function makeGrid(kind)return{State=0,Position=Vector(0,0),GetType=function()return kind end}end
local p=player({[373]=1});local t=nativeShot(p);grid=makeGrid(14);t.grid=true
call(40,t);t.dead=true;tick(p,3);assert(p.clears==0)
local p=player({[373]=1});local t=nativeShot(p);grid=makeGrid(15);t.grid=true
call(40,t);t.dead=true;tick(p,3);assert(p.clears==1)
grid=nil;game.GetRoom=getRoom
-- Native Chocolate exists only as a replacement passive after update.
local p=player({[69]=2});local reflags=0
function p:AddCacheFlags(flags)reflags=reflags|flags end
p.input=Vector(1,0);tick(p)
assert(reflags&256~=0,'Replacing native Chocolate must rebuild the native weapon cache')
assert(p.items[69]==0 and p.items[9002]==2 and R.count(p,69)==2)
local baseline=latest(2,p).CollisionDamage
local accepted=1
for i=1,190 do
 p.input=(i%2==0)and Vector(1,0)or Vector(0,0)
 local before=mainCount(p);tick(p)
 if mainCount(p)>before then accepted=accepted+1 end
 local leaked=p:FireTear(p.Position,Vector(16,0),true,false,false,p,20)
 assert(leaked.removed,'Untagged tap/charge tear may not bypass scripted reload, even with native streak flag false')
end
assert(accepted<=4,'Rapid key taps may not accelerate the chamber')
p.input=Vector(0,0);tick(p,63);p.input=Vector(1,0);tick(p)
approx(latest(2,p).CollisionDamage,baseline)
p.kind=10;tick(p);assert(p.items[9002]==0 and p.items[69]==2)
p.kind=20;tick(p);assert(p.items[9002]==2 and p.items[69]==0)
-- Temporary native Chocolate is suspended while creating the real shot and restored even on errors.
local p=player({});p.effects[69]=1;p.failFire=true;p.input=Vector(1,0)
local ok=pcall(tick,p);assert(not ok and p.effects[69]==1 and p.effects[9002]==0)
-- Explicit numerical change: C Section x0.25 once, with knife-fetus flags unchanged.
local p=player({[678]=1});p.Damage=10;p.input=Vector(1,0);tick(p);p.input=Vector(0,0)
local root=latest(2,p);approx(root.CollisionDamage,40);assert(root:HasTearFlags(TearFlags.TEAR_FETUS_KNIFE))
local child=p:FireTear(root.Position,Vector(5,0),false,false,false,root,.5)
child.CollisionDamage=root.CollisionDamage*.5;call(40,child);approx(child.CollisionDamage,20)
local knife=entity(8,0,child);knife.CollisionDamage=2;call(45,knife);approx(knife.CollisionDamage,2)
local target=entity(10);target.HitPoints=1000
 target:TakeDamage(root.CollisionDamage,0,EntityRef(root),0);approx(target.HitPoints,990)
 target:TakeDamage(child.CollisionDamage,0,EntityRef(child),0);approx(target.HitPoints,985)
 target:TakeDamage(knife.CollisionDamage,0,EntityRef(knife),0);approx(target.HitPoints,984.5)
-- Native child lasers may calculate their own damage instead of copying a reduced carrier.
local laser=entity(7,1,p);laser.Parent=root;laser.CollisionDamage=8
 target:TakeDamage(8,DamageFlag.DAMAGE_LASER,EntityRef(laser),0);approx(target.HitPoints,982.5)
-- Full physical sweep: enemies in front/behind/left/right are all hit once,
-- while a stationary target outside the radius is unaffected.
EntityPartition={ENEMY=1};local targets={};local originalFind=Isaac.FindInRadius
function Isaac.FindInRadius()return targets end
local p=player({[579]=1,[619]=1});p.Damage=10
for _,angle in ipairs({0,90,180,270})do
 local npc=entity(10);npc.HitPoints=1000;npc.Position=Vector.FromAngle(angle)*50;targets[#targets+1]=npc
end
local outside=entity(10);outside.HitPoints=1000;outside.Position=Vector(200,0);targets[#targets+1]=outside
local sword=C._testing.sword;local state=sword.attack(p,Vector(1,0))
assert(state.knife.Visible==false and state.knife.CollisionDamage==0 and state.knife.EntityCollisionClass==0)
for age=0,12 do
 frame=state.start+age;sword._update();assert(state.progress>=0 and state.progress<=1)
 call(2)
end
approx(state.progress,1)
for i=1,4 do approx(targets[i].HitPoints,910)end
approx(outside.HitPoints,1000)
assert(state.knife.removed and #sword.active==0)
Isaac.FindInRadius=originalFind
-- Some native light hits name the player as their source. Nearby carrier
-- attribution still applies the new16x, without requiring a laser variant.
local p=player({[533]=1});p.nativeFlags=TearFlags.TEAR_LASERSHOT;local root=nativeShot(p)
local npc=entity(10);npc.HitPoints=1000
npc:TakeDamage(1,DamageFlag.DAMAGE_LASER,EntityRef(p),0);approx(npc.HitPoints,984)
print('v165 feedback regressions passed: dead-without-remove/native probability calls, late descendants, fire/poop/wall, native Chocolate removal +190 taps/error/identity, C Section quarter once, actual360 sweep collision and light player-source16x')

local output
Isaac.ConsoleOutput=function(value)output=value end
call(22,'hunterdiag')
assert(output and output:find('native_miss_requests')and output:find('light: incoming=1.0000 applied=16.0000'))
-- A training dummy can record and cancel damage at ordinary priority.
-- Damage scaling must run before it, and the dummy must see one scaled hit.
local p=player({[533]=1});p.nativeFlags=TearFlags.TEAR_LASERSHOT;local root=nativeShot(p)
local dummy=entity(10);dummy.HitPoints=1000;local recorded={}
mod:AddCallback(11,function(_,entity,amount)
 if entity==dummy then recorded[#recorded+1]=amount;return false end
end)
dummy:TakeDamage(1,DamageFlag.DAMAGE_LASER,EntityRef(root),0)
assert(#recorded==1);approx(recorded[1],16);approx(dummy.HitPoints,1000)
local p=player({[678]=1});p.input=Vector(1,0);tick(p);p.input=Vector(0,0)
local root=latest(2,p);recorded={}
dummy:TakeDamage(8,0,EntityRef(root),0)
assert(#recorded==1);approx(recorded[1],2)
print('v165 early damage transform passed: cancelling default-priority dummy observes a single16x light hit or quarter fetal hit')
