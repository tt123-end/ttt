from pathlib import Path
import zipfile,hashlib,shutil,json
from openpyxl import load_workbook
from openpyxl.styles import Alignment
T=Path('/workspace/hunter-fix-tools');D=Path('/workspace/deliverables169');P=D/'zzzz_revolver_samson'
readme='''# 猎手v1.69：仅调整英灵剑触发与三圣颂伤害

本说明优先于包内历史版本说明。用户环境为忏悔+＋REPENTOGON。本轮范围按要求限定为英灵剑和三圣颂，其余机制沿用v1.68。

## 英灵剑

收到的v1.68诊断是“native weapon released, but no spin callback was observed”。此信息只能说明没有观察到旋斩回调，不能证明原生武器真的完成了释放。检查旧代码发现准备蓄力后就在POST_PLAYER_UPDATE阶段把蓄力清零，并且在该阶段结束输入覆盖与发射窗口；如果原生输入缓存或武器处理发生在窗口之外，释放便可能没有被原生逻辑正确读取。另外，旧逻辑等待新的FireSword回调，没有覆盖已有主剑实体切入Spin状态的情况。

v1.69把朝向/按下/松开请求保留到完整输入与武器更新结束，在POST_UPDATE推进阶段、恢复射击限制。准备蓄力后不再提前清零，直到真实旋斩出现或请求取消才清理。保留原生主剑的初始化实体，检查真实GetIsSpinAttack状态，既接收FireSword回调，也识别已有剑实体进入Spin，不要求每次释放都重新生成实体。准备阶段的普通挥剑实体保持隐藏并阻止伤害，原生Spin一旦出现便恢复原生显示与碰撞；不会额外造成一次普通挥剑。仍由游戏处理旋斩素材、动画、碰撞和伤害，不复制贴图、不手动Play(Spin)、不设置伪旋斩状态、不另写范围伤害。

这些改动经过接口与时序模型检查，未在本机运行Isaac。输入先缓存、武器在玩家POST更新之后才处理、主剑复用是本轮覆盖的兼容边界，不能把模型结果当成游戏原生回调顺序或旋斩已成功的实测证据。

hunterdiag中的sword会显示原生Spin是否被观察到，及arm_calls、release_calls、input_polls、sword_callbacks计数。若超时，会报告具体阶段和上述计数；若观察到真实Spin，会报告“native spin observed”与原生动画名称，不再仅凭脚本推进阶段宣布已释放。

## 三圣颂

实际命中伤害倍率从v1.68的原版8倍降到4倍，伤害再减半，EID中英文同步。沿用已经确认生效的光束碰撞/ExtraSource伤害链，不改变光束样式、单段比例、命中频率或角色面板。无其他增伤时，原生输入1.4的单段由11.2改为5.6；其他既有道具额外倍率按原规则另算。

## 保持不变

诅咒之眼及自伤/刺门转场传送代码、科技400%主激光、死亡之眼分组概率判定、专用巧克力牛奶、剖腹产伤害削减、生命/碎心/骨心规则、初始数值、Stats+、换弹UI、人物贴图和动画资源保持v1.68。验证不只检查这些测试，还逐文件比对独立模块，并对完整兼容代码做排除本轮剑保护/三圣颂倍率/版本文本后的逐字对比。

## 安装与测试

完全退出游戏，备份并移出旧zzzz_revolver_samson，将本ZIP内同名文件夹完整放入mods，只启用一份猎手。通过匹配忏悔+的REPENTOGON Launcher启动，控制台hunterdiag应显示[Hunter v1.69] REPENTOGON=true。不要求重新创建长期存档，先在测试局验证。

本地通过Lua5.4语法、XML/ANM2解析、原有Stats+/EID上传接口、兼容和生命判定模型，以及本轮完整输入/武器更新、保留蓄力、复用主剑、准备动作无伤害、原生Spin恢复碰撞、弹药/换弹/输入/射击限制恢复的检查。v1.68在提前清零蓄力及输入缓存/较晚武器处理的对应测试中失败，新版通过。没有Isaac运行环境，原版旋斩实际表现仍须游戏确认。

如仍无挥斩，提供v1.69的完整sword一行即可继续区分是否读取了输入、是否执行了武器更新、是否创建或复用了剑实体。复杂武器优先级与此前磐石等限制不在本次范围。
'''
(D/'README_v169.md').write_text(readme);(P/'修复说明_v1.69.txt').write_text(readme)
shutil.copy2(D/'validation_v169.json',P/'validation_v169.json')
guide='''# 猎手v1.69：当前忏悔+／REPENTOGON环境

使用匹配忏悔+的官方Launcher，不要混装普通忏悔1.0.12 DLL。

- 官方Launcher：https://github.com/TeamREPENTOGON/Launcher/releases/latest
- 官方安装和存档说明：https://github.com/TeamREPENTOGON/REPENTOGON/blob/1.1.3/docs/docs/install_zh.md
- Weapon接口：https://github.com/TeamREPENTOGON/REPENTOGON/blob/1.1.3/docs/docs/Weapon.md
- 回调说明：https://github.com/TeamREPENTOGON/REPENTOGON/blob/1.1.3/docs/docs/enums/ModCallbacks.md

退出游戏并完整替换猎手旧文件夹，只启用一份。hunterdiag应显示[Hunter v1.69] REPENTOGON=true。本版三圣颂实际伤害为原版4倍，不再使用历史版本BaseDamage=67.2的检查；英灵剑诊断报告真实Spin观察结果及原生武器/输入调用计数。

本机没有运行Isaac；原生旋斩仍需游戏确认。详细修改以本包修复说明v1.69为准，其余机制沿用v1.68。
'''
(D/'REPENTOGON_install_v169_zh.md').write_text(guide);(P/'REPENTOGON_安装说明.md').write_text(guide)
wb=load_workbook('/workspace/deliverables168/compatibility_implementation_v168.xlsx');ws=wb['说明与限制'];ws.delete_rows(1,ws.max_row)
for line in readme.splitlines():
 ws.append([line]);ws.cell(ws.max_row,1).alignment=Alignment(wrap_text=True,vertical='top');ws.row_dimensions[ws.max_row].height=max(22,min(180,len(line)//70*16+22))
for row in wb['实施对照'].iter_rows(min_row=2):
 key=str(row[1].value)
 if key=='579':row[4].value='v1.69仅修正原生触发生命周期';row[6].value='请求跨完整输入/武器更新；准备阶段保留蓄力；原生主剑保留与真实Spin检测，兼容复用不再创建实体；恢复输入和发射限制';row[7].value='提前清零与时序/主剑复用模型旧版失败、新版通过；仍需游戏确认'
 if key=='533':row[4].value='v1.69再减半';row[5].value='原版实际命中伤害4倍，沿用已确认命中链';row[6].value='仅倍率8改4；EID同步；其他光束行为不变';row[7].value='命中模型及其他机制完整源码保持检查通过；待实测'
wb.save(D/'compatibility_implementation_v169.xlsx')
with zipfile.ZipFile(D/'verification_sources_v169.zip','w',zipfile.ZIP_DEFLATED)as out:
 names=['build169.py','verify169.py','test_compat169.lua','package169.py','verify166.py','test_stats161.lua','test_red_damage157.lua','test_bone_containers162_tail.lua','test_eid158.lua','test_compat_eid165.lua','eid_actual_api158.lua','eid_item_api163.lua']+['tainted_hunter_'+n+'169.lua'for n in ['compat','compat_eid','rules','sword']]
 for n in names:out.write(T/n,n)
 out.writestr('VERIFICATION_CONTEXT.txt','Logic/interface contract tests only, not Isaac runtime. Tests use referenced v168/v169 mod trees and uploaded API fixtures at fixed workspace paths. Official API references: https://github.com/TeamREPENTOGON/REPENTOGON/tree/1.1.3 .\n')
z=D/'hunter_v169.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as out:
 for p in sorted(P.rglob('*')):
  if p.is_file():out.write(p,p.relative_to(D))
with zipfile.ZipFile(z)as out:
 assert out.testzip()is None
 for p in P.rglob('*'):
  if p.is_file():assert out.read(str(p.relative_to(D)))==p.read_bytes()
 assert out.read('zzzz_revolver_samson/tainted_hunter_compat_items.lua')==Path('/workspace/deliverables168/zzzz_revolver_samson/tainted_hunter_compat_items.lua').read_bytes()
 count=len(out.namelist())
names=['hunter_v169.zip','README_v169.md','validation_v169.json','verification_sources_v169.zip','compatibility_implementation_v169.xlsx','REPENTOGON_install_v169_zh.md']
(D/'SHA256SUMS_v169.txt').write_text(''.join(hashlib.sha256((D/n).read_bytes()).hexdigest()+'  '+n+'\n'for n in names))
print(json.dumps({'files':count,'bytes':z.stat().st_size,'CRC':'PASS','byte_comparison':'PASS','publish':names},ensure_ascii=False,indent=2))
