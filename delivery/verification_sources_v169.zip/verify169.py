from pathlib import Path
import ctypes,json,xml.etree.ElementTree as E,re
T=Path('/workspace/hunter-fix-tools')
exec((T/'verify166.py').read_text().split("prefix='local MOD_ROOT='")[0])
D=Path('/workspace/deliverables169');P=D/'zzzz_revolver_samson';OLD=Path('/workspace/deliverables168/zzzz_revolver_samson')
prefix='local MOD_ROOT='+json.dumps(str(P))+'\n'
for p in P.glob('*.lua'):lua(p.read_text(),p.name)
for p in list(P.rglob('*.xml'))+list(P.rglob('*.anm2')):E.parse(p)
fixture=(T/'test_compat169.lua').read_text();lua(prefix+fixture,'v169_integrated',True)
header=fixture[:fixture.index('do\nlocal p=player({[373]=1});local t=nativeShot(p)')]
old='local MOD_ROOT="/workspace/deliverables168/zzzz_revolver_samson"\n'
lua(old+header+'''
local p=player({[579]=1});p.input=Vector(1,0);tick(p,4)
assert(p.nativeSpinCount==1,'Full native weapon tick must produce a spin')
''','v168_cached_input_and_late_weapon_tick',True,'Full native weapon tick must produce a spin')
# The old implementation's own two callbacks erase the armed charge even
# before modeling any native timing; this is a direct code regression.
lua(old+header+'''
local p=player({[579]=1});C._testing.sword.attack(p,Vector(1,0))
call(1160,p);assert(p:GetWeapon(1):GetCharge()>=30)
call(31,p)
assert(p:GetWeapon(1):GetCharge()>=30,'Charge must survive the arm phase until native release')
''','v168_premature_clear_charge',True,'Charge must survive the arm phase until native release')
print('v168 fails full input-cache/late-weapon lifecycle and direct preserved-charge regressions; v169 passes')
prior=(T/'verify166.py').read_text();a=prior.index("statsRoot=");b=prior.index('preserved=0')
s=prior[a:b].replace("assert(text(533):find('16倍原生基础伤害'))", "assert(text(533):find('实际命中伤害为原版的4倍'))\nassert(text(68):find('400%%'))\nassert(text(316):find('包含刺门等自伤'))")
s=s.replace('eid_character_text_v166','eid_character_text_v169');exec(s)
# User requested all non-sword/non-light behavior unchanged. Check both module
# bytes and the complete non-sword compatibility program, not just test cases.
changed={'tainted_hunter_compat.lua','tainted_hunter_sword.lua','tainted_hunter_rules.lua','tainted_hunter_compat_eid.lua','main.lua','metadata.xml','REPENTOGON_安装说明.md'}
preserved=0
for p in OLD.rglob('*'):
 if p.is_file()and p.name not in changed:
  assert p.read_bytes()==(P/p.relative_to(OLD)).read_bytes(),p
  if p.suffix in{'.png','.anm2'}:preserved+=1
current=(P/'tainted_hunter_compat.lua').read_text();baseline=(OLD/'tainted_hunter_compat.lua').read_text()
normalized=current.replace('-- v169: full native sword tick lifecycle; light4x; other v168 mechanics preserved.','-- v168: native sword weapon release, confirmed hurt teleport, light8x and Technology4x.').replace('4*R.chocolateFor(p)','8*R.chocolateFor(p)',1).replace('td.lightMultiplier164 or 4','td.lightMultiplier164 or 8').replace('local nativeOwner,priming=sword.isHitbox(knife)','local nativeOwner=sword.isHitbox(knife)').replace('kd.nativeSwordHitbox166=true;kd.blockedSwing163=priming or nil','kd.nativeSwordHitbox166=true').replace('[Hunter v1.69]','[Hunter v1.68]')
assert normalized==baseline,'Non-target compatibility code changed'
eid=(P/'tainted_hunter_compat_eid.lua').read_text().replace('实际命中伤害为原版的4倍','实际命中伤害为原版的8倍').replace('4x actual native hit damage','8x actual native hit damage')
assert eid==(OLD/'tainted_hunter_compat_eid.lua').read_text()
assert (P/'tainted_hunter_rules.lua').read_text().replace('version=169','version=168')==(OLD/'tainted_hunter_rules.lua').read_text()
assert (P/'main.lua').read_text().splitlines()[1:]==(OLD/'main.lua').read_text().splitlines()[1:]
sword=(P/'tainted_hunter_sword.lua').read_text()
for forbidden in ['MC_POST_RENDER','FindInRadius','TakeDamage(',':Shoot(',':FireKnife(',':SetIsSpinAttack(',':Play(']:assert forbidden not in sword,forbidden
assert not re.search(r'(?<![\w:])Sprite\(',sword)
# Current official1.1.3 interfaces, read-only reference checkout.
refs=T/'refs168';callbacks=(refs/'docs_docs_enums_ModCallbacks.md').read_text();weapon=(refs/'repentogon_LuaInterfaces_LuaWeapon.cpp').read_text()
for name in ['MC_POST_WEAPON_FIRE','MC_PRE_PLAYER_UPDATE','MC_PRE_KNIFE_UPDATE','MC_POST_FIRE_SWORD']:assert name in callbacks,name
for name in ['GetMainEntity','GetWeaponType','GetMaxCharge','SetCharge','SetFireDelay']:assert'"'+name+'"'in weapon,name
report={'version':'1.69','target':'Repentance+ with REPENTOGON; interface sources checked against1.1.3','syntax_xml_anm2':'PASS','visual_assets_byte_identical':preserved,'scope':'Only sword lifecycle/priming-hitbox protection, light8x->4x, matching EID and version/diagnostic metadata changed','preservation':'PASS: inventory/Cursed Eye self-damage and door teleport module, damage/broken hearts, stats, Stats+, combat/reload, charge UI and content/items.xml byte-identical to v168; all other compatibility source verified by normalized full-file comparison','sword':'Input arm/release survives pre-cached input and late native Weapon::Fire; do not clear armed charge at POST_PLAYER; advance/restore at POST_UPDATE; prime/protect native main sword, detect its actual Spin state without requiring another factory callback; native art/collision only, no simulated sweep','light':'4x actual native light hit damage; half of v1688x; confirmed collision/ExtraSource chain preserved','regressions':'PASS: v168 direct premature charge clearing and broader input/weapon lifecycle contracts fail, v169 passes; reused sword/prime damage suppression/genuine spin/collision/chamber/input/gate checks plus prior full mechanics, actual uploaded Stats+/EID and heart exclusion suites','user_runtime_feedback':'v168 diagnostic: native weapon released but no spin callback observed; no runtime trace of exact engine input/weapon callback order was provided','game_runtime':'NOT RUN; no Isaac executable available. Full-tick contract testing does not prove native animation works in the game','limits':['Native original spin still requires in-game confirmation; diagnostic now includes native weapon calls, input polls and sword callback counts','Native weapon-priority combinations and previously documented cap/source limits unchanged']}
(D/'validation_v169.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('v169 verification complete: scope-preservation and logic contracts; no Isaac runtime')
