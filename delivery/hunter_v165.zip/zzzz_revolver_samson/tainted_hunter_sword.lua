-- Vanilla has no SetIsSpinAttack. Drive the entire sweep and its collision,
-- rather than pretending Sprite:Play('Spin') changes native sword state.
return function(mod,playerType,R)
    local S={active={}};local game=Game();local LENGTH=12;local RADIUS=70
    local function valid(p)return p and p:Exists()and not p:IsDead()and p:GetPlayerType()==playerType end
    local function difference(a,b)return (a-b+180)%360-180 end
    local function copyArt(state)
        local knife=state.knife
        if not knife:Exists()then return end
        local native=knife:GetSprite();local file=native:GetFilename();local anim=native:GetAnimation()
        if not file or file==''or not anim or anim==''then return end
        if state.actionArt then return end
        if not anim:find('Idle')and native:GetFrame()>=1 then state.actionArt=true end
        if state.file~=file then
            state.sprite:Load(file,true);state.file=file
            -- Unlike v164 this is an independent renderer: the native normal
            -- swing state cannot immediately overwrite a supported Spin clip.
            state.sprite:Play('Spin',true)
            if state.sprite:IsPlaying('Spin')then
                state.sprite:Update();state.actionArt=true;state.chargedArt=true
                return
            end
        end
        -- Only use animations confirmed by the real entity; no guessed Spin name.
        state.sprite:Play(anim,true);state.sprite:SetFrame(anim,native:GetFrame())
    end
    function S.attack(p,dir)
        local knife=p:FireKnife(p,0,true,0,10)
        knife:Shoot(1,RADIUS)
        knife.CollisionDamage=0;knife.EntityCollisionClass=0;knife.GridCollisionClass=0;knife.Visible=false
        local kd=knife:GetData();kd.spin163=true;kd.spin165=true;kd.owner163=p;kd.aux163=true
        kd.until163=game:GetFrameCount()+LENGTH+1
        local state={owner=p,knife=knife,sprite=Sprite(),start=game:GetFrameCount(),duration=LENGTH,
            angle=dir:GetAngleDegrees(),damage=8*p.Damage+10,hit={},projectiles={},progress=0}
        copyArt(state);S.active[#S.active+1]=state
        return state
    end
    local function update()
        local nextStates={}
        for _,s in ipairs(S.active)do
            local age=game:GetFrameCount()-s.start
            if valid(s.owner)and age<=s.duration then
                local previous=s.progress;s.progress=math.max(0,math.min(1,age/s.duration))
                if s.knife:Exists()then
                    s.knife.Visible=false;s.knife.CollisionDamage=0;s.knife.EntityCollisionClass=0
                    s.knife.Position=s.owner.Position;copyArt(s)
                end
                local from=s.angle+previous*360;local to=s.angle+s.progress*360
                local middle=(from+to)/2;local half=math.max(0,(to-from)/2)+6
                if Isaac.FindInRadius then
                    for _,npc in ipairs(Isaac.FindInRadius(s.owner.Position,RADIUS+40,EntityPartition.ENEMY))do
                        local offset=npc.Position-s.owner.Position;local distance=offset:Length()
                        local padding=distance>0 and math.deg(math.asin(math.min(1,(npc.Size or 0)/distance)))or 180
                        local key=tostring(npc.InitSeed)
                        if not s.hit[key]and npc:Exists()and not npc:IsDead()and npc:IsVulnerableEnemy()
                            and not npc:HasEntityFlags(EntityFlag.FLAG_FRIENDLY)and distance<=RADIUS+(npc.Size or 0)
                            and math.abs(difference(offset:GetAngleDegrees(),middle))<=half+padding then
                            s.hit[key]=true
                            npc:TakeDamage(s.damage,0,EntityRef(s.owner),1)
                        end
                    end
                    if EntityPartition.BULLET and ProjectileFlags then
                        for _,e in ipairs(Isaac.FindInRadius(s.owner.Position,RADIUS+15,EntityPartition.BULLET))do
                            local key=tostring(e.InitSeed);local offset=e.Position-s.owner.Position
                            if not s.projectiles[key]and offset:Length()<=RADIUS+(e.Size or 0)
                                and math.abs(difference(offset:GetAngleDegrees(),middle))<=half+8 then
                                local bullet=e:ToProjectile()
                                if bullet then
                                    s.projectiles[key]=true
                                    bullet:AddProjectileFlags((ProjectileFlags.CANT_HIT_PLAYER or 0)|(ProjectileFlags.HIT_ENEMIES or 0))
                                    bullet.Velocity=offset:Normalized()*math.max(6,bullet.Velocity:Length())
                                    bullet.CollisionDamage=4*s.owner.Damage+4
                                end
                            end
                        end
                    end
                end
                if s.progress<1 then nextStates[#nextStates+1]=s
                elseif s.knife:Exists()then s.knife:Remove()end
            elseif s.knife:Exists()then s.knife:Remove()end
        end
        S.active=nextStates
    end
    mod:AddCallback(ModCallbacks.MC_POST_UPDATE,update)
    mod:AddCallback(ModCallbacks.MC_POST_KNIFE_UPDATE,function(_,knife)
        if knife:GetData().spin165 then
            knife.CollisionDamage=0;knife.EntityCollisionClass=0;knife.GridCollisionClass=0;knife.Visible=false
        end
    end)
    mod:AddCallback(ModCallbacks.MC_POST_RENDER,function()
        if game:IsPaused()then return end
        for _,s in ipairs(S.active)do
            if valid(s.owner)and s.owner.Visible and s.file then
                local pos=Isaac.WorldToScreen(s.owner.Position)+Vector(0,-8)
                local angle=s.angle+s.progress*360
                local alpha=math.min(1,(1-s.progress)*4)
                for trail=4,0,-1 do
                    s.sprite.Rotation=angle-trail*14
                    s.sprite.Color=Color(1,1,1,alpha*(trail==0 and 1 or .11),0,0,0)
                    s.sprite:Render(pos,Vector(0,0),Vector(0,0))
                end
            end
        end
    end)
    mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM,function()
        for _,s in ipairs(S.active)do if s.knife:Exists()then s.knife:Remove()end end
        S.active={}
    end)
    mod:AddCallback(ModCallbacks.MC_POST_GAME_STARTED,function()S.active={}end)
    S._update=update
    return S
end
