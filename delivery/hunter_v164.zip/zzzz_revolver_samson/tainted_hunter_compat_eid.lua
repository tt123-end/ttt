-- Item descriptions apply only to the player whose EID page is being shown.
return function(mod,playerType)
    local installed
    local text={
        [52]={"保留直线飞刀，不使用炸弹弹体；命中敌人/障碍物/墙体时爆炸，爆炸伤害为200%面板+30；保留射速惩罚","Straight tear knives, not bombs; impact explosion deals200% sheet damage+30; native rate penalty retained"},
        [69]={"不需蓄力；飞刀增伤随当前射速/最高射速降低而提高，比例≤0.25时×4，比例1时×1.2","No charge; knife multiplier smoothly grows from1.2 at rate/cap1 to4 at0.25"},
        [114]={"转换为3把献祭匕首，不替换飞刀攻击","Replaced with3 Sacrificial Daggers; knives remain the primary weapon"},
        [118]={"每轮立即同时发射飞刀和50%原生伤害的硫磺火；血激光不因装填中断","Fire a knife and a half-damage native Brimstone beam immediately; reload does not cancel it"},
        [168]={"保留原生准星导弹；爆炸后向随机方向射出3把400%面板伤害飞刀，继承弹速和射程","Native targeted rocket; explosion releases3 random knives, each400% sheet damage with player speed/range"},
        [229]={"不需蓄力；立即发射散弹后正常装填，保留原生射速惩罚","Immediate shotgun, then normal reload; native rate penalty retained"},
        [316]={"不需蓄力；每轮5把飞刀，各80%面板伤害；装填受伤时原生随机传送","Immediate5-knife volley, each80% sheet damage; damage during reload can teleport you"},
        [395]={"飞刀携带满蓄力伤害的科技X环；同时持有硫磺火则为加粗血环，不再额外发射直线血激光","A full-charge-damage Tech X ring follows each knife; Brimstone makes it a thick blood ring instead of a separate beam"},
        [556]={"在本房间获得里猎手的无蓄力硫磺火兼容","Grants Tainted Hunter's instant Brimstone compatibility for the room"},
        [579]={"仍发射飞刀；满血时发射原生剑气；每次非换弹期间实际攻击时触发一次蓄力旋转斩击","Keep knives and full-health sword beams; one charged spin slash on each actual attack outside reload"},
        [678]={"无蓄力发射携刀胎儿，采用原生剖腹产＋妈妈刀形态，造成4倍原生伤害","Immediate knife-carrying fetuses using the native C Section/Knife form, with4x native damage"},
        [352]={"玻璃大炮原生伤害×4；其他原生效果保留","Glass Cannon native damage x4; its other effects remain native"},
        [149]={"保持直线飞刀，命中爆炸，可自伤；主刀和爆炸各100%面板伤害；保留原生+40伤害与射速惩罚","Straight knives with impact explosion and self-damage; knife and explosion each100% sheet damage; native+40 damage/rate penalty retained"},
        [533]={"保留原生光束弹，其实际光束命中伤害×4，不重复放大","Native light projectiles; actual light-beam hits deal4x native damage, applied once"},
        [104]={"原飞刀及所有合法分裂弹全部落空，才尝试重置死亡之眼","Dead Eye can reset only when the entire primary/descendant group misses"},
        [150]={"触发时仍为飞刀，造成3.2倍普通飞刀伤害","Tooth procs keep the knife appearance and deal3.2x normal knife damage"},
        [154]={"替换为里猎手版本：原生属性加法阶段伤害+1.5，不再左右眼交替增伤","Hunter replacement: +1.5 additive damage instead of alternating-eye damage"},
        [237]={"保留其原生属性、尺寸和穿透；仍为深色飞刀","Native stats, size and piercing retained; dark knives replace the scythe visual"},
        [331]={"原生神性光环伤害×5；其他原生效果保留","Native Godhead aura damage x5; other effects retained"},
        [398]={"缩小效果触发概率改为50%","Shrink proc chance50%"},
        [429]={"有效泪弹命中掉币概率改为25%","25% coin-drop chance on an effective tear hit"},
        [443]={"触发时仍为飞刀，造成4倍普通飞刀伤害","Razor procs keep the knife appearance and deal4x normal knife damage"},
        [503]={"原生触发概率×5，最高100%","Native proc probability x5, capped at100%"},
        [637]={"转换为八寸钉","Replaced with8 Inch Nails"},
        [619]={"弹仓2发；两发之间为面板攻击间隔的20%；打空后按完整面板攻击间隔装填","2-round chamber;20% of the sheet interval between rounds; full-interval reload when empty"}
    }
    local function install()
        if installed==EID or not EID or type(EID.addDescriptionModifier)~="function"then return end
        EID:addDescriptionModifier("Hunter workbook163",function(desc)
            local p=EID.player or Isaac.GetPlayer(0)
            return p and p:GetPlayerType()==playerType and desc.ObjType==5 and desc.ObjVariant==100 and text[desc.ObjSubType]~=nil
        end,function(desc)
            local zh=EID:getLanguage()=="zh_cn";local p=EID.player or Isaac.GetPlayer(0)
            desc.Description=text[desc.ObjSubType][zh and 1 or 2]
            if (desc.ObjSubType==52 or desc.ObjSubType==149)and p:HasCollectible(52)and p:HasCollectible(149)then
                desc.Description=zh and "仍为飞刀；普通最高射速固定0.6；保留+40面板属性加成；主刀100%面板，爆炸100%面板+30；免疫爆炸"or"Knives, ordinary cap0.6, native+40 damage;100% sheet knife,100% sheet+30 explosion; explosion immunity"
            end
            return desc
        end)
        local token=Isaac.GetItemIdByName("Hunter Chemical Peel")
        if token and token>0 and type(EID.addCollectible)=="function"then
            EID:addCollectible(token,"{{Damage}} 原生属性加法阶段伤害+1.5，不再有左右眼差异","化学剥皮法（里猎手）","zh_cn")
            EID:addCollectible(token,"{{Damage}} +1.5 additive damage; no alternating-eye bonus","Chemical Peel (Hunter)","en_us")
        end
        installed=EID
    end
    install();mod:AddCallback(ModCallbacks.MC_POST_UPDATE,install)
end
