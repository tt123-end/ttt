from pathlib import Path
import shutil,xml.etree.ElementTree as E
T=Path('/workspace/hunter-fix-tools');OLD=Path('/workspace/deliverables163/zzzz_revolver_samson');P=Path('/workspace/deliverables164/zzzz_revolver_samson')
for name in ['compat','compat_eid','charge_ui']:
 shutil.copy2(T/f'tainted_hunter_{name}164.lua',P/f'tainted_hunter_{name}.lua')
s=(OLD/'main.lua').read_text().replace('-- v1.63 - compatibility implementation from the user-approved workbook','-- v1.64 - reliable hit groups and native-effect compatibility fixes',1)
needle='mod.HunterCompat163 = include("tainted_hunter_compat")(mod, TAINTED_PLAYER_TYPE)'
assert needle in s
s=s.replace(needle,needle+'\ninclude("tainted_hunter_charge_ui")(mod, TAINTED_PLAYER_TYPE, mod.HunterCompat163.rules)',1)
(P/'main.lua').write_text(s)
s=(OLD/'tainted_hunter_combat.lua').read_text().replace('        if compat.onReload then compat.onReload(player,data)end','        -- Spirit Sword now triggers on an actual attack, not on reload start.',1)
(P/'tainted_hunter_combat.lua').write_text(s)
t=E.parse(OLD/'metadata.xml');t.getroot().find('version').text='1.64';t.getroot().find('description').text='v1.64: Dead Eye hit/miss fix, native charge wheel suppression, straight explosive knife flight, Dr Fetus blast2x+30, Ipecac hit/blast1x, Trisagion actual hit4x, Spirit Sword spin on attack.';t.write(P/'metadata.xml',encoding='utf-8',xml_declaration=True)
print('Built v1.64')
