from pathlib import Path
import ctypes,json,xml.etree.ElementTree as E
D=Path('/workspace/deliverables164');P=D/'zzzz_revolver_samson';OLD=Path('/workspace/deliverables162/zzzz_revolver_samson');T=Path('/workspace/hunter-fix-tools')
lib=ctypes.CDLL('liblua5.4.so.0');lib.luaL_newstate.restype=ctypes.c_void_p
lib.luaL_loadbufferx.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_size_t,ctypes.c_char_p,ctypes.c_char_p]
lib.lua_tolstring.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_void_p];lib.lua_tolstring.restype=ctypes.c_char_p
lib.lua_close.argtypes=[ctypes.c_void_p];lib.luaL_openlibs.argtypes=[ctypes.c_void_p]
lib.lua_pcallk.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_longlong,ctypes.c_void_p]
def lua(source,label,execute=False,expected_failure=None):
 data=source.encode();st=lib.luaL_newstate();lib.luaL_openlibs(st)
 assert lib.luaL_loadbufferx(st,data,len(data),label.encode(),None)==0,(label,lib.lua_tolstring(st,-1,None))
 if execute:
  result=lib.lua_pcallk(st,0,0,0,0,None)
  error=lib.lua_tolstring(st,-1,None)if result else None
  if expected_failure:assert result and expected_failure.encode()in error,(label,error)
  else:assert result==0,(label,error)
 lib.lua_close(st)
prefix='local MOD_ROOT='+json.dumps(str(P))+'\n'
for p in P.glob('*.lua'):lua(p.read_text(),p.name)
for p in list(P.rglob('*.xml'))+list(P.rglob('*.anm2')):E.parse(p)
lua(prefix+(T/'test_compat164.lua').read_text(),'integrated_compatibility164',True)
oldFixture=(T/'test_compat163.lua').read_text()
removeStart=oldFixture.index(' function e:Remove()');removeEnd=oldFixture.index('\n function e:TakeDamage',removeStart)
newFixture=(T/'test_compat164.lua').read_text()
mockStart=newFixture.index(' function e:Remove()');mockEnd=newFixture.index('\n function e:TakeDamage',mockStart)
oldFixture=oldFixture[:removeStart]+newFixture[mockStart:mockEnd]+oldFixture[removeEnd:]
oldPrefix='local MOD_ROOT="/workspace/deliverables163/zzzz_revolver_samson"\n'
tail=(T/'test_deadeye164_tail.lua').read_text()
lua(oldPrefix+oldFixture+'\n'+tail,'old_v163_rejected_tear_failure',True,'Rejected native tear must never reset Dead Eye')
second=tail[tail.index('local p=player({[373]=1});local root=nativeShot(p)'):]
lua(oldPrefix+oldFixture+'\n'+second,'old_v163_target_hp_restore_failure',True,'A hit must survive a stationary target restoring its HP')
lightRegression='''
local p=player({[533]=1});p.nativeFlags=TearFlags.TEAR_LASERSHOT
local root=nativeShot(p);local target=entity(10);target.HitPoints=1000
local light=entity(7,5,p);light.Parent=root;light.CollisionDamage=p.Damage/3
target:TakeDamage(light.CollisionDamage,8,EntityRef(light),0)
assert(math.abs(target.HitPoints-(1000-p.Damage/3*4))<1e-6,'Actual Trisagion light hit must be multiplied4')
'''
lua(oldPrefix+oldFixture+'\n'+lightRegression,'old_v163_light_laser_failure',True,'Actual Trisagion light hit must be multiplied4')
print('v163 confirmed failing both targeted Dead Eye regressions; v164 passes both')
statsRoot='/workspace/reference-stats-plus154/stats-plus_2729900570'
stats=(T/'test_stats161.lua').read_text()
stats+='''
mod.HunterCompat163={rules={blastCombo=function(p)return p:HasCollectible(52)and p:HasCollectible(149)end},flatDamage=function()return 1.5 end}
p.items[562]=nil;p.items[52]=1;p.items[149]=1;p.a=5;p.b=20;p.tearsBonus=0;settle(p)
approx(p.data.hunterTears161.capRate,.6);approx(p.Damage,6)
print('v163 forced-cap0.6 and +1.5-before-x1.2 damage passed')
'''
lua(prefix+'local OLD_ROOT="/workspace/deliverables160/zzzz_revolver_samson"\nlocal STATS_ROOT='+json.dumps(statsRoot)+'\n'+stats,'uploaded_stats_api_and_numeric_regression',True)
damage=(T/'test_red_damage157.lua').read_text()
damage=damage.replace(' function p:GetMaxHearts()return self.max end',' function p:GetMaxHearts()return self.max end\n function p:GetBoneHearts()return self.bone end',1)
damage=damage.replace('self.red=math.min(self.red,self.max)','self.red=math.min(self.red,self.max+self.bone*2)',1)
damage=damage.replace('local p=player(20,2,4);p.bone=1;p:TakeDamage(5,0,enemy,30);assert(p.red==1 and p.broken==1)',"local p=player(20,2,0);p.max=0;p.bone=1;p:TakeDamage(1,0,enemy,30);assert(p.red==1 and p.broken==0)",1)
lua(prefix+damage+'\n'+(T/'test_bone_containers162_tail.lua').read_text(),'red_damage_and_bone_regression',True)
eid=(T/'test_eid158.lua').read_text().replace('800%%','400%%')
eidprefix=prefix+'local ACTUAL_API='+json.dumps(str(T/'eid_actual_api158.lua'))+'\nlocal TEXT_ARTIFACT='+json.dumps(str(D/'eid_character_text_v164.txt'))+'\n'
lua(eidprefix+eid,'uploaded_character_eid_api',True)
lua(eidprefix+'local ACTUAL_ITEM_API='+json.dumps(str(T/'eid_item_api163.lua'))+'\n'+(T/'test_compat_eid163.lua').read_text(),'uploaded_item_eid_api',True)
eidItem=(T/'test_compat_eid163.lua').read_text()
eidItem+='''
p.kind=20;p.items={};EID.Config.Language='zh_cn'
local function text(id)return modifier.callback({ObjType=5,ObjVariant=100,ObjSubType=id}).Description end
assert(text(52):find('200%%')and text(52):find('不使用炸弹弹体'))
assert(text(149):find('主刀和爆炸各100%%'))
assert(text(579):find('实际攻击时')and not text(579):find('开始装填'))
assert(text(533):find('实际光束命中伤害×4'))
EID.Config.Language='en_us';assert(text(52):find('200%%')and text(579):find('actual attack'))
print('v164 actual EID feedback wording and numeric overrides passed in both languages')
'''
lua(eidprefix+'local ACTUAL_ITEM_API='+json.dumps(str(T/'eid_item_api163.lua'))+'\n'+eidItem,'updated_item_eid_values',True)
preserved=0
for p in OLD.rglob('*'):
 if p.is_file()and p.suffix in {'.png','.anm2'}:
  assert p.read_bytes()==(P/p.relative_to(OLD)).read_bytes(),p
  preserved+=1
assert (OLD/'tainted_hunter_damage.lua').read_bytes()==(P/'tainted_hunter_damage.lua').read_bytes()
previous=Path('/workspace/deliverables163/zzzz_revolver_samson')
changed={'main.lua','metadata.xml','tainted_hunter_combat.lua','tainted_hunter_compat.lua','tainted_hunter_compat_eid.lua'}
for p in previous.rglob('*'):
 if p.is_file()and p.name not in changed:assert p.read_bytes()==(P/p.relative_to(previous)).read_bytes(),p
main164=(P/'main.lua').read_text().replace('\ninclude("tainted_hunter_charge_ui")(mod, TAINTED_PLAYER_TYPE, mod.HunterCompat163.rules)','',1)
assert main164.splitlines()[1:]==(previous/'main.lua').read_text().splitlines()[1:]
oldMain=(OLD/'main.lua').read_text();newMain=(P/'main.lua').read_text()
assert oldMain.split('local taintedStats = include')[0].splitlines()[1:]==newMain.split('mod.HunterCompat163 = include')[0].splitlines()[1:]
report={'version':'1.64','workbook_decision_rows':1497,'custom_decision_rows':39,'lua_syntax_files':len(list(P.glob('*.lua'))),'xml_anm2':'PASS','integrated_compatibility':'PASS: deterministic engine-contract model, not game runtime','stats_plus':'PASS: uploaded cap function/display, validators and multiplier middleware; baseline210 monotonic cases; explicit Dr Fetus+Ipecac cap0.6','damage':'PASS: prior red-heart/payment/shield cases plus dedicated bone-container regressions; damage module byte-identical to v162','eid':'PASS: uploaded character API and item modifier/collectible registration API;25 localized item overrides','visual_assets_preserved':preserved,'game_runtime':'NOT RUN; no Isaac executable available','known_limits':['Rock Bottom: no safe exact readonly native-cap API in vanilla; sampling disabled and last safe cap reference retained, Stats+ may show UNKNOWN','Godhead aura attribution, native fetal knives/spin collision, active/auxiliary source timing and complex combinations need in-game validation','Default rows generally delegate native behavior through shared adapters; this is not721 individually game-tested items']}
report['targeted_regressions']={'v163':'Confirmed failures: discarded native tears trigger a miss reset; target HP restoration loses hit attribution; actual Trisagion child laser remains unscaled','v164':'All pass;240 stationary-target hit volleys, parasite all-miss/any-hit, invalid/friendly contacts, ordinary tear entities/range, fetal-bomb suppression and manual-bomb isolation, actual light-laser hit4x including first-hit/child/DOT/aura isolation, attack-time Spirit Sword spins on both Birthright rounds, native charge-option restore and reload sprite rendering'}
report['values']={'Dr_Fetus_knife':'4*panel (normal knife)','Dr_Fetus_explosion':'2*panel+30','Ipecac_knife':'1*panel','Ipecac_explosion':'1*panel','Dr_Fetus_plus_Ipecac':'Existing explicit pair retained:1*panel knife,1*panel+30 blast, cap0.6 and explosion immunity','Trisagion':'4*native actual light hit; no carrier4x duplication','Spirit_Sword':'Charged spin per actual ready attack; full-health native beam retained'}
report['native_charge_UI']='Vanilla uses the global Options.ChargeBars switch while Tainted Hunter is in an instant scripted weapon mode; prior value restored on mode/death/run/exit/unload. Reload sprite independent. In co-op, other native charge wheels are also hidden during that mode; no per-player native render hook in vanilla.'
(D/'validation_v164.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('Integrated checks completed')
