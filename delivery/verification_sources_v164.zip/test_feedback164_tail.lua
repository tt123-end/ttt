-- Continuous stationary-target hits and suppressed native duplicates.
for _,loadout in ipairs({{[373]=1},{[373]=1,[69]=1}})do
 local p=player(loadout);local target=entity(10);target.HitPoints=100000
 for volley=1,120 do
  local root
  if loadout[69]then p.input=Vector(1,0);tick(p);p.input=Vector(0,0);root=latest(2,p)
  else root=nativeShot(p)end
  call(42,root,target);target:TakeDamage(root.CollisionDamage,0,EntityRef(root),0)
  target.HitPoints=100000;root:Remove();tick(p)
  local rejected=nativeShot(p);assert(rejected.removed and not rejected.CanTriggerStreakEnd)
  tick(p,63)
  assert(p.clears==0,'Continuous successful volleys must not reset Dead Eye')
 end
end
-- All-miss Parasite groups still attempt exactly one native reset, not one per child.
local p=player({[373]=1,[104]=1});local root=nativeShot(p)
local a=p:FireTear(root.Position,Vector(2,0),false,false,false,root,.5)
local b=p:FireTear(root.Position,Vector(-2,0),false,false,false,root,.5)
root:Remove();a:Remove();tick(p,3);assert(p.clears==0)
b:Remove();tick(p,3);assert(p.clears==1);tick(p,3);assert(p.clears==1)
-- A non-HP-changing enemy contact is sufficient, but walls/friendly NPCs are not.
local p=player({[373]=1});local root=nativeShot(p);local friend=entity(10);friend.friendly=true
call(42,root,friend);root:Remove();tick(p,3);assert(p.clears==1)
-- Controlled tears create their hit group at the damage window, before reset HP.
local p=player({[373]=1,[329]=1});local root=nativeShot(p)
local target=entity(10);target.HitPoints=1000
target:TakeDamage(root.CollisionDamage,0,EntityRef(root),0);target.HitPoints=1000
tick(p,3);assert(p.clears==0)

-- Real straight tears: no inherited bomb damage, no parabola and full range budget.
for _,id in ipairs({52,149})do
 local p=player({[id]=1});p.Damage=10;p.nextFactor=100;p.nextVariant=4
 p.nativeFlags=TearFlags.TEAR_EXPLOSIVE;p.input=Vector(1,0);tick(p);p.input=Vector(0,0)
 local t=latest(2,p);assert(t.Type==2 and t.Variant==0)
 approx(t.CollisionDamage,id==52 and 40 or 10)
 approx(t:GetData().explosionDamage163,id==52 and 50 or 10)
 assert(not t:HasTearFlags(TearFlags.TEAR_EXPLOSIVE))
 local count=#bombs
 for step=1,29 do
  t.Position=t.Position+Vector(16,0);t.FallingSpeed=20;t.FallingAcceleration=10
  call(40,t);assert(not t.removed);approx(t.Height,-10);approx(t.FallingSpeed,0);approx(t.FallingAcceleration,0)
 end
 t.Position=t.Position+Vector(16,0);call(40,t);assert(t.removed)
 call(1);assert(#bombs==count,'Open-air range expiration must not explode')
end
local p=player({[52]=1});local ordinaryBomb=entity(4,0,p);ordinaryBomb.IsFetus=false
call(58,ordinaryBomb);assert(not ordinaryBomb.removed)
local fetus=entity(4,0,p);fetus.IsFetus=true;fetus.ExplosionDamage=50
call(58,fetus);assert(fetus.removed and fetus.ExplosionDamage==0)
local npc=entity(10,0,p);local friendlyFetus=entity(4,0,npc);friendlyFetus.IsFetus=true
call(58,friendlyFetus);assert(not friendlyFetus.removed)

-- Trisagion: scale actual light hits exactly4, before first laser-update as well.
local p=player({[533]=1});p.nativeFlags=TearFlags.TEAR_LASERSHOT
local root=nativeShot(p);approx(root.CollisionDamage,p.Damage)
local target=entity(10);target.HitPoints=1000
local l=entity(7,5,p);l.Parent=root;l.CollisionDamage=p.Damage/3
-- Exercise the damage-time fallback, before init/update metadata was observed.
target:TakeDamage(l.CollisionDamage,DamageFlag.DAMAGE_LASER,EntityRef(l),0)
approx(target.HitPoints,1000-p.Damage/3*4)
for i=1,6 do
 call(27,l);call(48,l);l.CollisionDamage=p.Damage/3
 target:TakeDamage(l.CollisionDamage,DamageFlag.DAMAGE_LASER,EntityRef(l),0)
end
approx(target.HitPoints,1000-7*p.Damage/3*4)
-- Poison/DOT isn't the light beam, and unrelated red lasers retain their own damage.
local hp=target.HitPoints;target:TakeDamage(1,DamageFlag.DAMAGE_POISON_BURN,EntityRef(l),0)
approx(target.HitPoints,hp-1)
local other=entity(7,1,p);other.CollisionDamage=2;target:TakeDamage(2,DamageFlag.DAMAGE_LASER,EntityRef(other),0)
approx(target.HitPoints,hp-3)
local child=p:FireTear(root.Position,Vector(3,0),false,false,false,root,.5)
child.CollisionDamage=p.Damage*.5
local light=entity(7,5,p);light.Parent=child;light.CollisionDamage=child.CollisionDamage/3;call(27,light)
hp=target.HitPoints;target:TakeDamage(light.CollisionDamage,DamageFlag.DAMAGE_LASER,EntityRef(light),0)
approx(target.HitPoints,hp-child.CollisionDamage/3*4)
-- Trisagion and Godhead aura multipliers are separate rather than multiplying to20.
local p=player({[533]=1,[331]=1});p.nativeFlags=TearFlags.TEAR_LASERSHOT|TearFlags.TEAR_GLOW
local root=nativeShot(p);local target=entity(10);target.HitPoints=100
 target:TakeDamage(2,0,EntityRef(root),0);approx(target.HitPoints,90)
-- Spirit Sword's first loaded round now spins too; emptying the chamber adds no third spin.
local p=player({[579]=1,[619]=1});p.input=Vector(1,0)
local function spinCount()
 local count=0;for _,e in ipairs(entities)do if e.SpawnerEntity==p and e:GetData().spin163 then count=count+1 end end;return count
end
tick(p);assert(spinCount()==1 and p:GetData().hunterCombat155.ammo==1 and not p:GetData().hunterCombat155.untilFrame)
tick(p,12);assert(spinCount()==1)
tick(p);assert(spinCount()==2 and p:GetData().hunterCombat155.untilFrame)
tick(p);assert(spinCount()==2)
assert(C.onReload==nil)
-- Native charge UI option is reversible; the reload UI still renders independently.
Options={ChargeBars=true};players={p}
local ui=include('tainted_hunter_charge_ui')(mod,20,R)
ui.update();assert(Options.ChargeBars==false);local prior=renderLog['gfx/chargebar.anm2']or 0
call(2);assert((renderLog['gfx/chargebar.anm2']or 0)>prior)
p.items[579]=nil;ui.update();assert(Options.ChargeBars==true)
p.items[579]=1;ui.update();assert(Options.ChargeBars==false);call(17,true);assert(Options.ChargeBars==true)
Options.ChargeBars=false;ui.update();p.kind=10;ui.update();assert(Options.ChargeBars==false)
Options.ChargeBars=true;p.kind=20;ui.update();p.dead=true;ui.update();assert(Options.ChargeBars==true)
print('v164 feedback model passed:240 stationary-hit volleys, grouped misses, straight-range/entity tests, light-laser actual-hit4x/children/DOT isolation, two attack-time spins, reversible charge UI and visible reload wheel')
