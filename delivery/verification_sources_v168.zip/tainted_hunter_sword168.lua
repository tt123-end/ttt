-- Release the player's real, fully charged Spirit Sword weapon. No stand-in
-- knife factory, copied art, per-frame fake rotation or scripted sweep damage.
return function(mod,playerType,R)
    local S={active={},pending={}};local game=Game()
    local function method(object,name)
        local ok,value=pcall(function()return object[name]end)
        return ok and type(value)=='function'and value or nil
    end
    local function valid(p)return p and p:Exists()and not p:IsDead()and p:GetPlayerType()==playerType end
    local function owner(e,depth)
        if not e or(depth or 0)>6 then return end
        return e:ToPlayer()or owner(e.SpawnerEntity,(depth or 0)+1)or owner(e.Parent,(depth or 0)+1)
    end
    local function diag(p,message)p:GetData().hunterNativeSword166=message end
    function S.attack(p,dir)
        if not REPENTOGON or not ModCallbacks.MC_PRE_PLAYER_UPDATE or not ModCallbacks.MC_POST_FIRE_SWORD then
            diag(p,'native weapon release API unavailable');return
        end
        local previous=S.pending[p.InitSeed]
        if previous then return previous end
        local q={owner=p,dir=Vector(dir.X,dir.Y),stage='arm',start=game:GetFrameCount(),fired=0}
        S.pending[p.InitSeed]=q;diag(p,'native weapon release queued')
        return q
    end
    function S.engineWindow(p)
        local q=S.pending[p.InitSeed];return q and q.scope or false
    end
    local function restore(q)
        if not q.scope then return end
        q.scope=nil
        local p=q.owner
        if not p:Exists()then return end
        p.FireDelay=q.savedDelay or p.FireDelay
        local w=p:GetWeapon(1)
        if w and w:GetWeaponType()==(WeaponType.WEAPON_SPIRIT_SWORD or 13)then
            w:SetFireDelay(q.savedWeaponDelay or 0)
            w:SetCharge(0)
        end
    end
    if ModCallbacks.MC_PRE_PLAYER_UPDATE then
        mod:AddPriorityCallback(ModCallbacks.MC_PRE_PLAYER_UPDATE,900000,function(_,p)
            local q=S.pending[p.InitSeed];if not q then return end
            if not valid(p)or not R.has(p,579)or not p:AreControlsEnabled()or game:GetFrameCount()>q.start+6 then
                restore(q);S.pending[p.InitSeed]=nil;return
            end
            local w=p:GetWeapon(1)
            if not w or w:GetWeaponType()~=(WeaponType.WEAPON_SPIRIT_SWORD or 13)then
                diag(p,'native Spirit Sword primary weapon unavailable');S.pending[p.InitSeed]=nil;return
            end
            q.savedDelay=p.FireDelay;q.savedWeaponDelay=w:GetFireDelay();q.scope=true
            -- Arm a real held charge, then release it in the next player
            -- update. The native Weapon::FireSword initializes the full spin.
            p.FireDelay=0;w:SetFireDelay(0);w:SetCharge(math.max(1,w:GetMaxCharge())+1)
            diag(p,'native weapon '..q.stage..'; charge='..w:GetCharge())
        end)
    end
    if ModCallbacks.MC_INPUT_ACTION then
        mod:AddCallback(ModCallbacks.MC_INPUT_ACTION,function(_,entity,hook,action)
            local p=entity and entity:ToPlayer();local q=p and S.pending[p.InitSeed]
            if not q or not q.scope then return end
            local value
            if action==ButtonAction.ACTION_SHOOTLEFT then value=math.max(0,-q.dir.X)
            elseif action==ButtonAction.ACTION_SHOOTRIGHT then value=math.max(0,q.dir.X)
            elseif action==ButtonAction.ACTION_SHOOTUP then value=math.max(0,-q.dir.Y)
            elseif action==ButtonAction.ACTION_SHOOTDOWN then value=math.max(0,q.dir.Y)
            else return end
            if q.stage=='release'then value=0 end
            if hook==(InputHook.GET_ACTION_VALUE or 2)then return math.min(1,value)end
            if hook==(InputHook.IS_ACTION_PRESSED or 0)then return value>.01 end
            if hook==(InputHook.IS_ACTION_TRIGGERED or 1)then return false end
        end)
    end
    local function capture(knife,p,q)
        local kd=knife:GetData();if kd.nativeSword166 then return end
        kd.nativeSwordCandidate168=nil;kd.owner163=p;kd.aux163=true;kd.spin163=true;kd.nativeSword166=true
        kd.until163=game:GetFrameCount()+90
        q.fired=q.fired+1
        S.active[#S.active+1]={owner=p,knife=knife,start=game:GetFrameCount()}
        diag(p,'native FireSword spin captured; animation='..knife:GetSprite():GetAnimation())
    end
    if ModCallbacks.MC_POST_FIRE_SWORD then
        mod:AddCallback(ModCallbacks.MC_POST_FIRE_SWORD,function(_,knife)
            local p=owner(knife);local q=p and S.pending[p.InitSeed]
            if not q or not q.scope then return end
            if method(knife,'GetIsSpinAttack')and knife:GetIsSpinAttack()then capture(knife,p,q)
            elseif q.stage=='release'then
                -- FireSword's caller may finish initializing spin fields only
                -- after this callback. Protect that genuine native candidate
                -- until its first update, then inspect the finished state.
                local kd=knife:GetData();kd.nativeSwordCandidate168={owner=p,request=q}
                kd.owner163=p;kd.aux163=true;kd.spin163=true;kd.until163=game:GetFrameCount()+3
                q.candidates=(q.candidates or 0)+1
                diag(p,'native sword candidate waiting for engine initialization')
            end
        end)
        mod:AddPriorityCallback(ModCallbacks.MC_POST_KNIFE_UPDATE,-1000000,function(_,knife)
            local candidate=knife:GetData().nativeSwordCandidate168
            if not candidate then return end
            if valid(candidate.owner)and method(knife,'GetIsSpinAttack')and knife:GetIsSpinAttack()then
                capture(knife,candidate.owner,candidate.request)
            else
                diag(candidate.owner,'native release finished without a spin state');knife:Remove()
            end
        end)
    end
    mod:AddPriorityCallback(ModCallbacks.MC_POST_PLAYER_UPDATE,900000,function(_,p)
        local q=S.pending[p.InitSeed];if not q or not q.scope then return end
        local stage=q.stage;restore(q)
        if q.fired>0 then S.pending[p.InitSeed]=nil
        elseif stage=='arm'then q.stage='release'
        else
            if q.fired==0 and not q.candidates then diag(p,'native weapon released, but no spin callback was observed')end
            S.pending[p.InitSeed]=nil
        end
    end)
    function S.isActive(p)
        for _,state in ipairs(S.active)do
            if state.owner==p and state.knife:Exists()and not state.knife:IsDead()then return true end
        end
        return false
    end
    function S.isHitbox(knife)
        if not REPENTOGON then return end
        local parent;local getter=method(knife,'GetHitboxParentKnife')
        if getter then parent=getter(knife)end
        if not parent and knife.Parent and knife.Parent.Type==EntityType.ENTITY_KNIFE then parent=knife.Parent end
        if not parent and knife.SpawnerEntity and knife.SpawnerEntity.Type==EntityType.ENTITY_KNIFE then parent=knife.SpawnerEntity end
        if parent and(parent:GetData().nativeSword166 or parent:GetData().nativeSwordCandidate168)then return parent:GetData().owner163 end
        if knife.SubType==4 then
            local p=owner(knife)
            if p and S.isActive(p)then return p end
        end
    end
    mod:AddCallback(ModCallbacks.MC_POST_UPDATE,function()
        local active={}
        for _,state in ipairs(S.active)do
            local p=state.owner;local k=state.knife;local age=game:GetFrameCount()-state.start
            if k:Exists()then
                if not valid(p)or age>90 then k:Remove()
                elseif age>3 and method(k,'GetIsSwinging')and not k:GetIsSwinging()then k:Remove()
                else active[#active+1]=state end
            end
        end
        S.active=active
        -- A later mod may skip player AI; restore scoped input/delay even when
        -- its post-player callback was skipped. No fabricated fallback attack.
        for key,q in pairs(S.pending)do
            if q.scope then restore(q)end
            if not valid(q.owner)or game:GetFrameCount()>q.start+6 then S.pending[key]=nil end
        end
    end)
    local function clear()
        for _,q in pairs(S.pending)do restore(q)end
        for _,s in ipairs(S.active)do if s.knife:Exists()then s.knife:Remove()end end
        S.pending={};S.active={}
    end
    mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM,clear)
    mod:AddCallback(ModCallbacks.MC_POST_GAME_STARTED,clear)
    return S
end
