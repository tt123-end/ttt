from pathlib import Path
import shutil,xml.etree.ElementTree as E
T=Path('/workspace/hunter-fix-tools');O=Path('/workspace/deliverables167/zzzz_revolver_samson');P=Path('/workspace/deliverables168/zzzz_revolver_samson')
if not P.exists():shutil.copytree(O,P)
for n in ['compat','compat_eid','rules','sword','compat_items']:shutil.copy2(T/f'tainted_hunter_{n}168.lua',P/f'tainted_hunter_{n}.lua')
s=(O/'main.lua').read_text().replace('-- v1.67 - typed removal callbacks, original sword Spin and actual native light damage','-- v1.68 - native sword release, accepted damage teleport, Trisagion8x and Technology4x',1)
(P/'main.lua').write_text(s)
t=E.parse(O/'metadata.xml');t.getroot().find('version').text='1.68';t.getroot().find('description').text='v1.68: Real Spirit Sword charged weapon release; accepted reload damage including self-damage teleports; Trisagion8x actual hit damage; Technology400% panel hit damage. REPENTOGON / Repentance+ target.';t.write(P/'metadata.xml',encoding='utf-8',xml_declaration=True)
print('Built v1.68')
