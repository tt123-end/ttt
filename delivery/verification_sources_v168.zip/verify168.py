from pathlib import Path
import ctypes,json,xml.etree.ElementTree as E,re
T=Path('/workspace/hunter-fix-tools')
exec((T/'verify166.py').read_text().split("prefix='local MOD_ROOT='")[0])
D=Path('/workspace/deliverables168');P=D/'zzzz_revolver_samson';OLD=Path('/workspace/deliverables167/zzzz_revolver_samson')
prefix='local MOD_ROOT='+json.dumps(str(P))+'\n'
for p in P.glob('*.lua'):lua(p.read_text(),p.name)
for p in list(P.rglob('*.xml'))+list(P.rglob('*.anm2')):E.parse(p)
fixture=(T/'test_compat168.lua').read_text();lua(prefix+fixture,'v168_integrated',True)
header=fixture[:fixture.index('do\nlocal p=player({[373]=1});local t=nativeShot(p)')]
old='local MOD_ROOT="/workspace/deliverables167/zzzz_revolver_samson"\n'
lua(old+header+'''
local p=player({[579]=1});local k=C._testing.sword.attack(p,Vector(1,0))
assert(k and p:GetData().hunterNativeSword166~='original sword Spin animation unavailable','Observed native sword Spin unavailable')
''','v167_reported_native_spin_unavailable',True,'Observed native sword Spin unavailable')
lua(old+header+'''
local p=player({[316]=1});p.red=12;p.max=12;p.input=Vector(1,0);tick(p);p.input=Vector(0,0)
p:TakeDamage(.5,DamageFlag.DAMAGE_CURSED_DOOR,{},0);tick(p,2)
assert(p.teleports==1,'Cursed-door self-damage must teleport')
''','v167_excluded_curse_door',True,'Cursed-door self-damage must teleport')
lua(old+header+'''
local p=player({[68]=1});local l=entity(7,2,p);l.CollisionDamage=4.2;call(48,l)
local npc=entity(10);npc.HitPoints=1000
call(1248,l,npc);npc:TakeDamage(.7,0,EntityRef(p),0);call(1249,l,npc)
assert(math.abs(npc.HitPoints-(1000-16.8))<1e-6,'Technology actual player-source laser must be400% sheet')
''','v167_tech_collision_field_only',True,'Technology actual player-source laser must be400% sheet')
print('v167 fails reported missing sword clip, excluded cursed-door self-damage and cached/player-source Technology damage contracts; v168 passes')
# Actual uploaded integration APIs, numeric cap model and container exclusions.
prior=(T/'verify166.py').read_text();a=prior.index("statsRoot=");b=prior.index('preserved=0')
s=prior[a:b].replace("assert(text(533):find('16倍原生基础伤害'))", "assert(text(533):find('实际命中伤害为原版的8倍'))\nassert(text(68):find('400%%'))\nassert(text(316):find('包含刺门等自伤'))")
s=s.replace('eid_character_text_v166','eid_character_text_v168');exec(s)
changed={'tainted_hunter_compat.lua','tainted_hunter_compat_items.lua','tainted_hunter_sword.lua','tainted_hunter_rules.lua','tainted_hunter_compat_eid.lua','main.lua','metadata.xml','REPENTOGON_安装说明.md'}
preserved=0
for p in OLD.rglob('*'):
 if p.is_file()and p.name not in changed:
  assert p.read_bytes()==(P/p.relative_to(OLD)).read_bytes(),p
  if p.suffix in{'.png','.anm2'}:preserved+=1
sword=(P/'tainted_hunter_sword.lua').read_text()
for forbidden in ['MC_POST_RENDER','FindInRadius','TakeDamage(',':Shoot(',':FireKnife(',':SetIsSpinAttack(',':Play(']:assert forbidden not in sword,forbidden
assert not re.search(r'(?<![\w:])Sprite\(',sword)
new=(P/'tainted_hunter_compat.lua').read_text();old=(OLD/'tainted_hunter_compat.lua').read_text()
a='        if td.cSection165 and not td.aux163';b='        if td.trisagion164'
assert old[old.index(a):old.index(b,old.index(a))]==new[new.index(a):new.index(b,new.index(a))]
assert (OLD/'tainted_hunter_damage.lua').read_bytes()==(P/'tainted_hunter_damage.lua').read_bytes()
refs=T/'refs168'
callbacks=(refs/'docs_docs_enums_ModCallbacks.md').read_text();weapon=(refs/'repentogon_LuaInterfaces_LuaWeapon.cpp').read_text()
for name in ['MC_PRE_PLAYER_UPDATE','MC_POST_FIRE_SWORD','MC_POST_FIRE_TECH_LASER','MC_POST_ENTITY_TAKE_DMG']:assert name in callbacks,name
for name in ['GetWeaponType','GetMaxCharge','SetCharge','SetFireDelay','GetFireDelay']:assert'"'+name+'"'in weapon,name
report={'version':'1.68','target':'User now runs Repentance+ with REPENTOGON; APIs checked against official1.1.3 source','syntax_xml_anm2':'PASS','visual_assets_byte_identical':preserved,'accepted_mechanics':'PASS: prior chamber, grouped probabilistic Dead Eye, Chocolate replacement, quarter C Section, Stats+ and container-red/bone/payment exclusions','light_damage':'8x native actual light damage; half of user-confirmed16x path; exact collision/ExtraSource attribution unchanged','technology':'400% panel per primary Technology hit, with existing Chocolate curve when owned; actual damage override before observers, including Source=player and flags0; native straight one-hit laser and chamber gate; Brimstone/Tech X excluded','sword':'Actual primary Spirit Sword Weapon is charged, armed and released in scoped native player updates; only native POST_FIRE_SWORD spin entities accepted; no FireKnife, sprite replacement, Play(Spin), manual sweep damage or fake render','curse':'Accepted POST damage including all self-damage queues a native positive-seed random-room teleport; false damage/shields/Black Candle/non-reload/death guarded; cursed-door pending survives door room transition and waits for stable room; broken-heart exclusions unchanged','official_api_check':'PASS:1.1.3 callbacks and Weapon getters/setters source verified','local_regressions':'PASS: native weapon release contract, input/FireDelay/chamber restoration, native spin capture and hitbox retention; self-damage flags, curse-door room change, stable transition, source lifetime; actual laser8x/400% and source isolation; real uploaded EID/Stats+ APIs','game_runtime':'NOT RUN; no Isaac executable available. User confirmed v167 light damage working; new sword release/teleport/Tech changes still need in-game verification','limits':['Real native sword release scheduling and final animation must be confirmed in Isaac','If another item replaces the primary Spirit Sword weapon, the module reports unavailable instead of fabricating a slash; complex weapon-priority synergies need in-game validation','Rock Bottom and other previously documented native cap/source limitations remain']}
(D/'validation_v168.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('v168 verification complete: official API and logic contracts; no game runtime')
