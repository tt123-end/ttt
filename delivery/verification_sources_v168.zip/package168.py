from pathlib import Path
import zipfile,hashlib,shutil,json
from openpyxl import load_workbook
from openpyxl.styles import Alignment
T=Path('/workspace/hunter-fix-tools');D=Path('/workspace/deliverables168');P=D/'zzzz_revolver_samson'
readme='''# 猎手 v1.68：忏悔+／REPENTOGON反馈修正

本说明优先于包内历史版本说明。用户现已切换至忏悔+并启用REPENTOGON；本版以此为目标，所需接口已对照官方REPENTOGON1.1.3源码。本地没有Isaac运行环境，以下新增行为仍需游戏内确认。

## 本轮改动

英灵剑：用户hunterdiag已确认v1.67返回“original sword Spin animation unavailable”。普通FireKnife创建的实体没有原版Spin素材，过去把旋斩状态/动画写在这个实体上无法满足需求。v1.68不再调用FireKnife、不再手动Play(Spin)。实际出手后，为角色真实持有的Spirit Sword主武器安排一次原生蓄满释放：只在其原生玩家更新窗口内短暂提供朝向/松键输入及可发射状态，随后恢复输入和射击限制，不额外消耗弹药、不重新开始换弹。通过游戏的MC_POST_FIRE_SWORD接收真正的原生旋斩，原生负责素材、动画和碰撞。保护旋斩实体及其碰撞子刀；如果调用者在回调返回后才完成状态初始化，会等到实体首次更新再核对，避免误删。没有脚本范围挥砍、替代渲染、复制剑贴图或手动伤害。满血剑气保留。

这条原生释放路径仍需游戏验证。若主武器被其他道具替换而不再是Spirit Sword，诊断会明确显示主武器不可用，不用仿制挥砍代替。复杂武器优先级组合未在游戏逐一验证。

诅咒之眼：根据本轮补充，换弹期间的真实受伤应包含自伤。采用REPENTOGON实际受伤后的回调排队，不再用延迟血量比较与GetLastDamageFlags完全相等判定。非自伤和刺房门、献血机、恶魔乞丐、献祭、健康消耗等真实自伤均可触发；黑蜡烛仍阻止传送，假伤害和护盾取消的伤害不触发。原生蓄力传送仍被抑制，避免同一受伤重复传送。

刺门的受伤请求会保留到门后的房间，等待转场与玩家更新结束、房间稳定后再调用原生随机房间传送；不会在伤害回调或玩家更新中直接切房，不再借用主动道具使用链。使用正数随机种子，队列消费后才调用传送。其他换房、换层、死亡、失去道具或取得黑蜡烛会取消不再适用的请求。诅咒之眼的这条自伤传送规则与碎心惩罚完全独立：自伤不增加碎心的既有判定保持原文件不变。

三圣颂：保留用户已实测生效的实际光束命中增伤路径，倍率从16改成8，伤害减半。角色面板、原版光束单段比例与频率不变，EID同步。例如其他条件不变时，原生输入1.4的单段由22.4改为11.2；额外巧克力牛奶兼容增伤按原规则另算。

科技（道具68）：受控发射原生直线激光，遵守一发后换弹的机制；基础每次命中400%角色面板伤害。命中回调直接给出实际伤害，而不是仅改可能被原生缓存绕过的CollisionDamage字段，也不是在已400%的伤害上再乘4。基准面板4.2时为16.8；同时有巧克力牛奶时保留其额外倍率。支持精确碰撞归属和新版ExtraSource，阻止未授权的原生额外主激光。此次数值针对科技主攻击，不扩大到科技X环、硫磺火或其他辅助激光。

EID中英文同步科技400%、三圣颂8倍、诅咒之眼包含自伤。人物视觉资源、基本数值、Stats+、生命惩罚模块及剖腹产命中伤害削减保持既有版本。死亡之眼与专用巧克力牛奶的已确认规则保留。

## 安装与检查

完全退出游戏，将旧zzzz_revolver_samson移出mods备份，完整解压新包中的同名文件夹，只启用一份猎手。忏悔+通过对应REPENTOGON Launcher启动，不沿用普通忏悔1.0.12的DLL。先开测试局；不要求重新创建长期存档。

控制台hunterdiag应显示[Hunter v1.68] REPENTOGON=true。获得对应道具并使用后，还会报告：

- sword：原生武器排队、蓄满/释放、捕获到原生旋斩，或明确的失败阶段。
- cursed eye：受伤排队与随机传送请求。
- light：三圣颂实际incoming/applied伤害。
- technology：科技实际incoming/applied伤害。

如果英灵剑仍无动画，请发射一次后提供sword这一行；本版能区分真实武器不存在、未收到原生旋斩回调和原生旋斩已捕获。不要把“接口模型通过”当成游戏动画已经通过。

## 验证与范围

通过Lua5.4语法、XML/ANM2解析、实际上传的Stats+/EID接口执行、已有射速/生命/骨心/付款排除和兼容逻辑模型。新增原生武器蓄满释放契约、普通FireKnife缺少Spin素材的反馈复现、原生回调后初始化、输入/射击限制恢复、弹仓及换弹时间不被重复消耗；实际受伤后传送、自伤标记、刺门跨房延后、护盾/黑蜡烛/假伤害/死亡/换层保护；三圣颂8倍、科技实际400%、来源为玩家且伤害标记为0、取消伤害的静止靶观察及激光来源隔离。

没有运行Isaac。用户已确认v1.67三圣颂增伤生效；本轮新旋斩释放、传送与科技伤害仍需游戏确认。其他复杂第三方模组组合、武器优先级与此前磐石上限等限制未在本次逐项游戏验证。
'''
(D/'README_v168.md').write_text(readme);(P/'修复说明_v1.68.txt').write_text(readme)
shutil.copy2(D/'validation_v168.json',P/'validation_v168.json')
guide='''# 猎手v1.68：忏悔+与REPENTOGON

当前用户环境为忏悔+＋REPENTOGON，本版所需接口已核对官方1.1.3源码。官方Launcher负责匹配运行版本；不要把普通忏悔的1.0.12 DLL包混装到忏悔+。

- 官方Launcher：https://github.com/TeamREPENTOGON/Launcher/releases/latest
- 官方中文安装与存档迁移说明：https://github.com/TeamREPENTOGON/REPENTOGON/blob/1.1.3/docs/docs/install_zh.md
- 原生Weapon接口：https://github.com/TeamREPENTOGON/REPENTOGON/blob/1.1.3/docs/docs/Weapon.md
- 原生挥剑、受伤、激光回调：https://github.com/TeamREPENTOGON/REPENTOGON/blob/1.1.3/docs/docs/enums/ModCallbacks.md

猎手安装：完全退出游戏，备份移出旧模组文件夹，完整解压本包到mods，只保留一份启用版本。通过对应Launcher启动，在测试局输入hunterdiag，应显示[Hunter v1.68] REPENTOGON=true。

本版英灵剑改为真实主武器的原生蓄满释放，不再创建缺少Spin素材的普通飞刀实体。三圣颂沿用已确认的实际命中增伤链并改为8倍，科技主激光基础为400%面板伤害。诊断显示的是实际incoming/applied及原生释放阶段；历史v1.66说明中要求BaseDamage=67.2的检查已不适用。

本包不包含第三方DLL；本地验证是接口和逻辑模型，不是游戏实测结果。
'''
(D/'REPENTOGON_install_v168_zh.md').write_text(guide);(P/'REPENTOGON_安装说明.md').write_text(guide)
wb=load_workbook('/workspace/deliverables167/compatibility_implementation_v167.xlsx');ws=wb['说明与限制'];ws.delete_rows(1,ws.max_row)
for line in readme.splitlines():
 ws.append([line]);ws.cell(ws.max_row,1).alignment=Alignment(wrap_text=True,vertical='top');ws.row_dimensions[ws.max_row].height=max(22,min(180,len(line)//70*16+22))
for row in wb['实施对照'].iter_rows(min_row=2):
 key=str(row[1].value)
 if key=='579':row[4].value='v1.68反馈优先';row[5].value='真实英灵剑主武器满蓄力释放；保留满血剑气';row[6].value='原生Weapon蓄满/松键，接收MC_POST_FIRE_SWORD旋斩；不再FireKnife或手动Play(Spin)；输入/射击限制恢复';row[7].value='官方1.1.3接口与释放契约模型通过；仍需游戏确认'
 if key=='533':row[4].value='v1.68伤害减半';row[5].value='原版实际命中伤害8倍，沿用已确认生效的命中链';row[6].value='精确光束碰撞/ExtraSource归属；实际Damage覆盖倍率8；无重复结算';row[7].value='v1.67增伤已获用户实测确认；倍率8逻辑模型通过'
 if key=='316':row[4].value='v1.68补充：包含所有真实自伤';row[5].value='换弹期间真实伤害传送，包含刺门、献血等自伤；黑蜡烛阻止；碎心排除自伤的规则不变';row[6].value='实际POST受伤回调排队；刺门跨房等待稳定；原生随机房间传送；不保留EntityRef';row[7].value='真实/自伤/假伤害/护盾/刺门跨房/黑蜡烛模型通过；待实测'
 if key=='68':row[4].value='v1.68数值覆盖';row[5].value='科技主直线激光基础伤害400%角色面板；遵守换弹';row[6].value='受控原生FireTechLaser；精确碰撞/ExtraSource实际伤害覆盖；不影响科技X环和硫磺火';row[7].value='玩家来源/零标记/静止靶/换弹/其他激光隔离模型通过；待实测'
wb.save(D/'compatibility_implementation_v168.xlsx')
with zipfile.ZipFile(D/'verification_sources_v168.zip','w',zipfile.ZIP_DEFLATED)as out:
 names=['build168.py','verify168.py','test_compat168.lua','package168.py','verify166.py','test_stats161.lua','test_red_damage157.lua','test_bone_containers162_tail.lua','test_eid158.lua','test_compat_eid165.lua','eid_actual_api158.lua','eid_item_api163.lua']+['tainted_hunter_'+n+'168.lua'for n in ['compat','compat_items','compat_eid','rules','sword']]
 for n in names:out.write(T/n,n)
 out.writestr('OFFICIAL_REFERENCE_SOURCES.txt','\n'.join('https://raw.githubusercontent.com/TeamREPENTOGON/REPENTOGON/1.1.3/'+r for r in ['repentogon/LuaInterfaces/LuaWeapon.cpp','repentogon/LuaInterfaces/CustomCallbacks.cpp','repentogon/Patches/ASMPatches/ASMCallbacks.cpp','docs/docs/enums/ModCallbacks.md','docs/docs/Game.md'])+'\nLocal verification expects these under refs168 with slashes replaced by underscores. Old regression baselines and uploaded integration API fixtures require the referenced workspace paths. These are not game runtime tests.\n')
z=D/'hunter_v168.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as out:
 for p in sorted(P.rglob('*')):
  if p.is_file():out.write(p,p.relative_to(D))
with zipfile.ZipFile(z)as out:
 assert out.testzip()is None
 for p in P.rglob('*'):
  if p.is_file():assert out.read(str(p.relative_to(D)))==p.read_bytes()
 assert b':FireKnife('not in out.read('zzzz_revolver_samson/tainted_hunter_sword.lua')
 assert b'throughDoor' in out.read('zzzz_revolver_samson/tainted_hunter_compat_items.lua')
 count=len(out.namelist())
names=['hunter_v168.zip','README_v168.md','validation_v168.json','verification_sources_v168.zip','compatibility_implementation_v168.xlsx','REPENTOGON_install_v168_zh.md']
(D/'SHA256SUMS_v168.txt').write_text(''.join(hashlib.sha256((D/n).read_bytes()).hexdigest()+'  '+n+'\n'for n in names))
print(json.dumps({'files':count,'bytes':z.stat().st_size,'CRC':'PASS','byte_comparison':'PASS','publish':names},ensure_ascii=False,indent=2))
