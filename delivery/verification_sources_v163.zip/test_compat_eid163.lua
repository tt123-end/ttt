-- Executes uploaded EID registration functions; engine entities are fixtures.
local callbacks={};ModCallbacks={MC_POST_UPDATE=1}
local mod={AddCallback=function(_,id,fn)callbacks[id]=callbacks[id]or{};table.insert(callbacks[id],fn)end}
EID={DescModifiers={},FullyAutomatedDescriptions={},ItemNames={zh_cn={},en_us={}},descriptions={zh_cn={},en_us={}},DefaultLanguageCode='en_us',Config={Language='zh_cn'}}
assert(loadfile(ACTUAL_API))();assert(loadfile(ACTUAL_ITEM_API))()
Isaac={GetItemIdByName=function()return 9001 end}
local p={kind=20,items={}}
function p:GetPlayerType()return self.kind end
function p:HasCollectible(id)return self.items[id]or false end
EID.player=p
assert(loadfile(MOD_ROOT..'/tainted_hunter_compat_eid.lua'))()(mod,20)
assert(#EID.DescModifiers==1)
local modifier=EID.DescModifiers[1]
for _,id in ipairs({52,69,114,118,168,229,316,395,556,579,678,352,149,533,104,150,154,237,331,398,429,443,503,637,619})do
 local desc={ObjType=5,ObjVariant=100,ObjSubType=id,Description='native'}
 assert(modifier.condition(desc));assert(modifier.callback(desc).Description~='native')
end
local desc={ObjType=5,ObjVariant=100,ObjSubType=619}
assert(modifier.callback(desc).Description:find('20%%'))
p.items[52]=true;p.items[149]=true;desc.ObjSubType=52
assert(modifier.callback(desc).Description:find('0.6',1,true))
EID.Config.Language='en_us';assert(modifier.callback(desc).Description:find('explosion immunity'))
p.kind=10;assert(not modifier.condition(desc));p.kind=20
assert(EID.descriptions.zh_cn.custom['5.100.9001'][3]:find('1.5',1,true))
for i=1,5 do for _,fn in ipairs(callbacks[1])do fn(mod)end end
assert(#EID.DescModifiers==1)
print('Uploaded EID item API passed:25 localized overrides, character isolation, combo wording, replacement token and idempotent install')
