from pathlib import Path
import ctypes,json,xml.etree.ElementTree as E
D=Path('/workspace/deliverables163');P=D/'zzzz_revolver_samson';OLD=Path('/workspace/deliverables162/zzzz_revolver_samson');T=Path('/workspace/hunter-fix-tools')
lib=ctypes.CDLL('liblua5.4.so.0');lib.luaL_newstate.restype=ctypes.c_void_p
lib.luaL_loadbufferx.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_size_t,ctypes.c_char_p,ctypes.c_char_p]
lib.lua_tolstring.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_void_p];lib.lua_tolstring.restype=ctypes.c_char_p
lib.lua_close.argtypes=[ctypes.c_void_p];lib.luaL_openlibs.argtypes=[ctypes.c_void_p]
lib.lua_pcallk.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_longlong,ctypes.c_void_p]
def lua(source,label,execute=False):
 data=source.encode();st=lib.luaL_newstate();lib.luaL_openlibs(st)
 assert lib.luaL_loadbufferx(st,data,len(data),label.encode(),None)==0,(label,lib.lua_tolstring(st,-1,None))
 if execute:assert lib.lua_pcallk(st,0,0,0,0,None)==0,(label,lib.lua_tolstring(st,-1,None))
 lib.lua_close(st)
prefix='local MOD_ROOT='+json.dumps(str(P))+'\n'
for p in P.glob('*.lua'):lua(p.read_text(),p.name)
for p in list(P.rglob('*.xml'))+list(P.rglob('*.anm2')):E.parse(p)
lua(prefix+(T/'test_compat163.lua').read_text(),'integrated_compatibility163',True)
statsRoot='/workspace/reference-stats-plus154/stats-plus_2729900570'
stats=(T/'test_stats161.lua').read_text()
stats+='''
mod.HunterCompat163={rules={blastCombo=function(p)return p:HasCollectible(52)and p:HasCollectible(149)end},flatDamage=function()return 1.5 end}
p.items[562]=nil;p.items[52]=1;p.items[149]=1;p.a=5;p.b=20;p.tearsBonus=0;settle(p)
approx(p.data.hunterTears161.capRate,.6);approx(p.Damage,6)
print('v163 forced-cap0.6 and +1.5-before-x1.2 damage passed')
'''
lua(prefix+'local OLD_ROOT="/workspace/deliverables160/zzzz_revolver_samson"\nlocal STATS_ROOT='+json.dumps(statsRoot)+'\n'+stats,'uploaded_stats_api_and_numeric_regression',True)
damage=(T/'test_red_damage157.lua').read_text()
damage=damage.replace(' function p:GetMaxHearts()return self.max end',' function p:GetMaxHearts()return self.max end\n function p:GetBoneHearts()return self.bone end',1)
damage=damage.replace('self.red=math.min(self.red,self.max)','self.red=math.min(self.red,self.max+self.bone*2)',1)
damage=damage.replace('local p=player(20,2,4);p.bone=1;p:TakeDamage(5,0,enemy,30);assert(p.red==1 and p.broken==1)',"local p=player(20,2,0);p.max=0;p.bone=1;p:TakeDamage(1,0,enemy,30);assert(p.red==1 and p.broken==0)",1)
lua(prefix+damage+'\n'+(T/'test_bone_containers162_tail.lua').read_text(),'red_damage_and_bone_regression',True)
eid=(T/'test_eid158.lua').read_text().replace('800%%','400%%')
eidprefix=prefix+'local ACTUAL_API='+json.dumps(str(T/'eid_actual_api158.lua'))+'\nlocal TEXT_ARTIFACT='+json.dumps(str(D/'eid_character_text_v163.txt'))+'\n'
lua(eidprefix+eid,'uploaded_character_eid_api',True)
lua(eidprefix+'local ACTUAL_ITEM_API='+json.dumps(str(T/'eid_item_api163.lua'))+'\n'+(T/'test_compat_eid163.lua').read_text(),'uploaded_item_eid_api',True)
preserved=0
for p in OLD.rglob('*'):
 if p.is_file()and p.suffix in {'.png','.anm2'}:
  assert p.read_bytes()==(P/p.relative_to(OLD)).read_bytes(),p
  preserved+=1
assert (OLD/'tainted_hunter_damage.lua').read_bytes()==(P/'tainted_hunter_damage.lua').read_bytes()
oldMain=(OLD/'main.lua').read_text();newMain=(P/'main.lua').read_text()
assert oldMain.split('local taintedStats = include')[0].splitlines()[1:]==newMain.split('mod.HunterCompat163 = include')[0].splitlines()[1:]
report={'version':'1.63','workbook_decision_rows':1497,'custom_decision_rows':39,'lua_syntax_files':len(list(P.glob('*.lua'))),'xml_anm2':'PASS','integrated_compatibility':'PASS: deterministic engine-contract model, not game runtime','stats_plus':'PASS: uploaded cap function/display, validators and multiplier middleware; baseline210 monotonic cases; explicit Dr Fetus+Ipecac cap0.6','damage':'PASS: prior red-heart/payment/shield cases plus dedicated bone-container regressions; damage module byte-identical to v162','eid':'PASS: uploaded character API and item modifier/collectible registration API;25 localized item overrides','visual_assets_preserved':preserved,'game_runtime':'NOT RUN; no Isaac executable available','known_limits':['Rock Bottom: no safe exact readonly native-cap API in vanilla; sampling disabled and last safe cap reference retained, Stats+ may show UNKNOWN','Godhead aura attribution, native fetal knives/spin collision, active/auxiliary source timing and complex combinations need in-game validation','Default rows generally delegate native behavior through shared adapters; this is not721 individually game-tested items']}
(D/'validation_v163.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('Integrated checks completed')
