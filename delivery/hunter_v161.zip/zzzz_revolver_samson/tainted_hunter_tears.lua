-- v1.61: use an observed native tears cap, never guessed weapon multipliers.
local tears = {}

function tears.softCap(nativeCapRate, stats)
    local ratio = math.max(0, nativeCapRate) / 5
    if ratio >= 1 then return stats.softCap * ratio end
    return stats.minimumSoftCap + (stats.softCap - stats.minimumSoftCap) * ratio
end

function tears.calculate(incomingDelay, nativeCapDelay, stats)
    local nativeCapRate = 30 / math.max(0.001, nativeCapDelay + 1)
    local cap = tears.softCap(nativeCapRate, stats)
    -- Plain Isaac: native delay10, native cap delay5. Anchor those points to
    -- the requested starting2.4*x0.2=0.48 and ordinary maximum1, respectively.
    -- Preserve the *distance in delay* to the measured cap instead of dividing
    -- the incoming rate by an assumed penalty (the v160 overcompensation).
    local initialRate = stats.baseTears * stats.tearsMultiplier
    local stretch = (30 / initialRate - 30 / stats.softCap) / 5
    local remainingDelay = incomingDelay - nativeCapDelay
    if remainingDelay >= 0 then
        return 30 / (30 / cap + stretch * remainingDelay), cap
    end
    -- Keep boosts above the observed cap, including effects acquired before
    -- the next probe. Do not turn either1 or0.6 into a hard rate clamp.
    local nativeRate = 30 / math.max(0.001, incomingDelay + 1)
    return cap + (nativeRate - nativeCapRate) * stats.tearsMultiplier, cap
end

return tears
