-- v1.61: native cap sampling, derived from uploaded Stats+'s Tear Cap method.
-- No REPENTOGON required. Only extra temporary copies of a pure tears-up are
-- added; owned weapons/penalty items, health and active slots are never removed.
return function(mod, playerType, stats, tears)
    local game = Game()
    local PROBE_ITEM = 32 -- Wire Coat Hanger: ordinary tears up, no health/charges.
    local MAX_PROBES = 48
    local BASIC_UPS = {[1]=true,[6]=true,[32]=true,[183]=true,[255]=true,[564]=true,[120]=true}
    local itemCount
    local function isHunter(p)
        return p and playerType ~= -1 and p:GetPlayerType() == playerType
    end
    local function state(p)
        local data = p:GetData()
        if not data.hunterTears161 then
            data.hunterTears161 = {capDelay=5, pending=true}
        end
        return data.hunterTears161
    end
    local function signature(p)
        if not itemCount then itemCount = Isaac.GetItemConfig():GetCollectibles().Size end
        local parts = {}
        local effects = p:GetEffects()
        for id=1,itemCount-1 do
            if not BASIC_UPS[id] then
                local n = p:GetCollectibleNum(id,true)
                local e = effects:GetCollectibleEffectNum(id)
                if n ~= 0 or e ~= 0 then parts[#parts+1]=id..":"..n..":"..e end
            end
        end
        parts[#parts+1]="t:"..p:GetTrinket(0)..":"..p:GetTrinket(1)
        return table.concat(parts,";")
    end
    local function debug(message)
        if Isaac.DebugString then Isaac.DebugString("[Tainted Hunter tears] "..message) end
    end
    local function evaluate(p, nativeDelay)
        local d = state(p)
        d.rawDelay = nativeDelay
        if d.probing then return nil end
        if not d.restoring then
            local key = signature(p)
            if key ~= d.key then d.pending=true;d.contextChanged=true end
            -- Refresh dynamic native effects without repeatedly probing during
            -- Stats+'s synchronous temporary-add/remove cap measurements.
            d.dynamicPending = d.baselineDelay and math.abs(nativeDelay-d.baselineDelay)>0.0001 or false
        end
        local capDelay=d.capDelay
        -- Removing a penalty can make the previously measured cap obsolete.
        -- Avoid treating that one transitional cache as a cap-breaking boost.
        if d.contextChanged and nativeDelay<capDelay then capDelay=5 end
        local rate,cap = tears.calculate(nativeDelay,capDelay,stats)
        d.currentRate=rate;d.capRate=cap
        return rate
    end
    local function refresh(p)
        p:AddCacheFlags(CacheFlag.CACHE_FIREDELAY)
        p:EvaluateItems()
    end
    local function sample(p,d)
        -- Probing with Rock Bottom could permanently raise its stored stat.
        -- Stats+ also refuses native cap probing in that case.
        local effects=p:GetEffects()
        if p:HasCollectible(562) or effects:HasCollectibleEffect(562) then
            d.pending=false;d.contextChanged=false;d.key=signature(p)
            d.dynamicPending=false;d.sampleFrame=game:GetFrameCount();d.baselineDelay=d.rawDelay
            return
        end
        local owned = p:GetCollectibleNum(PROBE_ITEM,true)
        local originalDelay = p.MaxFireDelay
        d.probing=true
        local capDelay
        local ok,err=pcall(function()
            local previous
            for i=1,MAX_PROBES do
                d.rawDelay=nil
                p:AddCollectible(PROBE_ITEM,0,false)
                assert(p:GetCollectibleNum(PROBE_ITEM,true)==owned+i,"native probe item was not added")
                if d.rawDelay==nil then refresh(p) end
                local current=assert(d.rawDelay,"native fire-delay cache was not observed")
                if previous and math.abs(previous-current)<0.000001 then capDelay=current;break end
                previous=current
            end
            assert(capDelay,"native cap did not converge within probe limit")
        end)
        -- Cleanup uses actual inventory counts even if AddCollectible raised
        -- after inserting an item. Never remove an original owned copy.
        local cleaned,cleanupError=pcall(function()
            for i=1,MAX_PROBES+1 do
                if p:GetCollectibleNum(PROBE_ITEM,true)<=owned then break end
                p:RemoveCollectible(PROBE_ITEM,true)
            end
            assert(p:GetCollectibleNum(PROBE_ITEM,true)==owned,"probe inventory cleanup failed")
        end)
        d.probing=false
        if ok and cleaned then d.capDelay=capDelay;d.valid=true end
        d.pending=false;d.contextChanged=false;d.key=signature(p)
        d.dynamicPending=false
        d.sampleFrame=game:GetFrameCount()
        d.restoring=true
        local restored,restoreError=pcall(refresh,p)
        d.restoring=false
        d.baselineDelay=d.rawDelay
        if not ok then debug("sampling failed: "..tostring(err)) end
        if not cleaned then debug("cleanup failed: "..tostring(cleanupError)) end
        if not restored then debug("cache restoration failed: "..tostring(restoreError).."; previous delay "..tostring(originalDelay)) end
    end
    mod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE,function(_,p)
        if not isHunter(p) or p:IsDead() or p:IsCoopGhost() then return end
        local d=state(p)
        local dynamic=d.dynamicPending and d.sampleFrame and game:GetFrameCount()-d.sampleFrame>=90
        if (d.pending or dynamic) and not d.probing then sample(p,d) end
    end)
    mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM,function()
        for i=0,game:GetNumPlayers()-1 do
            local p=Isaac.GetPlayer(i)
            if isHunter(p) then local d=state(p);d.pending=true;d.contextChanged=true end
        end
    end)
    mod:AddCallback(ModCallbacks.MC_POST_GAME_STARTED,function()
        for i=0,game:GetNumPlayers()-1 do
            local p=Isaac.GetPlayer(i)
            if isHunter(p) then local d=state(p);d.pending=true;d.contextChanged=true end
        end
    end)
    return {evaluate=evaluate}
end
