from pathlib import Path
import shutil,zipfile,hashlib,json
T=Path('/workspace/hunter-fix-tools');D=Path('/workspace/deliverables170');P=D/'zzzz_revolver_samson'
readme='''# 猎手 Hunter — v1.70

基于已确认的v1.69精简包。本版只调整里猎手指定道具的属性与相关飞刀效果，保留当前人物/UI和其他已确认机制。需要当前忏悔+对应的REPENTOGON。

## 射速规则

取消原先的负射速倍率补偿，不再有趋近0.6的保底，也取消吐根＋胎儿博士固定0.6上限。固有射速倍率仍为×0.2；初始无道具数值仍为射速0.48、普通上限1、面板伤害4.2、弹速1.6、射程12。

下表中的道具不再施加其原生射速修正降低；没列出的其他道具按原规则结算，不享受原先的负倍率补偿。旧射速补偿/采样模块已从精简包删除。

| 道具 | 新属性与效果 |
|---|---|
| 内眼 | 保留当前三发，伤害×0.5 |
| 变异蜘蛛 | 保留当前四发，伤害×0.42 |
| 科技2 | 保留当前攻击，伤害倍率改为×0.75，不额外叠加原生降伤 |
| 巨人独眼 | 替换原生伤害加成，仅+8基础攻击力；无原生伤害倍率；飞刀获得真正穿透，移除原先剩余伤害型伪穿透 |
| 萌死戳的肺 | 当前散弹方式保留，伤害×0.23 |
| 夏娃的睫毛膏 | 仅伤害×1.35，取消原生×2及弹速降低；改为弹速上限2 |
| 硫磺火 | 当前飞刀＋硫磺火攻击与伤害兼容保留，仅取消原生射速惩罚 |
| 胎儿博士 | 当前飞刀/爆炸方式保留，伤害×0.8；主刀基础仍为400%面板，爆炸仍为2×面板＋30 |
| 吐根 | 当前直线飞刀/命中爆炸保留，移除原生+40面板攻击力；主刀和爆炸均为2×面板＋40 |
| 泪血症 | 当前攻击方式保留；替换原生伤害加成，改为+3基础攻击力，不叠加原生1.5倍伤害 |

伤害倍率按每种道具是否生效计算一次。基础攻击力加值进入伤害加法阶段，再按角色及其他道具倍率结算；例如单独持有巨人独眼、无其他增伤时是(3.5+8)×1.2=13.8面板伤害，单独泪血症为(3.5+3)×1.2=7.8。额外副本/临时效果的基础加值按数量计算；倍率不因同一种道具额外副本重复叠乘。

## 已确认的组合规则

- 内眼、变异蜘蛛、萌死戳的肺任意组合只取最低伤害倍率。三者同时拥有时为×0.23，不把×0.5、×0.42、×0.23叠乘；与这组无关的倍率正常相乘。
- 有完美视力时取消上述三种道具的伤害惩罚；完美视力本身的原生×0.8仍保留。
- 同时有完美视力与巨人独眼时，完美视力的原生×0.8也取消。
- 同时有吐根与胎儿博士时，保留爆炸免疫，取消博士×0.8，主刀与爆炸均为2×面板＋40，不额外加博士的30。
- 巨人独眼的真穿透会作用于飞刀及其相关分裂弹。带爆炸的真穿透飞刀命中敌人后仍继续飞行，沿用现有单次爆炸记录，避免同一飞刀重复引爆；墙体/射程处理保持原规则。

以上为基础伤害公式；巧克力牛奶等其他已确认兼容的额外作用继续按原规则结算。

## 显示与安装

Stats+的原生伤害倍率条目已替换为新规则，包含最低散射倍率、完美视力与巨人独眼例外，避免原生倍率和新倍率重复显示。保留射速×0.2显示并修正受影响的射速上限显示。EID角色特性及相关道具中英文说明同步。

完全退出游戏，先把旧zzzz_revolver_samson文件夹移出mods备份，再完整解压本包同名文件夹，只启用一份猎手。完整替换会移除旧的射速补偿文件；不要删除游戏data目录或自己的存档。通过匹配忏悔+的REPENTOGON Launcher启动，先开测试局，hunterdiag应显示[Hunter v1.70] REPENTOGON=true，并报告当前伤害、道具倍率、射速、上限及弹速。

REPENTOGON官方Launcher：https://github.com/TeamREPENTOGON/Launcher/releases/latest
官方安装/存档说明：https://github.com/TeamREPENTOGON/REPENTOGON/blob/1.1.3/docs/docs/install_zh.md

## 验证与实现范围

运行代码保留真实道具及原有武器效果，不通过移除/重新发放所持道具来替换数值。仅在同步数值重算期间隔离指定原生属性，保留临时效果对象与冷却，并在结束或异常后恢复道具屏蔽状态、效果数量和缓存设置；不在该期间推进游戏帧或重建武器。

已通过Lua5.4语法、XML/ANM2及资源依赖检查；十种道具单独持有/临时效果、散射道具七种组合、完美视力与巨人独眼、吐根与博士、弹速上限、未知射速惩罚不再保底、数值隔离异常恢复检查；执行了实际上传Stats+/EID的校验器、倍率计算和显示接口；保留并执行原有死亡之眼、巧克力牛奶、剖腹产、英灵剑、科技、诅咒之眼和红心/骨心/付血排除的逻辑回归。人物贴图、动画、换弹、受伤规则、英灵剑及诅咒之眼模块与v1.69精简版逐字节一致。

本机没有Isaac运行环境，上述为接口/数值/状态模型检查，不能代替游戏实测。原生武器属性计算、临时效果、磐石历史属性锁定及第三方MOD同步改动缓存/物品的组合，需要游戏确认；少数未列出的特殊前置射速公式的上限显示也需实测。若数值异常，提供当前道具组合、面板及hunterdiag输出即可定位。
'''
(P/'README.md').write_text(readme);(D/'README_v170.md').write_text(readme)
# Keep the installable package clean: validation and development sources are
# separate artifacts, never historical files inside the mod.
with zipfile.ZipFile(D/'verification_sources_v170.zip','w',zipfile.ZIP_DEFLATED)as out:
 names=['build170.py','verify170.py','package170.py','test_stats170.lua','test_compat170.lua','test_eid170.lua','test_compat_eid170.lua','verify166.py','test_red_damage157.lua','test_bone_containers162_tail.lua','eid_actual_api158.lua','eid_item_api163.lua']+['tainted_hunter_'+x+'170.lua'for x in ['balance','stats','stats_plus','rules','compat','compat_eid','eid']]
 for n in names:out.write(T/n,n)
 out.writestr('REFERENCE_CONTEXT.txt','These are Lua/interface contract tests, not a running Isaac game. Tests refer to the uploaded Stats+/EID and accepted clean baseline at workspace paths. Official REPENTOGON1.1.3 API sources: https://github.com/TeamREPENTOGON/REPENTOGON/tree/1.1.3 .\n')
z=D/'hunter_v170.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as out:
 for p in sorted(P.rglob('*')):
  if p.is_file():out.write(p,p.relative_to(D))
with zipfile.ZipFile(z)as out:
 assert out.testzip()is None
 for p in P.rglob('*'):
  if p.is_file():assert out.read(str(p.relative_to(D)))==p.read_bytes()
 assert not any(any(x in name for x in ['validation_v','修复说明_','geometry_','tears_probe.lua'])for name in out.namelist())
 count=len(out.namelist())
manifest={'version':'1.70','baseline':'v1.69 clean','files':count,'zip_bytes':z.stat().st_size,'zip_crc':'PASS','byte_comparison':'PASS','historical_files_in_mod':False,'lua_files':len(list(P.glob('*.lua'))),'removed_modules':['tainted_hunter_tears.lua','tainted_hunter_tears_probe.lua']}
(D/'package_manifest_v170.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
names=['hunter_v170.zip','README_v170.md','validation_v170.json','package_manifest_v170.json','verification_sources_v170.zip']
(D/'SHA256SUMS_v170.txt').write_text(''.join(hashlib.sha256((D/n).read_bytes()).hexdigest()+'  '+n+'\n'for n in names))
print(json.dumps(manifest,ensure_ascii=False,indent=2))
