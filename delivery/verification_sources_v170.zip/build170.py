from pathlib import Path
import shutil,xml.etree.ElementTree as E
T=Path('/workspace/hunter-fix-tools');O=Path('/workspace/deliverables169_clean/zzzz_revolver_samson');D=Path('/workspace/deliverables170');P=D/'zzzz_revolver_samson'
if not P.exists():shutil.copytree(O,P)
for name in ['balance','stats','stats_plus','rules','compat','compat_eid','eid']:shutil.copy2(T/f'tainted_hunter_{name}170.lua',P/f'tainted_hunter_{name}.lua')
for name in ['tainted_hunter_tears.lua','tainted_hunter_tears_probe.lua']:
 if(P/name).exists():(P/name).unlink()
s=(O/'main.lua').read_text();s=s.replace(s.splitlines()[0],'-- v1.70 - selected item stat replacements; no tears penalty compensation',1);(P/'main.lua').write_text(s)
t=E.parse(O/'metadata.xml');t.getroot().find('version').text='1.70';t.getroot().find('description').text='v1.70: Tainted Hunter selected native stat penalties replaced; multishot minimum rule,20/20 synergies, Polyphemus true piercing and new explosive formulas. Clean package based on accepted v1.69.';t.write(P/'metadata.xml',encoding='utf-8',xml_declaration=True)
print('Built clean v1.70')
