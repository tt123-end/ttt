from pathlib import Path
import ctypes,json,re,xml.etree.ElementTree as E,hashlib
T=Path('/workspace/hunter-fix-tools')
exec((T/'verify166.py').read_text().split("prefix='local MOD_ROOT='")[0])
D=Path('/workspace/deliverables170');P=D/'zzzz_revolver_samson';OLD=Path('/workspace/deliverables169_clean/zzzz_revolver_samson')
prefix='local MOD_ROOT='+json.dumps(str(P))+'\n'
for p in P.glob('*.lua'):lua(p.read_text(),p.name)
for p in list(P.rglob('*.xml'))+list(P.rglob('*.anm2')):E.parse(p)
lua(prefix+'local STATS_ROOT="/workspace/reference-stats-plus154/stats-plus_2729900570"\n'+(T/'test_stats170.lua').read_text(),'v170_numeric_and_uploaded_stats_plus',True)
lua(prefix+(T/'test_compat170.lua').read_text(),'v170_combat_and_prior_compatibility',True)
# The existing red-container/bone/shield/payment suite, unchanged damage module.
s=(T/'test_red_damage157.lua').read_text().replace(' function p:GetMaxHearts()return self.max end',' function p:GetMaxHearts()return self.max end\n function p:GetBoneHearts()return self.bone end',1).replace('self.red=math.min(self.red,self.max)','self.red=math.min(self.red,self.max+self.bone*2)',1).replace('local p=player(20,2,4);p.bone=1;p:TakeDamage(5,0,enemy,30);assert(p.red==1 and p.broken==1)',"local p=player(20,2,0);p.max=0;p.bone=1;p:TakeDamage(1,0,enemy,30);assert(p.red==1 and p.broken==0)",1)
lua(prefix+s+'\n'+(T/'test_bone_containers162_tail.lua').read_text(),'unchanged_red_bone_payment_rules',True)
eidprefix=prefix+'local ACTUAL_API='+json.dumps(str(T/'eid_actual_api158.lua'))+'\nlocal TEXT_ARTIFACT='+json.dumps(str(D/'eid_character_text_v170.txt'))+'\n'
lua(eidprefix+(T/'test_eid170.lua').read_text(),'v170_actual_character_eid_api',True)
lua(eidprefix+'local ACTUAL_ITEM_API='+json.dumps(str(T/'eid_item_api163.lua'))+'\n'+(T/'test_compat_eid170.lua').read_text(),'v170_actual_item_eid_api',True)
# Clean package baseline: no old histories return, no graphics or existing
# stable mechanics are altered by this numerical policy change.
changed={'README.md','main.lua','metadata.xml','tainted_hunter_stats.lua','tainted_hunter_stats_plus.lua','tainted_hunter_rules.lua','tainted_hunter_compat.lua','tainted_hunter_compat_eid.lua','tainted_hunter_eid.lua'}
removed={'tainted_hunter_tears.lua','tainted_hunter_tears_probe.lua'}
visual=0
for p in OLD.rglob('*'):
 if not p.is_file():continue
 if p.name in removed:assert not(P/p.relative_to(OLD)).exists();continue
 if p.name not in changed:assert p.read_bytes()==(P/p.relative_to(OLD)).read_bytes(),p
 if p.suffix in{'.png','.anm2'}:visual+=1
assert len(list(P.glob('*.lua')))==16
assert (P/'main.lua').read_text().splitlines()[1:]==(OLD/'main.lua').read_text().splitlines()[1:]
for p in P.rglob('*'):
 if p.is_file()and p.suffix in{'.xml','.anm2'}:E.parse(p)
# Validate every packaged ANM2 sheet resolves to a retained custom resource or
# the same builtin ghost sheet as the accepted clean baseline.
files={p.relative_to(P).as_posix().lower():p for p in P.rglob('*')if p.is_file()}
import posixpath
for p in P.rglob('*.anm2'):
 rel=p.relative_to(P).as_posix()
 for sheet in E.parse(p).findall('.//Spritesheet'):
  target=posixpath.normpath(posixpath.join(posixpath.dirname(rel),sheet.get('Path'))).lower()
  assert target in files or target=='resources/gfx/characters/costumes/ghost.png',(p,target)
for p in P.glob('*.lua'):
 for module in re.findall(r'''include\(["']([^"']+)["']\)''',p.read_text()):assert(P/(module+'.lua')).exists(),module
refs=T/'refs170'
source=(refs/'repentogon_Patches_ItemSpoofSystem.cpp').read_text()
assert 'void ItemSpoof::Block' in source and 'player.AddCacheFlags(item->cacheFlags)'in source
stage=(refs/'docs_docs_enums_EvaluateStatStage.md').read_text()
assert 'TEARS_UP'in stage and 'FLAT_DAMAGE'in stage
api=(refs/'docs_docs_EntityPlayer.md').read_text()
for name in ['BlockCollectible','UnblockCollectible','IsCollectibleBlocked','GetTearsCap','SetRockBottomDamage','SetRockBottomMaxFireDelay','SetRockBottomShotSpeed']:assert name in api,name
report={'version':'1.70','baseline':'v1.69 clean; no historical resources reintroduced','syntax_xml_anm2':'PASS','visual_assets_byte_identical':visual,'stable_modules_preserved':['inventory/cursed-eye self-damage/door teleport','sword','combat/reload/HUD','red-container/bone/broken-heart rules','normal character mechanics','all PNG/ANM2 resources'],'numeric_contracts':'PASS: ten native stat replacements; varied native penalty factors; seven group subsets;20/20 group cancellation and Polyphemus cancellation of20/20; Dr+Ipecac exception; temporary effect count/cooldown restored; config masks and item blocks restored on success/error; no inventory/health/weapon cache mutation','combat_contracts':'PASS: Ipecac and Dr+Ipecac knives/explosions2D+40; standalone Dr original4D knife and2D+30 explosion; Polyphemus real piercing/root/descendant/update flags; prior Dead Eye, Chocolate, C Section, sword, Technology and curse compatibility','stats_plus':'PASS: real uploaded validation and middleware; native damage multiplier computables + all new rules; native cap computable correction and stat restoration; other characters unchanged','eid':'PASS: real uploaded character/item APIs; bilingual values/group exceptions/explosion formula/no compensation text','removed_mechanism':'Old tears penalty probe/calculation modules deleted; no0.6 floor or combined forced0.6 cap; native tears2.4 then character x0.2, unlisted penalty contract demonstrated below0.6','numeric_implementation':'Selected effects masked only during synchronous numeric recalculation outside cache callback; item config cache flags quieted to prevent weapon rebuilds; owned items never removed, TemporaryEffect objects/cooldowns retained; native masks restored before any gameplay resumes','official_api':'Checked against official REPENTOGON1.1.3 stat-stage, spoof/block and player APIs','game_runtime':'NOT RUN; no Isaac executable. These are interface/state/math contracts, not proof of native game behavior','limits':['Requires REPENTOGON stat stages/block APIs; ordinary no-REPENTOGON mode is not this release target','Native weapons, temporary effects, Rock Bottom history locks and third-party mods that synchronously change inventories during cache callbacks need in-game verification','Soft-cap display is derived from native stat stages; exotic pre-multiplier affine modifiers outside the changed list need in-game validation']}
(D/'validation_v170.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('v170 verification complete: clean dependency closure, unchanged stable modules, new stats/combat and actual uploaded integrations; no game runtime')
