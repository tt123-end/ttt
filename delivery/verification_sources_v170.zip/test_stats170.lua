-- Native cache/BlockCollectible contracts, not an Isaac runtime.
local callbacks={};local players={};local frame=100
ModCallbacks={MC_EVALUATE_STAT=1226,MC_EVALUATE_CACHE=8,MC_POST_PLAYER_INIT=9,MC_POST_GAME_STARTED=15,MC_POST_PLAYER_UPDATE=31,MC_POST_PEFFECT_UPDATE=4,MC_PRE_PLAYER_UPDATE=1160}
CacheFlag={CACHE_SPEED=1,CACHE_FIREDELAY=2,CACHE_DAMAGE=4,CACHE_SHOTSPEED=8,CACHE_RANGE=16,CACHE_WEAPON=256}
EvaluateStatStage={TEARS_UP=0,FLAT_TEARS=1,DAMAGE_UP=2,FLAT_DAMAGE=3,PRE_FLAT_DAMAGE=4}
REPENTOGON={}
local mod={};local configs={}
for id=1,1000 do configs[id]={CacheFlags=2|4|8|256}end
local function call(id,...)
 local args={...};local result
 table.sort(callbacks[id]or{},function(a,b)return a.priority<b.priority end)
 for _,entry in ipairs(callbacks[id]or{})do
  local r=entry.fn(mod,table.unpack(args))
  if id==1226 and type(r)=='number'then args[3]=r;result=r end
 end
 return result or(id==1226 and args[3])
end
function mod:AddCallback(id,fn)callbacks[id]=callbacks[id]or{};table.insert(callbacks[id],{fn=fn,priority=0})end
function mod:AddPriorityCallback(id,priority,fn)self:AddCallback(id,fn);callbacks[id][#callbacks[id]].priority=priority end
function mod:RemoveCallback(id,fn)for i=#(callbacks[id]or{}),1,-1 do if callbacks[id][i].fn==fn then table.remove(callbacks[id],i)end end end
local function approx(a,b)assert(math.abs(a-b)<1e-7,tostring(a)..' ~= '..tostring(b))end
local function player(items,kind)
 local p={kind=kind or 20,Index=#players,items=items or{},effects={},blocks={},data={},flags=0,Damage=3.5,MaxFireDelay=10,ShotSpeed=1,MoveSpeed=1,TearRange=260,added=0,removed=0,weaponRebuilds=0,health=12}
 function p:Exists()return true end;function p:IsDead()return false end;function p:GetData()return self.data end;function p:GetPlayerType()return self.kind end
 function p:IsCollectibleBlocked(id)return self.blocks[id]or false end
 function p:GetCollectibleNum(id,ignore,ignoreSpoof)if self.blocks[id]and not(ignore or ignoreSpoof)then return 0 end;return self.items[id]or 0 end
 function p:HasCollectible(id,ignore,ignoreSpoof)if self.blocks[id]and not(ignore or ignoreSpoof)then return false end;return(self.items[id]or 0)>0 end
 function p:GetEffects()
  local e={}
  function e:GetCollectibleEffectNum(id)return p.effects[id]and p.effects[id].Count or 0 end
  function e:GetCollectibleEffect(id)return p.effects[id]end
  function e:HasCollectibleEffect(id)return self:GetCollectibleEffectNum(id)>0 end
  return e
 end
 local function nativeHas(id)return not p.blocks[id]and((p.items[id]or 0)>0 or(p.effects[id]and p.effects[id].Count>0))end
 local function n(id)return nativeHas(id)and((p.items[id]or 0)+(p.effects[id]and p.effects[id].Count or 0))or 0 end
 function p:AddCacheFlags(f)self.flags=self.flags|f end
 function p:GetTearsCap()return 5 end
 function p:EvaluateItems()
  local f=self.flags;self.flags=0
  if self.failNumeric and self.data.hunterBalance170 and self.data.hunterBalance170.active then self.failNumeric=false;error('native numeric cache failure')end
  if f&256~=0 then self.weaponRebuilds=self.weaponRebuilds+1 end
  if f&1~=0 then self.MoveSpeed=1;call(8,self,1)end
  if f&2~=0 then
   local ups=(self.tearsUp or 0)+n(1)*.7+n(32)*.7
   ups=call(1226,self,0,ups)
   local delay=math.max(5,16-6*math.sqrt(math.max(0,1+1.3*ups)))
   local rate=call(1226,self,1,30/(delay+1)+(self.flatTears or 0))
   -- Deliberately varied native penalties, including affine delay changes.
   -- The implementation must mask native effects, not guess any constants.
   for _,id in ipairs({2,153,152,169,229,310,118,52,149,531,556})do
    if nativeHas(id)then
     local a=(self.penaltyScale or 1)*(1.8+id%4)
     local b=(id%3)*4
     rate=30/((30/rate-1)*a+b+1)
    end
   end
   if nativeHas(900)then rate=rate*.1 end -- unlisted penalty: no compensation/floor
   if nativeHas(330)then rate=rate*8 end
   self.MaxFireDelay=30/rate-1;call(8,self,2)
  end
  if f&4~=0 then
   local damage=3.5+(self.nativeFlat or 0)
   if nativeHas(169)then damage=damage*2+4*n(169)end
   if nativeHas(149)then damage=damage+40 end
   if nativeHas(531)then damage=damage+n(531)end
   damage=call(1226,self,3,damage)
   if nativeHas(531)then damage=damage*1.5 end
   if nativeHas(310)then damage=damage*2 end
   if nativeHas(152)then damage=damage*.65 end
   if nativeHas(245)then damage=damage*.8 end
   if nativeHas(4)then damage=damage*1.5 end
   if nativeHas(330)then damage=damage*.2 end
   self.Damage=damage;call(8,self,4)
  end
  if f&8~=0 then
   self.ShotSpeed=1+(self.shotUp or 0)
   if nativeHas(310)then self.ShotSpeed=self.ShotSpeed-.5 end
   if nativeHas(149)then self.ShotSpeed=self.ShotSpeed*.8 end
   call(8,self,8)
  end
  if f&16~=0 then
   self.TearRange=260
   if nativeHas(149)then self.TearRange=self.TearRange*.8 end
   if nativeHas(531)then self.TearRange=self.TearRange*.8 end
   call(8,self,16)
  end
 end
 function p:BlockCollectible(id)
  assert(configs[id].CacheFlags==0,'Block must not rebuild native weapons')
  self.blocks[id]=true
  self:AddCacheFlags(configs[id].CacheFlags);self:EvaluateItems()
  if self.failBlock then self.failBlock=false;error('block failed after applying')end
 end
 function p:UnblockCollectible(id)
  assert(configs[id].CacheFlags==0,'Unblock must stay quiet until all restores finish')
  self.blocks[id]=nil;self:AddCacheFlags(configs[id].CacheFlags);self:EvaluateItems()
 end
 function p:AddCollectible(id,charge,first)assert(first==false);self.items[id]=(self.items[id]or 0)+1;self.added=self.added+1;self:AddCacheFlags(2);self:EvaluateItems()end
 function p:RemoveCollectible(id)assert((self.items[id]or 0)>0);self.items[id]=self.items[id]-1;self.removed=self.removed+1;self:AddCacheFlags(2);self:EvaluateItems()end
 players[#players+1]=p;return p
end
Game=function()return{GetFrameCount=function()return frame end,GetNumPlayers=function()return #players end}end
Isaac={GetPlayer=function(i)return players[i+1]end,GetItemConfig=function()return{GetCollectible=function(_,id)return configs[id]end}end,DebugString=function()end}
function include(n)return assert(loadfile(MOD_ROOT..'/'..n..'.lua'))()end
local stats=include('tainted_hunter_stats')(mod,20);local B=stats.balance
local function settle(p)
 p:AddCacheFlags(31);p:EvaluateItems();B.refresh(p)
 assert(not p.data.hunterBalance170 or not p.data.hunterBalance170.error,p.data.hunterBalance170 and p.data.hunterBalance170.error)
 for id in pairs(p.blocks)do assert(p.externalBlocked==id,'Leaked item block '..id)end
 for _,id in ipairs(B.ids)do assert(configs[id].CacheFlags==270,'Leaked item config mask '..id)end
 assert(p.added==0 and p.removed==0 and p.health==12,'Numeric replacement must not change inventory/health')
end
local function rate(p)return 30/(p.MaxFireDelay+1)end
local p=player({});settle(p);approx(p.Damage,4.2);approx(rate(p),.48);approx(p.ShotSpeed,1.6);approx(p.TearRange/40,12);approx(p.data.hunterBalance170.capRate,1)
local normal=player({[169]=1,[310]=1},10);settle(normal);approx(normal.Damage,22);assert(normal.data.hunterBalance170==nil)
for _,row in ipairs({{2,.5,0},{153,.42,0},{152,.75,0},{169,1,8},{229,.23,0},{310,1.35,0},{118,1,0},{52,.8,0},{149,1,0},{531,1,3}})do
 for _,scale in ipairs({1,3.79})do
  local p=player({[row[1]]=1});p.penaltyScale=scale;settle(p)
  approx(p.Damage,(3.5+row[3])*1.2*row[2]);approx(rate(p),.48);approx(p.data.hunterBalance170.capRate,1)
  assert(p.items[row[1]]==1 and p.weaponRebuilds==0)
 end
end
for _,v in ipairs({{2,.5,0},{153,.42,0},{152,.75,0},{169,1,8},{229,.23,0},{310,1.35,0},{118,1,0},{52,.8,0},{149,1,0},{531,1,3}})do
 local p=player({});p.effects[v[1]]={Count=1,Cooldown=841};settle(p)
 approx(p.Damage,(3.5+v[3])*1.2*v[2]);approx(rate(p),.48)
 assert(p.effects[v[1]].Count==1 and p.effects[v[1]].Cooldown==841)
end
for mask=1,7 do
 local items={};local lowest=1
 for i,v in ipairs({{2,.5},{153,.42},{229,.23}})do if mask&(1<<(i-1))~=0 then items[v[1]]=1;lowest=math.min(lowest,v[2])end end
 local p=player(items);settle(p);approx(p.Damage,4.2*lowest)
 p.items[245]=1;settle(p);approx(p.Damage,4.2*.8)
 p.items[169]=1;settle(p);approx(p.Damage,(3.5+8)*1.2)
 approx(rate(p),.48)
end
local p=player({[2]=1,[153]=1,[229]=1,[245]=1,[169]=1,[310]=1,[152]=1,[52]=1,[149]=1,[531]=1,[4]=1})
settle(p);approx(p.Damage,(3.5+8+3)*1.5*1.2*1.35*.75);approx(rate(p),.48)
p.items[149]=nil;settle(p);approx(p.Damage,(3.5+8+3)*1.5*1.2*1.35*.75*.8)
local p=player({[310]=1});p.shotUp=1.3;settle(p);approx(p.ShotSpeed,2)
p.items[310]=nil;settle(p);approx(p.ShotSpeed,2.9)
local p=player({[310]=1,[149]=1});settle(p);approx(p.ShotSpeed,1.4);approx(p.TearRange,428)
local p=player({[169]=1,[531]=1});p.effects[169]={Count=2,Cooldown=731};p.effects[531]={Count=1,Cooldown=319};settle(p)
approx(p.Damage,(3.5+24+6)*1.2);assert(p.effects[169].Count==2 and p.effects[169].Cooldown==731 and p.effects[531].Count==1 and p.effects[531].Cooldown==319)
local p=player({[118]=1,[531]=1,[900]=1});settle(p);approx(rate(p),.048);approx(p.data.hunterBalance170.capRate,.1)
local p=player({[2]=1,[330]=1});settle(p);approx(rate(p),.48*8);approx(p.data.hunterBalance170.capRate,8)
local p=player({[118]=1,[531]=1});p.tearsUp=100;settle(p);approx(rate(p),1)
local p=player({[310]=1});p.blocks[310]=true;p.externalBlocked=310;settle(p);assert(p.blocks[310]);approx(p.Damage,4.2)
for _,fault in ipairs({'failBlock','failNumeric'})do
 local p=player({[169]=1,[310]=1});p[fault]=true
 p:AddCacheFlags(31);p:EvaluateItems();B.refresh(p)
 assert(p.data.hunterBalance170.error and next(p.blocks)==nil)
 for _,id in ipairs(B.ids)do assert(configs[id].CacheFlags==270)end
 B.refresh(p);approx(p.Damage,(3.5+8)*1.2*1.35);assert(not p.data.hunterBalance170.error)
end
print('v170 numeric contracts PASS: all10 replacements, arbitrary native penalties suppressed, seven multishot subsets/20-20/Polyphemus, combined exceptions, temporary effect count/cooldown, shot cap, unlisted penalties below0.6, error cleanup, no inventory/weapon mutation')

-- Execute the uploaded Stats+ public validators, middleware class, native
-- multiplier computables and tear-cap computable (not handwritten substitutes).
package.path=STATS_ROOT..'/?.lua;'..package.path
local enums={CollectibleType={SAD_ONION=1,NUMBER_ONE=6,WIRE_COAT_HANGER=32,TOOTH_PICKS=183,SCREW=255,BAR_OF_SOAP=564,ODD_MUSHROOM_THIN=120,ROCK_BOTTOM=562,MEGA_MUSH=625,CRICKETS_HEAD=4,MAGIC_MUSHROOM=12,BLOOD_OF_THE_MARTYR=7,BOOK_OF_BELIAL=34,POLYPHEMUS=169,SACRED_HEART=182,EVES_MASCARA=310,ALMOND_MILK=561,SOY_MILK=330,CROWN_OF_LIGHT=415,IMMACULATE_HEART=573,TWENTY_TWENTY=245,BRIMSTONE=118,HAEMOLACRIA=531,TECHNOLOGY=68,TECH_X=395,WHORE_OF_BABYLON=122},TrinketType={CRACKED_CROWN=92},PlayerType={},ModCallback={EVALUATE_CACHE=8,POST_UPDATE=1}}
for i,name in ipairs({'CAIN','JUDAS','BLUE_BABY','EVE','AZAZEL','LAZARUS_2','DARK_JUDAS','KEEPER','FORGOTTEN','MAGDALENE_B','EVE_B','AZAZEL_B','LOST_B','FORGOTTEN_B','LAZARUS_2_B','CAIN_B'})do enums.PlayerType[name]=100+i end
package.loaded['lua_modules.isaac-typescript-definitions.dist.index']=enums
package.loaded['lua_modules.@isaac-stats-plus.common.dist.index']={toFixedFormatted=function(_,v,n)return string.format('%.'..n..'f',v)end}
local new=require('lualib_bundle').__TS__New
local function construct(name,...)return new(require(name)[name:match('([^.]+)$')],...)end
local cv=construct('validators.api.APIConditionValidator');local sv=construct('validators.api.APISettingValidator')
local pv=construct('validators.api.APIProviderValidator',sv,cv,construct('validators.api.APIProviderStateValidator'))
local mv=construct('validators.api.APIMiddlewareValidator');local av=construct('validators.api.APIAddonValidator',pv,cv,mv)
local api={stat={tears={addon='stats-plus-core',id='tears-stat'}}}
function api:middleware(def)return mv:validate(def)end
function api:provider(def)return pv:validate(def)end
function api:register(def)self.addon=av:validate(def)end
include('tainted_hunter_stats_plus')(mod,20,stats)
call('STATS_PLUS_REGISTER',api)
assert(#api.addon.middleware==4 and #api.addon.providers==1)
local middlewares={}
for _,definition in ipairs(api.addon.middleware)do middlewares[definition.target.computable]=construct('entities.extension.middleware.Middleware',api.addon.id,definition)end
local damageApi={provider=function(_,def)return def end,settings={toggle=function(_,def)return def end},stat=api.stat}
local damageDef=require('lua_modules.@isaac-stats-plus.essentials-addon.dist.providers.damageMultiplierProvider.createDamageMultiplierProvider').createDamageMultiplierProvider(nil,damageApi,mod,{})
local compute={}
for key,fn in pairs(damageDef.computables)do
 compute[key]=function(self,...)
  local args={...};local initial=fn(self,table.unpack(args))
  return middlewares[key]and middlewares[key]:intercept(args,initial).value or initial
 end
end
for mask=0,7 do
 local items={[4]=1,[152]=1,[310]=1,[52]=1}
 for i,id in ipairs({2,153,229})do if mask&(1<<(i-1))~=0 then items[id]=1 end end
 local p=player(items);settle(p)
 local displayed=compute:getTotalCollectibleMultiplier(p)*compute:getCharacterMultiplier(p)
 approx(displayed,1.5*1.2*B.damageMultiplier(p))
 p.items[245]=1;settle(p);approx(compute:getTotalCollectibleMultiplier(p)*compute:getCharacterMultiplier(p),1.5*1.2*B.damageMultiplier(p)*.8)
 p.items[169]=1;settle(p);approx(compute:getTotalCollectibleMultiplier(p)*compute:getCharacterMultiplier(p),1.5*1.2*B.damageMultiplier(p))
 p.items[149]=1;settle(p);approx(compute:getTotalCollectibleMultiplier(p)*compute:getCharacterMultiplier(p),1.5*1.2*B.damageMultiplier(p))
end
local normal=player({[169]=1,[310]=1,[245]=1},10)
approx(compute:getTotalCollectibleMultiplier(normal),2*2*.8)
local capApi={provider=function(_,def)return def end,stat=api.stat}
local capDef=require('lua_modules.@isaac-stats-plus.essentials-addon.dist.providers.tearCapProvider.createTearCapProvider').createTearCapProvider(nil,capApi,mod)
local p=player({[118]=1,[531]=1,[2]=1});settle(p)
local nativeResult=capDef.computables.computeTearCap(capDef.computables,p)
local corrected=middlewares.computeTearCap:intercept({p},nativeResult).value
approx(30/(corrected+1),1);approx(rate(p),.48)
assert((p.items[1]or 0)==0 and p.added==p.removed)
local p=player({[118]=1,[531]=1,[900]=1});settle(p)
local nativeResult=capDef.computables.computeTearCap(capDef.computables,p)
local corrected=middlewares.computeTearCap:intercept({p},nativeResult).value
approx(30/(corrected+1),.1);approx(rate(p),.048)
assert(middlewares.computeTearCap:intercept({p},'UNKNOWN').value=='UNKNOWN')
print('v170 uploaded Stats+ APIs PASS:4 validated middleware, native multiplier list/item/total computation, seven multishot/20-20/Polyphemus combinations, native cap computation restored/corrected, unlisted cap0.1 and normal-character isolation')
