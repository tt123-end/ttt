-- v1.40: native directional legs, separate head/body pickup and hurt layers.
-- The ANM2 is cloned from Isaac: timing, events, pivots and trajectories are retained.
-- No screen-space render callback, input interception, collision or stat modification.
return function(mod, playerType, normalType)
    local DEFAULT = "gfx/001.000_player.anm2"
    local LEGACY = "gfx/001.000_player_hunter_b.anm2"
    local PREVIOUS = "gfx/001.000_player_hunter_b_v135.anm2"
    local PREVIOUS_FINAL = "gfx/001.000_player_hunter_b_v135_final.anm2"
    local PREVIOUS_136 = "gfx/001.000_player_hunter_b_v136.anm2"
    local PREVIOUS_137 = "gfx/001.000_player_hunter_b_v137.anm2"
    local PREVIOUS_138 = "gfx/001.000_player_hunter_b_v138.anm2"
    local PREVIOUS_139 = "gfx/001.000_player_hunter_b_v139.anm2"
    local NATIVE = "gfx/001.000_player_hunter_b_v140.anm2"
    local SKIN = "gfx/characters/costumes/character_hunter_b_v136.png"
    local NORMAL_SKIN = "gfx/characters/costumes/character_revolver_silent_blank.png"
    local function filename(sprite)
        return (sprite:GetFilename() or ""):lower():gsub("\\", "/")
    end
    local function changeAnimationFile(player)
        if not player or playerType == -1 then return end
        local sprite = player:GetSprite()
        local source = filename(sprite)
        local hunter = player:GetPlayerType() == playerType
        local data = player:GetData()
        local target
        local own = source == NATIVE or source == LEGACY or source == PREVIOUS or source == PREVIOUS_FINAL or source == PREVIOUS_136 or source == PREVIOUS_137 or source == PREVIOUS_138 or source == PREVIOUS_139
        if hunter and own then data.hunterWasB136 = true end
        if hunter and (source == DEFAULT or (own and source ~= NATIVE)) then
            target = NATIVE
        elseif not hunter and (own or (data.hunterWasB136 and player:GetPlayerType() == normalType and source == DEFAULT)) then
            target = DEFAULT
        else
            -- Keep engine/other-mod special animation files intact.
            return
        end
        local animation, frame = sprite:GetAnimation(), sprite:GetFrame()
        local overlay, overlayFrame = sprite:GetOverlayAnimation(), sprite:GetOverlayFrame()
        local scale, color, rotation = sprite.Scale, sprite.Color, sprite.Rotation
        local flipX, flipY, speed = sprite.FlipX, sprite.FlipY, sprite.PlaybackSpeed
        sprite:Load(target, true)
        if hunter then
            data.hunterWasB136 = true
            sprite:ReplaceSpritesheet(0, SKIN)
            sprite:LoadGraphics()
        elseif normalType and player:GetPlayerType() == normalType then
            -- Returning to the regular Hunter must restore its transparent base,
            -- otherwise an Isaac body would appear under the separate renderer.
            sprite:ReplaceSpritesheet(0, NORMAL_SKIN)
            sprite:LoadGraphics()
            data.silentMotion124, data.hunterFacing136, data.hunterWasB136 = nil, nil, nil
            rotation, flipX, flipY, speed = 0, false, false, 1
            if not player:IsDead() and (animation == "Death" or animation == "ForgottenDeath" or overlay == "Death" or overlay == "ForgottenDeath") then
                animation, frame, overlay = "WalkDown", 0, ""
            end
        end
        if not hunter then data.hunterWasB136, data.hunterFacing136 = nil, nil end
        -- SetFrame(int) preserves playback; SetFrame(animation,int) would stop it.
        if animation and animation ~= "" then
            sprite:Play(animation, true)
            sprite:SetFrame(frame)
        end
        if overlay and overlay ~= "" then
            sprite:PlayOverlay(overlay, true)
            sprite:SetOverlayFrame(overlay, overlayFrame)
        end
        sprite.Scale, sprite.Color, sprite.Rotation = scale, color, rotation
        sprite.FlipX, sprite.FlipY, sprite.PlaybackSpeed = flipX, flipY, speed
    end
    -- Only ordinary locomotion is affected. Pickup, damage, death, special
    -- engine animations and the head overlay remain owned by the engine.
    local ordinary = {WalkDown=true, WalkUp=true, WalkLeft=true, WalkRight=true}
    local function synchronizeBodyAim(player)
        if playerType == -1 or player:GetPlayerType() ~= playerType or player:IsDead() then return end
        local sprite = player:GetSprite()
        if filename(sprite) ~= NATIVE or not ordinary[sprite:GetAnimation()] then return end
        local shoot = player:GetShootingInput()
        if shoot:Length() <= 0.1 then return end
        local direction
        if math.abs(shoot.X) > math.abs(shoot.Y) then
            direction = shoot.X < 0 and "Left" or "Right"
        else
            direction = shoot.Y < 0 and "Up" or "Down"
        end
        local target = "Walk" .. direction
        local frame = sprite:GetFrame()
        -- Preserve playback with Play + single-index SetFrame. The two-argument
        -- SetFrame overload would stop walking, so never use it here.
        if player.Velocity:Length() < 0.1 then frame = 0 end
        local overlay, overlayFrame = sprite:GetOverlayAnimation(), sprite:GetOverlayFrame()
        if sprite:GetAnimation() ~= target then
            sprite:Play(target, true)
            sprite:SetFrame(frame)
            if overlay and overlay ~= "" then sprite:SetOverlayFrame(overlay, overlayFrame) end
        elseif player.Velocity:Length() < 0.1 then
            sprite:SetFrame(0)
        end
    end
    mod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, function(_, player)
        changeAnimationFile(player)
    end)
    -- Handles continue, character changes and engine costume rebuilds without
    -- replacing the Sprite during rendering or restarting an animation each frame.
    mod:AddCallback(ModCallbacks.MC_POST_PLAYER_UPDATE, function(_, player)
        changeAnimationFile(player)
        synchronizeBodyAim(player)
    end)
    Isaac.DebugString("[Revolver Samson] v1.40 Tainted Hunter: native gait and layered pickup/hurt loaded")
end
