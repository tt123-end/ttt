-- v1.58: optional character-trait descriptions for the uploaded EID API.
-- This only registers text. Character mechanics and EID's own files are untouched.
return function(mod, playerType)
    local registeredEID
    local descriptions={
        zh_cn=table.concat({
            "{{Damage}} 单发泪弹造成角色面板攻击力800%的伤害",
            "每次攻击后进入换弹，持续1个攻击间隔",
            "{{Warning}} 换弹期间受到的伤害翻倍",
            "{{BrokenHeart}} 非主动付血型伤害实际扣到红心时，每次+1碎心",
            "献血机、恶魔乞丐、献祭刺、诅咒房刺门等不触发碎心",
            "{{Collectible169}} 巨人独眼式伪穿透：击杀后保留剩余伤害继续飞行",
            "{{Tears}} 受到的负射速倍率惩罚减轻",
            "普通射速软上限由1趋近0.6，不保底实际射速"
        },"#"),
        en_us=table.concat({
            "{{Damage}} Each tear deals 800% of the character's displayed damage",
            "Reload after every attack for one attack interval",
            "{{Warning}} Damage taken is doubled while reloading",
            "{{BrokenHeart}} Gain 1 Broken Heart per non-payment hit that actually removes Red Hearts",
            "Blood donations, Devil Beggars, sacrifice spikes, Curse Room doors and similar health payments do not trigger this penalty",
            "{{Collectible169}} Polyphemus-style pseudo-piercing: killing blows retain excess damage and keep flying",
            "{{Tears}} Reduced penalties from negative fire-rate multipliers",
            "Ordinary tears soft cap approaches 0.6 from 1; actual tears are not floored"
        },"#")
    }
    local function install()
        if playerType==-1 then return end
        if EID and type(EID.addCharacterInfo)=="function" and registeredEID~=EID then
            EID:addCharacterInfo(playerType,descriptions.en_us,"TAINTED HUNTER","en_us")
            EID:addCharacterInfo(playerType,descriptions.zh_cn,"里猎手","zh_cn")
            registeredEID=EID
        end
    end
    install()
    mod:AddCallback(ModCallbacks.MC_POST_GAME_STARTED,install)
    -- As with regular Hunter, support EID loading after the character mod.
    -- The instance guard prevents duplicate registration on repeated updates.
    mod:AddCallback(ModCallbacks.MC_POST_UPDATE,install)
end
