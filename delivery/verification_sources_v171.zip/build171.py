from pathlib import Path
import shutil,xml.etree.ElementTree as E
T=Path('/workspace/hunter-fix-tools');O=Path('/workspace/deliverables170/zzzz_revolver_samson');D=Path('/workspace/deliverables171');P=D/'zzzz_revolver_samson'
D.mkdir(exist_ok=True)
if not P.exists():shutil.copytree(O,P)
s=(O/'tainted_hunter_balance.lua').read_text()
assert s.count('end,debug.traceback)')==2
s=s.replace('end,debug.traceback)','end,tostring)').replace('[Hunter v1.70 balance]','[Hunter v1.71 balance]')
s=s.replace('    local B={};local game=Game()','    -- Isaac does not expose the Lua debug library. Keep both protected calls\n    -- independent of it so initialization and cleanup work in the game sandbox.\n    local B={};local game=Game()')
(P/'tainted_hunter_balance.lua').write_text(s)
(T/'tainted_hunter_balance171.lua').write_text(s)
for name in ['main.lua','tainted_hunter_compat.lua']:
 s=(O/name).read_text().replace('v1.70','v1.71')
 (P/name).write_text(s)
s=(O/'tainted_hunter_rules.lua').read_text().replace('version=170','version=171')
(P/'tainted_hunter_rules.lua').write_text(s)
t=E.parse(O/'metadata.xml');t.getroot().find('version').text='1.71';t.getroot().find('description').text='v1.71: Fix player initialization in the Isaac Lua sandbox without the debug library. All v1.70 gameplay, balance and compatibility rules retained.';t.write(P/'metadata.xml',encoding='utf-8',xml_declaration=True)
readme=(O/'README.md').read_text().replace('v1.70','v1.71')
readme=readme.replace('# 猎手 Hunter — v1.71\n','# 猎手 Hunter — v1.71\n\n本版修复v1.70打开游戏时的初始化报错：两处异常处理不再依赖游戏未提供的Lua debug库。保留v1.70全部数值、道具组合规则、人物外观及UI。已在debug=nil的接口测试环境中验证角色初始化、开始/继续游戏刷新、数值重算与故障恢复；本机未运行Isaac游戏。\n',1)
(P/'README.md').write_text(readme);(D/'README_v171.md').write_text(readme)
# The regression must run the real init callbacks and all numeric contracts with
# the same missing standard library as Isaac, including error cleanup paths.
s=(T/'test_stats170.lua').read_text()
s='debug=nil\n'+s
needle='local p=player({});settle(p);approx(p.Damage,4.2);'
init='''local init=player({});call(ModCallbacks.MC_POST_PLAYER_INIT,init)
assert(not init.data.hunterBalance170.working and not init.data.hunterBalance170.error)
approx(init.Damage,4.2);approx(rate(init),.48)
local initNormal=player({},10);call(ModCallbacks.MC_POST_PLAYER_INIT,initNormal)
assert(initNormal.data.hunterBalance170==nil)
for _,continued in ipairs({false,true})do
 call(ModCallbacks.MC_POST_GAME_STARTED,continued)
 approx(init.Damage,4.2);approx(rate(init),.48)
 assert(not init.data.hunterBalance170.working and not init.data.hunterBalance170.error)
 assert(initNormal.data.hunterBalance170==nil)
end
print('v171 sandbox initialization PASS: debug=nil, player init, new/continued game, normal character isolation')
'''
assert s.count(needle)==1
s=s.replace(needle,init+needle)
s=s.replace('assert(p.data.hunterBalance170.error and next(p.blocks)==nil)',"assert(p.data.hunterBalance170.error and next(p.blocks)==nil)\n assert(not p.data.hunterBalance170.working)\n assert(p.data.hunterBalance170.error:find(fault=='failBlock' and 'block failed after applying' or 'native numeric cache failure',1,true),'Original error must remain readable without debug')")
(T/'test_stats171.lua').write_text(s)
print('Built v1.71: remove both debug dependencies, retain v1.70 stat rules')
