-- v1.60: compensate the extra Haemolacria penalty when combined with Brimstone.
-- Other established weapon-priority rules and the soft-cap curve are retained.
local function getNegativeTearRateMultiplier(player)
    local effects = player.GetEffects and player:GetEffects()
    local function has(id)
        return player:HasCollectible(id) or (effects and effects.HasCollectibleEffect
            and effects:HasCollectibleEffect(id)) or false
    end
    local multiplier = 1.0
    local hasDrFetus = has(52) -- 168 is Epic Fetus, not Dr. Fetus
    local hasBrimstone = has(118)
    local hasArcPenalty = has(149) or has(531) -- Ipecac / Haemolacria share x1/3
    local hasCSection = has(678)
    -- C Section overrides Monstro's Lung's ordinary tear behavior/rate penalty.
    local hasMonstroLung = has(229) and not hasCSection

    -- Repentance's Dr. Fetus / Brimstone / Ipecac / Monstro's Lung priority and stacking rules.
    -- Dr. Fetus uses x0.4 unless Monstro's Lung takes priority; Brimstone overrides Ipecac;
    -- Monstro's Lung and Ipecac stack when neither Dr. Fetus nor Brimstone is present.
    if hasDrFetus then
        if hasMonstroLung then
            multiplier = multiplier * (1.0 / 4.3)
        else
            multiplier = multiplier * 0.4
        end
    elseif hasBrimstone then
        multiplier = multiplier * (1.0 / 3.0)
        -- Brimstone overrides Ipecac's rate penalty, but does not remove
        -- Haemolacria's penalty on the primary bursting tear. Treating both
        -- arc items as Ipecac left another x1/3 uncompensated in this combo.
        if has(531) then
            multiplier = multiplier * (1.0 / 3.0)
        end
    elseif hasMonstroLung then
        multiplier = multiplier * (1.0 / 4.3)
        if hasArcPenalty then
            multiplier = multiplier * (1.0 / 3.0)
        end
    elseif hasArcPenalty then
        multiplier = multiplier * (1.0 / 3.0)
    end

    -- Polyphemus, Mutant Spider and The Inner Eye share a non-stacking fire-rate penalty.
    -- 20/20 removes this penalty. Polyphemus + C Section also removes Polyphemus's rate penalty.
    if not has(245) then -- 20/20
        if has(153) or (has(169) and not hasCSection) then
            multiplier = multiplier * 0.42
        elseif has(2) then -- The Inner Eye
            multiplier = multiplier * 0.51
        end
    end

    -- Eve's Mascara's x0.66 tears multiplier stacks with the above groups.
    if has(310) then
        multiplier = multiplier * 0.66
    end
    if has(152) then -- Technology 2, Repentance x2/3 fire rate
        multiplier = multiplier * (2.0 / 3.0)
    end

    return multiplier
end


local tears = {getNegativeMultiplier = getNegativeTearRateMultiplier}

function tears.softCap(multiplier, stats)
    -- C(1)=1, C(M)->0.6 as M->0. This is a soft-cap reference, not
    -- a minimum actual fire rate or a clamp on cap-breaking bonuses.
    local m = math.max(0, math.min(1, multiplier))
    return stats.minimumSoftCap + (stats.softCap - stats.minimumSoftCap) * m
end

function tears.calibrate(rate, stats)
    local nativeStart = 30 / 11
    local nativeCap = 5.0
    local preMultiplierCap = stats.softCap / stats.tearsMultiplier
    if rate <= nativeStart then return rate * (stats.baseTears / nativeStart) end
    -- Anchor the initial rate to 2.4 and the ordinary native cap to 5.
    -- The previous linear x0.88 baseline normalization would make the cap
    -- 0.88 after x0.2. This continuous calibration keeps both requested anchors.
    -- Progress above 1 is intentional: positive/cap-breaking effects survive.
    local progress = (rate - nativeStart) / (nativeCap - nativeStart)
    return stats.baseTears + (preMultiplierCap - stats.baseTears) * progress
end

function tears.calculate(player, incomingDelay, stats)
    local nativeRate = 30 / math.max(0.01, incomingDelay + 1)
    local m = tears.getNegativeMultiplier(player)
    -- Recover the rate before the known native penalties, then replace only
    -- those penalties. This does not grant the items or alter other item effects.
    local beforePenalty = nativeRate / math.max(1e-12, m)
    local cap = tears.softCap(m, stats)
    local beforeCharacter = tears.calibrate(beforePenalty, stats)
    local rate = beforeCharacter * stats.tearsMultiplier * (cap / stats.softCap)
    return math.max(0.001, rate), cap, m
end

return tears
