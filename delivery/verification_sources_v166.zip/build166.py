from pathlib import Path
import shutil,xml.etree.ElementTree as E
T=Path('/workspace/hunter-fix-tools');OLD=Path('/workspace/deliverables165/zzzz_revolver_samson');P=Path('/workspace/deliverables166/zzzz_revolver_samson')
for name in ['compat','compat_eid','rules','sword']:
 shutil.copy2(T/f'tainted_hunter_{name}166.lua',P/f'tainted_hunter_{name}.lua')
s=(OLD/'main.lua').read_text().replace('-- v1.65 - native Chocolate replacement, complete sword sweep and live projectile groups','-- v1.66 - original native sword spin API and factory-initialized Trisagion damage',1)
(P/'main.lua').write_text(s)
t=E.parse(OLD/'metadata.xml');t.getroot().find('version').text='1.66';t.getroot().find('description').text='v1.66: Trisagion damage initialized in the native tear factory, not multiplied by speculative hit sources; Spirit Sword uses original native spin state/render/collision via REPENTOGON. Vanilla keeps the sword beam with no counterfeit sweep. Confirmed v1.65 Dead Eye, Chocolate and C Section unchanged.';t.write(P/'metadata.xml',encoding='utf-8',xml_declaration=True)
print('Built v1.66')
