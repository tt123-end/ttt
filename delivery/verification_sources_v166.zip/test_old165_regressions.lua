-- This is appended to the v164 harness by verify165.py.
local p=player({[373]=1});local tear=nativeShot(p);tear.dead=true;tick(p,3)
assert(p.clears==1,'Dead existing tear must request native miss reset')
