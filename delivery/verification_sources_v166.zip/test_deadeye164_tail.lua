-- Reproduces the v163 defect independently of changed weapon values.
local p=player({[373]=1})
local root=nativeShot(p);local target=entity(10);target.HitPoints=1000
call(42,root,target);target:TakeDamage(root.CollisionDamage,0,EntityRef(root),0)
call(1);root:Remove();tick(p,1)
local discarded=nativeShot(p)
assert(discarded.removed,'A genuine reload must reject this native extra tear')
assert(p.clears==0,'Rejected native tear must never reset Dead Eye after a hit')
local p=player({[373]=1});local root=nativeShot(p)
local target=entity(10);target.HitPoints=1000
call(42,root,target);target:TakeDamage(root.CollisionDamage,0,EntityRef(root),0)
target.HitPoints=1000 -- stationary testing targets can restore HP in the same update.
root:Remove();tick(p,3)
assert(p.clears==0,'A hit must survive a stationary target restoring its HP')
print('v164 targeted Dead Eye regressions passed: discarded native tear and restored target HP')
