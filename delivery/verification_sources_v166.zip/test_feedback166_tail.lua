-- Native base damage, not writable collision damage, controls the model's
-- Trisagion light. This captures the missing path in the previous tests.
local p=player({[533]=1});p.nativeFlags=TearFlags.TEAR_LASERSHOT
local root=lightShot(p)
approx(p.Damage,4.2);approx(root:GetData().panel163,4.2)
approx(root.BaseDamage,67.2);approx(root.CollisionDamage,67.2)
assert(not pcall(function()root.BaseDamage=123 end),'Native BaseDamage must stay read-only')
root.CollisionDamage=1 -- A later native/third-party collision-field write.
local nativeLight=root.BaseDamage/3
local npc=entity(10);npc.HitPoints=1000
local calls=0
mod:AddPriorityCallback(11,-10000,function(_,target)if target==npc then calls=calls+1 end end)
npc:TakeDamage(nativeLight,DamageFlag.DAMAGE_LASER,{Entity=nil},0)
approx(npc.HitPoints,1000-22.4);assert(calls==1)
assert(not p:GetData().hunterCompat163.lastLight165,'Native-base damage must not be post-multiplied')
-- Native descendants inherit scaled base once, even when no Lua source is available.
local child=p:FireTear(root.Position,Vector(3,0),false,false,false,root,.5)
nativeBases[child]=root.BaseDamage*.5;child.CollisionDamage=nativeBases[child]
local hp=npc.HitPoints;npc:TakeDamage(child.BaseDamage/3,8,{Entity=nil},0)
approx(npc.HitPoints,hp-11.2)
local p=player({[533]=1,[69]=1});p.nativeFlags=TearFlags.TEAR_LASERSHOT
local root=lightShot(p);local curve=R.chocolate(.48,1)
approx(root.BaseDamage,4.2*16*curve);approx(p.Damage,4.2)
assert(p.items[69]==0 and p.items[9002]==1)
-- Exceptions cannot leave the sheet multiplied or temporary effects missing.
local p=player({[533]=1});p.effects[69]=1;p.effects[154]=1;p.failFire=true;p.input=Vector(1,0)
local ok=pcall(tick,p);assert(not ok);approx(p.Damage,4.2)
assert(p.effects[69]==1 and p.effects[154]==1 and(p.effects[9002]or 0)==0 and(p.effects[9001]or 0)==0)
assert(p:GetData().hunterCompat163.context==nil)

-- REPENTOGON path: original EntityKnife gets real spin-state setters, remains
-- visible/collidable, and has no companion replacement sprite or manual hit.
REPENTOGON={};local p=player({[579]=1});local sword=C._testing.sword
local beforeSprites=spriteCreates
local k=sword.attack(p,Vector(0,1))
assert(k and k:GetIsSpinAttack()==true and k:GetIsSwinging()==true)
assert(k.Visible==true and k.EntityCollisionClass==4)
assert(k:GetData().nativeSword166 and not k:GetData().spin165)
assert(spriteCreates==beforeSprites+1,'Only the real knife sprite is created, no copied overlay')
approx(k.CollisionDamage,8*p.Damage+10)
k.Position=Vector(31,47);call(45,k);approx(k.Position.X,31);approx(k.Position.Y,47)
-- Legacy1.0.12 has no GetHitboxParentKnife; subtype4 native hitboxes survive.
local box=entity(8,10,p);box.SubType=4;box.CollisionDamage=20
call(45,box);assert(not box.removed and box:GetData().nativeSwordHitbox166)
approx(box.CollisionDamage,20)
-- Newer API can supply the native hitbox parent even without a player spawner.
local box=entity(8,10);box.SubType=4
function box:GetHitboxParentKnife()return k end
call(45,box);assert(not box.removed and box:GetData().owner163==p)
k:SetIsSwinging(false);tick(p,4);assert(k.removed)
-- Missing/outdated API does not silently fall back to the rejected fake slash.
local p=player({[579]=1});p.missingSwordAPI=true
assert(sword.attack(p,Vector(1,0))==nil)
assert(p:GetData().hunterNativeSword166:find('unavailable'))
REPENTOGON=nil
local p=player({[579]=1});local before=#entities
assert(sword.attack(p,Vector(1,0))==nil and #entities==before)
p.input=Vector(1,0);tick(p);p.input=Vector(0,0)
local beam=false
for _,e in ipairs(entities)do if e.SpawnerEntity==p and e.Variant==47 then beam=true end end
assert(beam,'Full-health sword beam remains available in vanilla')
REPENTOGON={}
print('v166 targeted contracts passed: readonly native base16x without hit sources, descendant ratio, normal sheet/error restoration, native spin flags/render/collision and legacy/new hitboxes, no fake fallback')
local p=player({[533]=1,[395]=1});p.nativeFlags=TearFlags.TEAR_LASERSHOT
local root=lightShot(p);local ring=latest(7,p)
approx(root.BaseDamage,67.2);approx(p.Damage,4.2);approx(ring.CollisionDamage,4.2)
assert(ring:GetData().followTear163==root and not root:GetData().pendingRing166)
print('v166 independent side-ring damage remains native while the light base is scaled')
