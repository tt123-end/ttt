from pathlib import Path
import ctypes,json,xml.etree.ElementTree as E
D=Path('/workspace/deliverables167');P=D/'zzzz_revolver_samson';T=Path('/workspace/hunter-fix-tools');OLD=Path('/workspace/deliverables166/zzzz_revolver_samson')
exec((T/'verify166.py').read_text().split("prefix='local MOD_ROOT='")[0])
D=Path('/workspace/deliverables167');P=D/'zzzz_revolver_samson';OLD=Path('/workspace/deliverables166/zzzz_revolver_samson')
prefix='local MOD_ROOT='+json.dumps(str(P))+'\n'
for p in P.glob('*.lua'):lua(p.read_text(),p.name)
for p in list(P.rglob('*.xml'))+list(P.rglob('*.anm2')):E.parse(p)
fixture=(T/'test_compat167.lua').read_text()
lua(prefix+fixture,'v167_integrated',True)
header=fixture[:fixture.index('do\nlocal p=player({[373]=1});local t=nativeShot(p)')]
old='local MOD_ROOT="/workspace/deliverables166/zzzz_revolver_samson"\n'
lua(old+header+'''local p=player({[373]=1});local t=nativeShot(p);call(67,baseView(t))''','v166_reported_Entity_member_error',True,'no member named CanTriggerStreakEnd')
lua(old+header+'''
local p=player({[316]=1});p.red=12;p.max=12;p.input=Vector(1,0);tick(p);p.input=Vector(0,0)
local source=EntityRef(entity(10));p:TakeDamage(.5,0,source,0)
source.Entity=nil;setmetatable(source,{__index=function()error('borrowed EntityRef expired')end})
call(4,p)
''','v166_borrowed_curse_source',True,'borrowed EntityRef expired')
lua(old+header+'''
local p=player({[579]=1});local k=C._testing.sword.attack(p,Vector(1,0))
assert(k:GetSprite():IsPlaying('Spin'),'Original Spin animation must be started')
''','v166_native_sword_animation',True,'Original Spin animation must be started')
# Version1.66 has no precise native collision attribution for zero-flag hits
# attributed to a player, which is an actual legacy API source shape.
lua(old+header+'''
local p=player({[533]=1});p.nativeFlags=TearFlags.TEAR_LASERSHOT
local root=lightShot(p);local l=entity(7,5,p);l.Parent=root
local npc=entity(10);npc.HitPoints=1000
call(1248,l,npc);npc:TakeDamage(1.4,0,EntityRef(p),0);call(1249,l,npc)
assert(math.abs(npc.HitPoints-(1000-1.4*16))<1e-6,'Player-source native light must get16x actual damage')
''','v166_opaque_native_light',True,'Player-source native light must get16x actual damage')
print('v166 fails strict generic Entity ABI, borrowed curse-source lifetime, original Spin start and zero-flag player-source light contracts; v167 passes')
# Reuse the actual uploaded Stats+/EID execution and prior heart damage suite.
prior=(T/'verify166.py').read_text();a=prior.index("statsRoot=");b=prior.index('preserved=0')
s=prior[a:b].replace("assert(text(533):find('16倍原生基础伤害'))", "assert(text(533):find('实际命中伤害为原版的16倍'))")
s=s.replace('eid_character_text_v166','eid_character_text_v167')
exec(s)
changed={'tainted_hunter_compat.lua','tainted_hunter_compat_items.lua','tainted_hunter_sword.lua','tainted_hunter_rules.lua','tainted_hunter_compat_eid.lua','main.lua','metadata.xml','REPENTOGON_安装说明.md'}
for p in OLD.rglob('*'):
 if p.is_file()and p.name not in changed:assert p.read_bytes()==(P/p.relative_to(OLD)).read_bytes(),p
sword=(P/'tainted_hunter_sword.lua').read_text()
for forbidden in ['MC_POST_RENDER','FindInRadius','TakeDamage(',':Shoot(']:assert forbidden not in sword,forbidden
import re
assert not re.search(r'(?<![\w:])Sprite\(',sword)
new=(P/'tainted_hunter_compat.lua').read_text()
assert 'p.Damage=originalDamage*'not in new
# Keep C Section's accepted damage logic byte-identical.
old=(OLD/'tainted_hunter_compat.lua').read_text();a='        if td.cSection165 and not td.aux163';b='        if td.trisagion164'
assert old[old.index(a):old.index(b,old.index(a))]==new[new.index(a):new.index(b,new.index(a))]
report={'version':'1.67','lua_syntax':'PASS','xml_anm2':'PASS','prior_mechanics':'PASS: integrated mock regression including accepted Dead Eye, Chocolate Milk and C Section; unchanged damage/stats/visual modules','stats_plus_eid':'PASS: uploaded actual integration APIs and Stats numeric regression','reported_entity_error':'Reproduced with strict generic Entity callback proxy; fixed via ToTear conversion','curse_teleport':'PASS: borrowed EntityRef expiry contract, post-update-only one teleport, charge cleared before native damage, Black Candle/shield/dead/room-transition guards','light_damage':'PASS: exact REPENTOGON collision attribution for source=player and flags=0; one Damage table override before cancelling observers;16x native incoming damage; no sheet/base mutation, unrelated lasers and same-frame hits unaffected','sword':'PASS: original Spin started on real EntityKnife with original native spin/swing flags and collision; no generic knife Shoot, copied sprites, render overlay or scripted damage','old_v166_regressions':'Confirmed failures in all four targeted contracts','game_runtime':'NOT RUN; no Isaac executable. Contract tests and verified official REPENTOGON1.0.12 APIs are not in-game animation/damage/crash verification','version_diagnostic':'hunterdiag prints Hunter v1.67, REPENTOGON presence, incoming/applied native light damage, native sword animation/frame','limits':['Native original spin final animation and collision must be confirmed in Isaac','The exact reported Cursed Eye native crash cannot be reproduced without Isaac or a crash dump; unsafe retained callback source and update-time room transition were removed','Non-REPENTOGON light source attribution retains conservative older fallback; reliable precise light-hit attribution uses REPENTOGON','Prior Rock Bottom cap sampling limits and complex third-party synergies remain']}
(D/'validation_v167.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('v167 verification complete (no game runtime)')
