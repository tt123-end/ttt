from pathlib import Path
import zipfile,shutil,hashlib,json
from openpyxl import load_workbook
from openpyxl.styles import Alignment
T=Path('/workspace/hunter-fix-tools');D=Path('/workspace/deliverables167');P=D/'zzzz_revolver_samson'
readme='''# 猎手 v1.67：忏悔龙报错、原版旋斩、三圣颂实际伤害与诅咒之眼

这份说明优先于包内历史版本说明。本版适配已安装REPENTOGON的环境；普通忏悔对应官方REPENTOGON1.0.12。人物外观、初始数值、死亡之眼、专用巧克力牛奶和剖腹产的已确认方案保留。

## 安装与版本确认

完全退出游戏，将原zzzz_revolver_samson文件夹先移出mods备份，再把新ZIP内同名文件夹完整放入mods。只启用一份猎手，不要把新文件夹嵌套在旧文件夹里。重新启动游戏，控制台输入hunterdiag，第一行应包含[Hunter v1.67] REPENTOGON=true。游戏开始时也会把该版本行写入控制台与日志。

你上传的报错中第502行和第498行回调对应旧v1.65文件布局；当前安装可能仍加载旧文件或混合文件。本版增加明确的运行版本输出，用完整替换和重启排除这一问题。这个报错本身确为模组的类型处理错误，不要求重装忏悔龙。

## 修改

1. 修复MC_POST_ENTITY_REMOVE的CanTriggerStreakEnd报错。该通用回调提供Entity，必须先ToTear后才能访问泪弹字段。同一回调里的大便碰撞检查也使用转换后的EntityTear；伤害来源中的激光以及通用父泪弹在进入专用接口前同样转换。严格类型代理已复现旧代码错误并确认新代码通过。

2. 英灵剑保留飞刀与满血剑气，实际出手触发旋斩。本版在真实原生EntityKnife上开启SetIsSpinAttack/SetIsSwinging，并明确启动原版Spin动画；删除泛用飞刀Shoot调用。使用原生剑素材、动画与碰撞体，不复制贴图、不额外绘制剑影、不用脚本范围伤害模拟旋斩。hunterdiag会显示原生剑动画名称和帧号。官方REPENTOGON文档确认原版Spin素材带Hit1/Hit2空层碰撞信息，但这里没有游戏运行环境，最终显示和原生碰撞仍需游戏确认。

3. 三圣颂维持已要求的原版伤害16倍（此前4倍后又要求再乘4），本次修改实现路径，不继续追加倍率。移除v1.66临时修改玩家Damage并假设它能改变原生基础伤害的方案。REPENTOGON的光束碰撞回调确定准确的激光与目标，在MC_ENTITY_TAKE_DMG中返回Damage覆盖实际伤害，保留原本单段比例、频率及命中方式，且只乘一次。覆盖旧版来源只显示玩家、伤害标记为0的情况；较新REPENTOGON的ExtraSource也可直接识别。角色面板不变，独立硫磺火/科技X环、DOT和其他来源不跟随增伤。hunterdiag中的light显示incoming和applied，例如未修正单段1.4应变为22.4；巧克力牛奶等额外兼容倍率另外计算，原版护甲/减伤仍由游戏处理。未安装REPENTOGON时保留旧的保守来源回退，精确光束归属路径需要REPENTOGON。

4. 诅咒之眼换弹受伤传送：旧代码把回调借用的EntityRef保留到后续帧，再去访问其来源，存在来源失效风险；而且在玩家效果更新期间直接使用传送道具会触发房间切换。现仅保存来源类型、编号、受伤数值、楼层和房间等普通值，确认实际掉血后在全局POST_UPDATE阶段消费一次传送事件。忏悔龙环境下在原生受伤处理前清除主武器的原版诅咒之眼蓄力，避免原版立即传送与自定义传送重复进入。黑蜡烛、付款伤害、护盾取消、死亡、角色变化与已经切换房间时取消待处理事件。此处已消除可确认的代码风险；没有游戏程序/崩溃转储，不能宣称已经复现并验证你遇到的原生闪退本身。

## 验证

通过Lua5.4语法、XML/ANM2解析、实际上传Stats+/EID接口执行、原有伤害/骨心判定及兼容回归。新增严格Entity类型、借用EntityRef失效、延迟且单次传送、原版Spin启动、玩家来源/零标记光束命中、取消伤害的静止靶观察、无重复增伤与其他激光隔离测试。旧v1.66在对应的四类接口契约测试中失败，新版通过。人物视觉资源、数值、Stats+、生命惩罚、剖腹产命中削减逻辑保持原版字节。

这些是接口契约和逻辑模型测试，不是Isaac运行结果。本机没有Isaac可执行文件；原版旋斩、实际靶伤害与诅咒之眼不再闪退，均需在游戏内确认。此前磐石精确射速上限、复杂第三方模组组合等限制继续存在。

若仍异常，请提供hunterdiag输出（须显示v1.67）和展开后的完整报错；若是原生闪退，可附日志最后一段。该命令现在同时报告装载版本、忏悔龙状态、三圣颂输入/输出伤害和原生剑动画，便于直接定位。
'''
(D/'README_v167.md').write_text(readme);(P/'修复说明_v1.67.txt').write_text(readme)
shutil.copy2(D/'validation_v167.json',P/'validation_v167.json')
guide=Path('/workspace/deliverables166/REPENTOGON_install_v166_zh.md').read_text().replace('1.66','1.67').replace('v166','v167')
(D/'REPENTOGON_install_v167_zh.md').write_text(guide);(P/'REPENTOGON_安装说明.md').write_text(guide)
wb=load_workbook('/workspace/deliverables166/compatibility_implementation_v166.xlsx');ws=wb['说明与限制'];ws.delete_rows(1,ws.max_row)
for line in readme.splitlines():
 ws.append([line]);ws.cell(ws.max_row,1).alignment=Alignment(wrap_text=True,vertical='top');ws.row_dimensions[ws.max_row].height=max(22,min(180,len(line)//70*16+22))
for row in wb['实施对照'].iter_rows(min_row=2):
 key=str(row[1].value)
 if key=='579':row[4].value='v1.67本轮反馈';row[6].value='真实原生剑开启旋斩/挥动状态，并启动原版Spin动画；移除泛用Shoot；满血剑气保留';row[7].value='接口/逻辑模型通过；未游戏实测原生动画'
 if key=='533':row[4].value='v1.67修正实际命中链；维持16倍';row[5].value='原版光束实际命中伤害16倍';row[6].value='REPENTOGON准确光束碰撞归属，返回Damage覆盖一次；覆盖玩家来源且标记为0；面板/原生基础伤害不修改';row[7].value='真实官方回调契约模型通过；未游戏实测'
 if key=='316':row[4].value='v1.67换弹受伤传送安全修复';row[6].value='来源数值快照，全局更新阶段单次传送；受伤前阻止原版蓄力重复传送；死亡/换房/护盾/黑蜡烛保护';row[7].value='借用来源失效、延迟传送与取消场景模型通过；原生闪退待实测'
wb.save(D/'compatibility_implementation_v167.xlsx')
with zipfile.ZipFile(D/'verification_sources_v167.zip','w',zipfile.ZIP_DEFLATED)as z:
 names=['build167.py','verify167.py','test_compat167.lua','package167.py','verify166.py','test_stats161.lua','test_red_damage157.lua','test_bone_containers162_tail.lua','test_eid158.lua','test_compat_eid165.lua','eid_actual_api158.lua','eid_item_api163.lua']+['tainted_hunter_'+n+'167.lua'for n in ['compat','compat_items','compat_eid','rules','sword']]
 for n in names:z.write(T/n,n)
z=D/'hunter_v167.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as out:
 for p in sorted(P.rglob('*')):
  if p.is_file():out.write(p,p.relative_to(D))
with zipfile.ZipFile(z)as out:
 assert out.testzip()is None
 for p in P.rglob('*'):
  if p.is_file():assert out.read(str(p.relative_to(D)))==p.read_bytes()
 assert b'local tear=entity:ToTear()'in out.read('zzzz_revolver_samson/tainted_hunter_compat.lua')
 files=len(out.namelist())
names=['hunter_v167.zip','README_v167.md','validation_v167.json','verification_sources_v167.zip','compatibility_implementation_v167.xlsx','REPENTOGON_install_v167_zh.md']
(D/'SHA256SUMS_v167.txt').write_text(''.join(hashlib.sha256((D/n).read_bytes()).hexdigest()+'  '+n+'\n'for n in names))
print(json.dumps({'files':files,'bytes':z.stat().st_size,'CRC':'PASS','content_byte_comparison':'PASS','publish':names},ensure_ascii=False,indent=2))
