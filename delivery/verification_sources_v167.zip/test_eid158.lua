local callbacks={}
ModCallbacks={MC_POST_GAME_STARTED=15,MC_POST_NEW_ROOM=19,MC_POST_UPDATE=1}
local mod={AddCallback=function(_,id,fn)callbacks[id]=callbacks[id]or{};table.insert(callbacks[id],fn)end}
Game=function()return {GetNumPlayers=function()return 0 end}end
Isaac={GetCostumeIdByPath=function()return -1 end}
Options={Language='zh'}
local function update()
 for _,fn in ipairs(callbacks[1]or{})do fn(mod)end
end
local function actualEID()
 EID={descriptions={auto={},en_us={CharacterInfo={[1]={'Vanilla','unchanged'}}}},DefaultLanguageCode='en_us',Config={Language='auto'},LanguageMap={zh='zh_cn',en='en_us'},registrationCalls=0}
 assert(loadfile(ACTUAL_API))()
 local original=EID.addCharacterInfo
 function EID:addCharacterInfo(...)
  self.registrationCalls=self.registrationCalls+1
  return original(self,...)
 end
 function EID:GetPlayerIcon(id)return '{{Player'..id..'}}'end
 function EID:ItemReminderAddTempDescriptionEntry(icon,name,text)
  self.lastEntry={icon=icon,name=name,text=text}
 end
 return EID
end
local function player(kind)return {GetPlayerType=function()return kind end}end
-- Optional integrations tolerate absence and partially initialized EID.
EID=nil
assert(loadfile(MOD_ROOT..'/mod_compat.lua'))()(mod,1000)
assert(loadfile(MOD_ROOT..'/tainted_hunter_eid.lua'))()(mod,1001)
for i=1,30 do update()end
EID={};update()
-- EID appears after both character modules, using the uploaded actual API.
local current=actualEID();update()
assert(current.registrationCalls==4,'Exactly two locales per character')
local normal=current.descriptions.zh_cn.CharacterInfo[1000]
local tainted=current.descriptions.zh_cn.CharacterInfo[1001]
assert(normal[1]=='HUNTER'and normal[2]:find('300%%')and normal[2]:find('600%%'))
assert(tainted[1]=='里猎手'and tainted[2]:find('800%%'))
assert(not tainted[2]:find('300%%')and not tainted[2]:find('600%%'))
assert(tainted[2]:find('每次攻击后进入换弹')and tainted[2]:find('1个攻击间隔'))
assert(tainted[2]:find('伤害翻倍')and tainted[2]:find('每次%+1碎心'))
assert(tainted[2]:find('非主动付血')and tainted[2]:find('诅咒房刺门'))
assert(tainted[2]:find('巨人独眼式伪穿透')and tainted[2]:find('保留剩余伤害'))
assert(tainted[2]:find('负射速倍率惩罚减轻')and tainted[2]:find('0.6',1,true))
assert(current.descriptions.en_us.CharacterInfo[1][2]=='unchanged')
local normalText=normal[2]
for i=1,120 do update()end
for _,fn in ipairs(callbacks[15])do fn(mod,false)end
assert(current.registrationCalls==4 and current.descriptions.zh_cn.CharacterInfo[1000][2]==normalText)
-- Actual language selection and Item Reminder route to the correct character.
current:ItemReminderHandleCharacterInfo(player(1001))
assert(current.lastEntry.name=='里猎手'and current.lastEntry.text==tainted[2])
local f=assert(io.open(TEXT_ARTIFACT,'w'))
f:write('里猎手 / EID 角色特性（中文）\n\n',tainted[2]:gsub('{{.-}}%s*',''):gsub('#','\n'),'\n\n')
Options.Language='en';current:ItemReminderHandleCharacterInfo(player(1001))
assert(current.lastEntry.name=='TAINTED HUNTER'and current.lastEntry.text:find('800%%'))
f:write('TAINTED HUNTER / EID character traits (English)\n\n',current.lastEntry.text:gsub('{{.-}}%s*',''):gsub('#','\n'),'\n');f:close()
Options.Language='zh';current:ItemReminderHandleCharacterInfo(player(1000))
assert(current.lastEntry.name=='HUNTER'and current.lastEntry.text==normalText)
local previous=current.lastEntry
current:ItemReminderHandleCharacterInfo(player(1002));assert(current.lastEntry==previous,'No unintended character registration')
-- Fresh EID instance receives the descriptions once, like the regular adapter.
current=actualEID();update();assert(current.registrationCalls==4)
for i=1,30 do update()end;assert(current.registrationCalls==4)
assert(loadfile(MOD_ROOT..'/tainted_hunter_eid.lua'))()(mod,-1);update()
assert(current.registrationCalls==4,'Invalid player type is never registered')
print('Uploaded EID actual API/locale/Item Reminder functions passed: bilingual tainted traits, normal character isolation, late/partial API load, once-per-instance registration, replacement instance and invalid id')
