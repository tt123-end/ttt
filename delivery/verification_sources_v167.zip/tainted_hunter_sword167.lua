-- Original EntityKnife spin state and original renderer/collision only.
-- No replacement art, copied sprite, scripted sweep, or extra manual damage.
return function(mod,playerType,R)
    local S={active={}};local game=Game()
    local function method(object,name)
        local ok,value=pcall(function()return object[name]end)
        return ok and type(value)=='function'and value or nil
    end
    function S.attack(p,dir)
        if not REPENTOGON then
            p:GetData().hunterNativeSword166='REPENTOGON spin API unavailable'
            return nil
        end
        local knife=p:FireKnife(p,0,true,0,10)
        if not knife then p:GetData().hunterNativeSword166='native sword factory returned nil';return nil end
        if not method(knife,'SetIsSpinAttack')or not method(knife,'SetIsSwinging')then
            knife:Remove()
            p:GetData().hunterNativeSword166='REPENTOGON spin API unavailable'
            return nil
        end
        local kd=knife:GetData();kd.owner163=p;kd.aux163=true;kd.spin163=true;kd.nativeSword166=true
        kd.until163=game:GetFrameCount()+45
        -- Spirit Sword's original Spin clip contains its Hit1/Hit2 null
        -- capsules. Start it on the real knife, alongside real engine state.
        -- Generic Shoot() is a thrown-knife operation, not a sword charge release.
        knife.Charge=1;knife.Rotation=dir:GetAngleDegrees()
        knife:SetIsSpinAttack(true);knife:SetIsSwinging(true)
        local sprite=knife:GetSprite();sprite:Play("Spin",true)
        if not sprite:IsPlaying("Spin")then
            knife:Remove();p:GetData().hunterNativeSword166='original sword Spin animation unavailable';return nil
        end
        knife.CollisionDamage=8*p.Damage+10
        -- Keep native art, visibility and collision. The engine
        -- runs its actual spin animation, hitboxes, hit list and reflection.
        S.active[#S.active+1]={owner=p,knife=knife,start=game:GetFrameCount()}
        p:GetData().hunterNativeSword166='native spin active; animation='..knife:GetSprite():GetAnimation()
        return knife
    end
    function S.isActive(p)
        for _,state in ipairs(S.active)do
            if state.owner==p and state.knife:Exists()and not state.knife:IsDead()then return true end
        end
        return false
    end
    function S.isHitbox(knife)
        if not REPENTOGON then return nil end
        local parent
        local getter=method(knife,'GetHitboxParentKnife')
        if getter then parent=getter(knife)end
        if not parent and knife.Parent and knife.Parent.Type==EntityType.ENTITY_KNIFE then parent=knife.Parent end
        if not parent and knife.SpawnerEntity and knife.SpawnerEntity.Type==EntityType.ENTITY_KNIFE then parent=knife.SpawnerEntity end
        if parent and parent:GetData().nativeSword166 then return parent:GetData().owner163 end
        if knife.SubType==4 then
            local p=knife.SpawnerEntity and knife.SpawnerEntity:ToPlayer()
            if p and S.isActive(p)then return p end
        end
    end
    mod:AddCallback(ModCallbacks.MC_POST_UPDATE,function()
        local active={}
        for _,state in ipairs(S.active)do
            local p=state.owner;local k=state.knife;local age=game:GetFrameCount()-state.start
            if k:Exists()then
                if not p:Exists()or p:IsDead()or p:GetPlayerType()~=playerType or age>45 then k:Remove()
                elseif age>3 and method(k,'GetIsSwinging')and not k:GetIsSwinging()then k:Remove()
                else
                    p:GetData().hunterNativeSword166='native spin; animation='..k:GetSprite():GetAnimation()..'; frame='..k:GetSprite():GetFrame()
                    active[#active+1]=state
                end
            end
        end
        S.active=active
    end)
    local function clear()
        for _,state in ipairs(S.active)do if state.knife:Exists()then state.knife:Remove()end end
        S.active={}
    end
    mod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM,clear)
    mod:AddCallback(ModCallbacks.MC_POST_GAME_STARTED,clear)
    return S
end
