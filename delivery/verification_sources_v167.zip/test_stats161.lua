-- Native game contracts are simulated; actual uploaded Stats+ cap function
-- runs below. No hardcoded Brimstone/Haemolacria multiplier feeds this model.
local callbacks={}
ModCallbacks={MC_EVALUATE_CACHE=8,MC_POST_PLAYER_INIT=9,MC_POST_GAME_STARTED=15,MC_POST_PLAYER_UPDATE=31,MC_POST_PEFFECT_UPDATE=4,MC_POST_NEW_ROOM=19}
CacheFlag={CACHE_SPEED=1,CACHE_FIREDELAY=2,CACHE_DAMAGE=4,CACHE_SHOTSPEED=8,CACHE_RANGE=16}
local frame=100;local players={};local log={}
local function approx(a,b)assert(math.abs(a-b)<1e-7,tostring(a)..' ~= '..tostring(b))end
local mod={}
function mod:AddCallback(id,fn)callbacks[id]=callbacks[id]or{};table.insert(callbacks[id],fn)end
function mod:RemoveCallback(id,fn)for i=#callbacks[id],1,-1 do if callbacks[id][i]==fn then table.remove(callbacks[id],i)end end end
local function call(id,...)
 for _,fn in ipairs(callbacks[id]or{})do fn(mod,...)end
end
local function player(kind,index)
 local p={kind=kind,Index=index or 0,data={},items={[373]=1},effects={},base={MoveSpeed=1,Damage=3.5,ShotSpeed=1,TearRange=260},flags=0,tearsBonus=0,a=1,b=0,Hearts=2,MaxHearts=2,card=60,bombs=0,added=0,removed=0,nativeCalls=0}
 function p:GetData()return self.data end
 function p:GetPlayerType()return self.kind end
 function p:HasCollectible(id)return(self.items[id]or 0)>0 end
 function p:GetCollectibleNum(id)return self.items[id]or 0 end
 function p:GetEffects()return{GetCollectibleEffectNum=function(_,id)return self.effects[id]or 0 end,HasCollectibleEffect=function(_,id)return(self.effects[id]or 0)>0 end}end
 function p:GetTrinket(slot)return self.trinkets and self.trinkets[slot]or 0 end
 function p:IsDead()return self.dead or false end
 function p:IsCoopGhost()return false end
 function p:AddCacheFlags(flags)self.flags=self.flags|flags end
 function p:EvaluateItems()
  local flags=self.flags;self.flags=0
  local statFlags={MoveSpeed=1,Damage=4,ShotSpeed=8,TearRange=16}
  for k,v in pairs(self.base)do if flags&statFlags[k]~=0 then self[k]=v end end
  local ups=self.tearsBonus+(self.items[32]or 0)*.7+(self.items[1]or 0)*.7
  local plain=math.max(5,16-6*math.sqrt(math.max(.001,1+1.3*ups)))
  if flags&2~=0 then self.MaxFireDelay=self.a*plain+self.b end
  self.nativeCalls=self.nativeCalls+1
  for _,flag in pairs(CacheFlag)do if flags&flag~=0 then call(8,self,flag)end end
 end
 function p:AddCollectible(id,charge,firstTime)
  assert((charge==nil or charge==0) and firstTime==false,'Probes may not grant pickup effects or active charges')
  self.items[id]=(self.items[id]or 0)+1;self.added=self.added+1
  if self.failAfterAdd then self.failAfterAdd=false;error('simulated native error after insertion')end
  self:AddCacheFlags(2);self:EvaluateItems()
 end
 function p:RemoveCollectible(id,ignoreModifiers)
  assert(id==32 or id==1,'Only our probe or Stats+ test tears-ups may be removed')
  assert((self.items[id]or 0)>0)
  self.items[id]=self.items[id]-1;self.removed=self.removed+1
  self:AddCacheFlags(2);self:EvaluateItems()
 end
 return p
end
Game=function()return{GetFrameCount=function()return frame end,GetNumPlayers=function()return #players end}end
Isaac={GetPlayer=function(i)return players[i+1]end,GetItemConfig=function()return{GetCollectibles=function()return{Size=800}end}end,DebugString=function(s)log[#log+1]=s end}
function include(name)return assert(loadfile(MOD_ROOT..'/'..name..'.lua'))()end
local stats=include('tainted_hunter_stats')(mod,20)
local tears=include('tainted_hunter_tears')
local p=player(20);local normal=player(10,1);players={p,normal}
local function refresh(p) p:AddCacheFlags(31);p:EvaluateItems()end
local function settle(p) refresh(p);call(4,p)end
local function rate(p)return 30/(p.MaxFireDelay+1)end
settle(p)
approx(rate(p),.48);approx(p.Damage,4.2);approx(p.TearRange/40,12)
approx(p.ShotSpeed,1.6);approx(p.MoveSpeed,1);approx(p.data.hunterTears161.capRate,1)
assert(p.items[32]==0 and p.items[373]==1 and p.Hearts==2 and p.MaxHearts==2 and p.bombs==0 and p.card==60)
assert(p.added==p.removed and p.added>1)
local count=p.added;for i=1,30 do refresh(p);call(4,p)end
assert(p.added==count,'Stable native caches must not keep adding probe items')
refresh(normal);call(4,normal);assert(normal.added==0 and normal.data.hunterTears161==nil and normal.Damage==3.5)

-- Approximate raw-delay affine cases, independent of any item-ID multiplier
-- table. For D'=a*D+b with a>=1,b>=0, a pure penalty must never raise current
-- tears, even with large flat delay terms (the old calibration's failure).
local sweeps=0
for _,baseDelay in ipairs({5,6,8,10,20})do
 local baseRate=tears.calculate(baseDelay,5,stats)
 for _,a in ipairs({1,1.1,2,3,10,100,1000000})do
  for _,b in ipairs({0,1,10,30,100,1000000})do
   local native=baseDelay*a+b;local capDelay=5*a+b
   local current,cap=tears.calculate(native,capDelay,stats)
   assert(current<=baseRate+1e-8,'Penalty increased current tears')
   assert(cap>.6 and cap<=1)
   assert(current<=cap+1e-8)
   approx(tears.calculate(capDelay,capDelay,stats),cap)
   sweeps=sweeps+1
  end
 end
end
assert(sweeps==210)
for _,m in ipairs({2,4,5.5})do
 local r,c=tears.calculate(11/m-1,6/m-1,stats)
 approx(r,.48*m);approx(c,m)
end
assert(tears.calculate(2,5,stats)>1,'Above-cap bonuses are not hard-clamped')

-- Reproduce the approximate HUD pair reported for v160 by inverting that
-- old formula; these are derived fixtures, not native game measurements.
local old=assert(loadfile(OLD_ROOT..'/tainted_hunter_tears.lua'))()
local function oldInverse(value)
 local calibrated=value/(.2*(29/45))
 local recovered=30/11+(calibrated-2.4)*(5-30/11)/(5-2.4)
 return 30/(recovered/9)-1
end
local oldStart,oldCap=oldInverse(.67),oldInverse(.87)
local fixturePlayer={HasCollectible=function(_,id)return id==118 or id==531 end}
approx(old.calculate(fixturePlayer,oldStart,stats),.67)
approx(old.calculate(fixturePlayer,oldCap,stats),.87)
local now,cap=tears.calculate(oldStart,oldCap,stats)
assert(now<.48 and cap>.6 and cap<1)
print('Reported-v160 HUD-derived fixture:0.67/0.87 -> '..now..'/'..cap)

-- Native sampler fixture with two penalty items and unknown affine native
-- implementation. Our code observes it rather than guessing1/3 or1/9.
p.items[118]=1;p.items[531]=1;p.a=2;p.b=30
settle(p)
local initialPenalized=rate(p);local expectedCap=tears.softCap(30/41,stats)
assert(initialPenalized<.48);approx(p.data.hunterTears161.capRate,expectedCap)
approx(p.data.hunterTears161.capDelay,40)
assert(p.added==p.removed and p.items[118]==1 and p.items[531]==1)
p.tearsBonus=100;settle(p);approx(rate(p),expectedCap)
p.tearsBonus=0;settle(p);approx(rate(p),initialPenalized)
-- Owned hanger copies survive; new room/dynamic effect sampling reuses native
-- values and cleanup preserves inventory, health and loadout.
p.items[32]=2;call(19);settle(p);assert(p.items[32]==2 and p.added==p.removed)
p.items[32]=0;p.a=3;p.b=40;frame=110;refresh(p);call(4,p)
local before=p.added;frame=200;call(4,p);assert(p.added>before)
approx(p.data.hunterTears161.capDelay,55)
p.items[118]=nil;p.items[531]=nil;p.a=1;p.b=0;refresh(p)
approx(rate(p),.48) -- no one-frame overshoot from the obsolete penalty cap
call(4,p);approx(rate(p),.48)

-- Failed native add cleans up its already-inserted temporary copy.
p.failAfterAdd=true;call(19);settle(p)
assert(p.items[32]==0 and p.added==p.removed and #log>=1)
call(19);settle(p);approx(rate(p),.48)
-- Rock Bottom forbids all sampling; no irreversible stat snapshot is raised.
p.items[562]=1;before=p.added;settle(p);assert(p.added==before)
p.items[562]=nil;settle(p)
-- A temporary native effect invalidates the measured cap without an owned
-- item change; each co-op Hunter keeps a separate cap and probe inventory.
p.effects[118]=1;p.a=3;settle(p);approx(p.data.hunterTears161.capDelay,15)
p.effects[118]=nil;p.a=1;settle(p);approx(rate(p),.48)
local second=player(20,2);second.a=4;second.b=10
players={p,normal,second};settle(second)
approx(second.data.hunterTears161.capDelay,30);approx(p.data.hunterTears161.capDelay,5)
assert(second.added==second.removed and p.added==p.removed)
second.dead=true;call(19);local secondAdds=second.added;call(4,second);assert(second.added==secondAdds)
second.dead=false;call(4,second);assert(second.added>secondAdds)
-- Continue recalculates without granting HP, items, card or bombs.
p.Hearts=3;p.MaxHearts=8;p.card=18;p.items[373]=nil;p.items[99]=2
call(15,true);call(4,p)
assert(p.Hearts==3 and p.MaxHearts==8 and p.card==18 and p.items[373]==nil and p.items[99]==2)
approx(rate(p),.48)
print('v161 native-cache/probe model passed:210 monotonic penalty cases, initial/cap/positive boosts, error cleanup, owned items, dynamic/room/continue isolation, Rock Bottom exclusion')

-- Execute the actual uploaded Stats+ native cap computation and display,
-- with only its game enum/common-format dependencies supplied for this host.
package.path=STATS_ROOT..'/?.lua;'..package.path
package.loaded['lua_modules.isaac-typescript-definitions.dist.index']={CollectibleType={SAD_ONION=1,NUMBER_ONE=6,WIRE_COAT_HANGER=32,TOOTH_PICKS=183,SCREW=255,BAR_OF_SOAP=564,ODD_MUSHROOM_THIN=120,ROCK_BOTTOM=562},ModCallback={EVALUATE_CACHE=8,POST_UPDATE=1}}
package.loaded['lua_modules.@isaac-stats-plus.common.dist.index']={toFixedFormatted=function(_,v,n)return string.format('%.'..n..'f',v)end}
local capApi={stat={tears={addon='stats-plus-core',id='tears-stat'}},provider=function(_,def)return def end}
local capDef=require('lua_modules.@isaac-stats-plus.essentials-addon.dist.providers.tearCapProvider.createTearCapProvider').createTearCapProvider(nil,capApi,mod)
local computes=capDef.computables
p.items[118]=1;p.items[531]=1;p.a=2;p.b=30;settle(p)
local ownedOnion=p.items[1]or 0;local ownedHanger=p.items[32]or 0
local measuredDelay=computes.computeTearCap(computes,p)
approx(30/(measuredDelay+1),expectedCap)
assert(capDef.display.value.format(measuredDelay)=='/0.66')
approx(rate(p),initialPenalized)
assert((p.items[1]or 0)==ownedOnion and p.items[32]==ownedHanger)
before=p.added;frame=400;call(4,p);assert(p.added==before,'Stats+ probe/cleanup must not trigger another native-cap probe')
p.tearsBonus=100;refresh(p);assert(computes.computeTearCap(computes,p)=='MAX')
p.items[562]=1;assert(computes.computeTearCap(computes,p)=='UNKNOWN');p.items[562]=nil
print('Uploaded Stats+ actual computeTearCap/display passed: observed cap/0.66, MAX, UNKNOWN, current restored, no probe feedback loop')

-- Actual uploaded Stats+ validators and damage Middleware.
include('tainted_hunter_stats_plus')(mod,20,stats)
local new=require('lualib_bundle').__TS__New
local function construct(name,...)return new(require(name)[name:match('([^.]+)$')],...)end
local cv=construct('validators.api.APIConditionValidator');local sv=construct('validators.api.APISettingValidator')
local pv=construct('validators.api.APIProviderValidator',sv,cv,construct('validators.api.APIProviderStateValidator'))
local mv=construct('validators.api.APIMiddlewareValidator');local av=construct('validators.api.APIAddonValidator',pv,cv,mv)
local api={stat=capApi.stat}
function api:provider(def)return pv:validate(def)end
function api:middleware(def)return mv:validate(def)end
function api:register(def)self.addon=av:validate(def)end
callbacks.STATS_PLUS_REGISTER[1](mod,api)
local addon=api.addon;assert(#addon.middleware==1 and #addon.providers==1)
local middleware=construct('entities.extension.middleware.Middleware',addon.id,addon.middleware[1])
approx(middleware:intercept({p},1).value,1.2);approx(middleware:intercept({p},2).value,2.4)
approx(middleware:intercept({normal},1.2).value,1.2)
local provider=addon.providers[1];local value=provider.state.multiplier.initial()
local ctx={player=p,state={multiplier={current=function()return value end,set=function(_,v)value=v end}}}
local destroy=provider.mount(ctx);approx(value,.2);assert(provider.display.value.format(value)=='x0.20')
destroy()
print('Uploaded Stats+ validators/Middleware passed: x1.20 damage composes, x0.20 tears unchanged')
