-- Actual module, mocked vanilla damage pipeline and native heart capacities.
local frame=100;local room=1;local callbacks={}
ModCallbacks={MC_ENTITY_TAKE_DMG=11,MC_POST_PEFFECT_UPDATE=4,MC_POST_PLAYER_INIT=9}
CallbackPriority={LATE=100};EntityType={ENTITY_PLAYER=1,ENTITY_SLOT=6,ENTITY_PROJECTILE=9}
RoomType={ROOM_SACRIFICE=13}
DamageFlag={DAMAGE_NOKILL=1,DAMAGE_FIRE=1<<1,DAMAGE_EXPLOSION=1<<2,DAMAGE_LASER=1<<3,DAMAGE_RED_HEARTS=1<<5,DAMAGE_COUNTDOWN=1<<6,DAMAGE_SPIKES=1<<7,DAMAGE_DEVIL=1<<10,DAMAGE_INVINCIBLE=1<<13,DAMAGE_CURSED_DOOR=1<<16,DAMAGE_TIMER=1<<17,DAMAGE_IV_BAG=1<<18,DAMAGE_CHEST=1<<20,DAMAGE_FAKE=1<<21,DAMAGE_NO_MODIFIERS=1<<25,DAMAGE_NO_PENALTIES=1<<28}
Game=function()return {GetFrameCount=function()return frame end,GetRoom=function()return {GetType=function()return room end}end}end
local mod={}
function mod:AddCallback(id,fn,filter)
 callbacks[id]=callbacks[id]or{};table.insert(callbacks[id],{fn=fn,priority=0,filter=filter})
end
function mod:AddPriorityCallback(id,priority,fn,filter)
 self:AddCallback(id,fn,filter);callbacks[id][#callbacks[id]].priority=priority
end
local function call(id,...)
 table.sort(callbacks[id]or{},function(a,b)return a.priority<b.priority end)
 for _,entry in ipairs(callbacks[id]or{})do
  local result=entry.fn(mod,...)
  if result~=nil then return result end
 end
end
local enemy={Entity={Type=10,Variant=0}}
local function player(kind,red,soul)
 local p={kind=kind or 20,data={},red=red or 8,soul=soul or 0,max=red or 8,bone=0,broken=0,alive=true,invuln=false,applied={},nativeCalls=0,brokenAwards=0,queued={}}
 function p:GetPlayerType()return self.kind end
 function p:ToPlayer()return self end
 function p:GetData()return self.data end
 function p:GetHearts()return self.red end
 function p:GetMaxHearts()return self.max end
 function p:GetBrokenHearts()return self.broken end
 function p:GetLastDamageFlags()return self.lastFlags or 0 end
 function p:GetLastDamageSource()return self.lastSource or {Type=0,Variant=0}end
 function p:IsDead()return not self.alive end
 function p:AddBrokenHearts(n)
  self.broken=self.broken+n
  if n>0 then self.brokenAwards=self.brokenAwards+1 end
  -- Model native capacity trimming, not one manually removed red container.
  self.max=math.min(self.max,math.max(0,24-self.broken*2))
  self.red=math.min(self.red,self.max)
  if self.max==0 and self.soul==0 and self.bone==0 then self.alive=false end
 end
 function p:commit(amount,flags,source,countdown)
  self.lastFlags,self.lastSource=flags,source
  table.insert(self.applied,{amount=amount,flags=flags,source=source,countdown=countdown})
  if flags&DamageFlag.DAMAGE_FAKE~=0 then return true end
  if self.shellFirst then self.bone=math.max(0,self.bone-1)
  elseif flags&DamageFlag.DAMAGE_RED_HEARTS~=0 then self.red=math.max(0,self.red-amount)
  else
   local absorbed=math.min(self.soul,amount);self.soul=self.soul-absorbed
   self.red=math.max(0,self.red-(amount-absorbed))
  end
  if self.convertType then self.kind=self.convertType end
  if self.red==0 and self.soul==0 and self.bone==0 then self.alive=false end
  if self.capacityAfterHit then self.max=self.capacityAfterHit end
  return true
 end
 function p:TakeDamage(amount,flags,source,countdown)
  self.nativeCalls=self.nativeCalls+1
  if self.invuln then return false end
  if call(11,self,amount,flags,source,countdown)==false then return false end
  if self.shield then
   self.shield=false
   return self.shieldReturnsTrue or false
  end
  if self.cancel then return false end
  if self.fail then error('simulated engine failure')end
  if self.defer then
   self.queued[#self.queued+1]={amount,flags,source,countdown}
   return true
  end
  return self:commit(amount,flags,source,countdown)
 end
 function p:flushDamage()
  local queued=self.queued;self.queued={}
  for _,event in ipairs(queued)do self:commit(table.unpack(event))end
 end
 return p
end
local function busy(p)return p.busy or false end
assert(loadfile(MOD_ROOT..'/tainted_hunter_damage.lua'))()(mod,20,busy)
local checks=0
local function checkDamage(flags,source,expected,options)
 local p=player(20,10)
 for k,v in pairs(options or{})do p[k]=v end
 p:TakeDamage(1,flags,source,30)
 assert(p.broken==expected,'flags='..tostring(flags)..' broken='..tostring(p.broken)..' expected='..tostring(expected))
 if expected>0 then assert(p.brokenAwards==1)end
 assert(not(p.data.hunterRedDamage157 and p.data.hunterRedDamage157.processing))
 checks=checks+1;return p
end
-- Successful actual red HP hits: all count once, independent of amount.
checkDamage(0,enemy,1)
checkDamage(DamageFlag.DAMAGE_COUNTDOWN,enemy,1)
checkDamage(DamageFlag.DAMAGE_RED_HEARTS,enemy,1) -- hostile red-targeting is not a payment
checkDamage(DamageFlag.DAMAGE_FIRE,{Type=33,Variant=0},1)
checkDamage(DamageFlag.DAMAGE_EXPLOSION,{Type=4,Variant=0},1) -- own bombs are still mistakes
checkDamage(DamageFlag.DAMAGE_SPIKES,{Type=0,Variant=0},1)
local p=player(20,10);p:TakeDamage(4,0,enemy,30);assert(p.red==6 and p.broken==1)
-- Reload doubles once and adds one broken heart, not two.
local p=checkDamage(0,enemy,1,{busy=true})
assert(p.red==8 and #p.applied==1 and p.applied[1].amount==2 and p.nativeCalls==2)
local p=player(20,10);p.busy=true;p:TakeDamage(2,DamageFlag.DAMAGE_COUNTDOWN,enemy,17)
assert(p.red==6 and p.broken==1 and #p.applied==1)
assert(p.applied[1].flags==DamageFlag.DAMAGE_COUNTDOWN and p.applied[1].source==enemy and p.applied[1].countdown==17)
-- Soul-only, shield, invulnerability, cancellation and fake hits do not count.
local p=player(20,8,6);p:TakeDamage(1,0,enemy,30);assert(p.red==8 and p.soul==5 and p.broken==0)
frame=103;call(4,p);assert(p.broken==0)
checkDamage(0,enemy,0,{shield=true})
checkDamage(0,enemy,0,{shield=true,shieldReturnsTrue=true})
checkDamage(0,enemy,0,{invuln=true})
checkDamage(0,enemy,0,{cancel=true})
checkDamage(DamageFlag.DAMAGE_FAKE,enemy,0,{busy=true})
-- Damage that reaches red HP after consuming soul protection counts.
local p=player(20,8,1);p:TakeDamage(2,0,enemy,30);assert(p.soul==0 and p.red==7 and p.broken==1)
-- Bone shell vs red fill: only loss of red fill counts.
local p=player(20,0,4);p.bone=1;p.shellFirst=true;p:TakeDamage(1,0,enemy,30);assert(p.bone==0 and p.broken==0)
local p=player(20,2,4);p.bone=1;p:TakeDamage(5,0,enemy,30);assert(p.red==1 and p.broken==1)
-- Required and related transaction flags, also in combination with ordinary flags.
for _,flag in ipairs({DamageFlag.DAMAGE_DEVIL,DamageFlag.DAMAGE_IV_BAG,DamageFlag.DAMAGE_CURSED_DOOR,DamageFlag.DAMAGE_CHEST,DamageFlag.DAMAGE_RED_HEARTS,DamageFlag.DAMAGE_NO_PENALTIES})do
 checkDamage(flag,{},0)
 local p=checkDamage(flag|DamageFlag.DAMAGE_COUNTDOWN,{},0,{busy=true})
 assert(p.red==8 and #p.applied==1,'Exclusion changes broken hearts only, not reload vulnerability')
end
-- Source fallback works if an engine/mod omitted its usual transaction flags.
for _,variant in ipairs({2,5,15,17})do
 checkDamage(0,{Entity={Type=6,Variant=variant}},0)
 checkDamage(0,{Type=6,Variant=variant},0)
end
-- Sacrifice spike only; nearby enemies and projectiles still count.
room=RoomType.ROOM_SACRIFICE
checkDamage(DamageFlag.DAMAGE_SPIKES,{Type=0,Variant=0},0)
checkDamage(DamageFlag.DAMAGE_SPIKES,enemy,1)
checkDamage(0,enemy,1)
checkDamage(DamageFlag.DAMAGE_SPIKES,{Type=9,Variant=0},1)
room=1
checkDamage(DamageFlag.DAMAGE_SPIKES,{Type=0,Variant=0},1)
-- Exempt hit cannot arm a later delayed penalty in reload mode.
local p=player(20,10);p.busy=true;p.defer=true
p:TakeDamage(1,DamageFlag.DAMAGE_IV_BAG,{},30)
p:flushDamage();frame=104;call(4,p);assert(p.red==8 and p.broken==0)
-- Deferred successful native damage is checked after it actually settles.
local p=player(20,10);p.defer=true
p:TakeDamage(1,0,enemy,30);assert(p.red==10 and p.broken==0)
p:flushDamage();frame=105;call(4,p);assert(p.red==9 and p.broken==1)
for i=1,5 do frame=frame+1;call(4,p)end;assert(p.broken==1)
-- Deferred soul-only hit still never counts; stale observations expire.
local p=player(20,8,4);p.defer=true;p:TakeDamage(1,0,enemy,30);p:flushDamage();frame=111;call(4,p);assert(p.broken==0)
frame=114;call(4,p);p.red=7;call(4,p);assert(p.broken==0)
-- A successful shield followed by a donation cannot be attributed to the shielded hit.
local p=player(20,10);p.shield=true;p.shieldReturnsTrue=true;p:TakeDamage(1,0,enemy,30)
p:TakeDamage(1,DamageFlag.DAMAGE_RED_HEARTS,{},30);frame=115;call(4,p);assert(p.red==9 and p.broken==0)
-- Direct container purchases do not become a penalty through a pending shield.
local p=player(20,10);p.shield=true;p.shieldReturnsTrue=true;p:TakeDamage(1,0,enemy,30)
p.max=8;p.red=8;call(4,p);assert(p.broken==0)
-- A delayed damage observation with a different committed source is discarded.
local p=player(20,10);p.defer=true;p:TakeDamage(1,0,enemy,30);p:flushDamage()
p.lastFlags=DamageFlag.DAMAGE_NO_PENALTIES;call(4,p);assert(p.broken==0)
-- No whole-run HP watcher: pickups, spending containers and direct health changes
-- without an associated eligible damage event never add broken hearts.
local p=player(20,8);p.red=4;p.max=4;call(4,p);assert(p.broken==0)
-- Native capacity limit can trim HP, but the added broken heart is not another hit.
local p=player(20,24);p:TakeDamage(1,0,enemy,0)
assert(p.broken==1 and p.brokenAwards==1 and p.max==22 and p.red==22)
call(4,p);assert(p.broken==1)
-- Removing broken hearts remains allowed; no stored count re-adds them.
p:AddBrokenHearts(-1);call(4,p);assert(p.broken==0)
-- Status is kept by the engine; init/reload only discards transient observations.
local p=player(20,8);p.broken=3;call(9,p);assert(p.broken==3)
-- Two actual hits in one frame each count once, no global frame deduplication.
local p=player(20,10);p:TakeDamage(1,0,enemy,0);p:TakeDamage(1,0,enemy,0);assert(p.red==8 and p.broken==2)
-- Other characters, dead players and type changes are isolated.
local p=player(10,10);p.busy=true;p:TakeDamage(1,0,enemy,0);assert(p.red==9 and p.broken==0 and p.data.hunterRedDamage157==nil)
local p=player(20,2);p.busy=true;p:TakeDamage(1,0,enemy,0);assert(not p.alive and p.broken==1)
-- Fatal red hits still count; native extra-life handling decides what survives resurrection.
local p=player(20,2);p.defer=true;p:TakeDamage(2,0,enemy,0);p:flushDamage()
call(4,p);assert(not p.alive and p.broken==1)
local p=player(20,8);p.convertType=6;p:TakeDamage(1,0,enemy,0);assert(p.broken==0 and p.kind==6)
local p1,p2=player(20,10),player(20,10);p1.busy=true
p1:TakeDamage(1,0,enemy,0);p2:TakeDamage(1,0,enemy,0)
assert(p1.red==8 and p2.red==9 and p1.broken==1 and p2.broken==1)
-- Error paths release the recursion guard and propagate the error.
local p=player(20,10);p.fail=true
assert(not pcall(p.TakeDamage,p,1,0,enemy,0));assert(not p.data.hunterRedDamage157.processing)
print('Red-heart damage tests passed: '..checks..' parameterized hit/exclusion cases plus double-damage, deferred/same-frame attribution, shields, soul/bone hearts, capacities, persistence/type isolation and cleanup scenarios')
