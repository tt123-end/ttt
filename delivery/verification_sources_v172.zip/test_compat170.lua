-- Deterministic engine-contract simulation. This is NOT a running Isaac game.
local frame=100;local roomIndex=0;local entities={};local players={};local callbacks={};local nextSeed=1000
local renderLog={}
local spriteCreates=0
local nativeBases=setmetatable({}, {__mode="k"})
REPENTOGON={}
InputHook={GET_ACTION_VALUE=2,IS_ACTION_PRESSED=0,IS_ACTION_TRIGGERED=1}
local storedJSON
package.preload.json=function()return{encode=function(v)storedJSON=v;return 'saved' end,decode=function()return storedJSON end}end
ModCallbacks={MC_ENTITY_TAKE_DMG=11,MC_POST_PEFFECT_UPDATE=4,MC_POST_PLAYER_INIT=9,MC_POST_RENDER=2,MC_POST_FIRE_TEAR=61,MC_POST_TEAR_UPDATE=40,MC_POST_TEAR_INIT=39,MC_PRE_TEAR_COLLISION=42,MC_POST_LASER_UPDATE=48,MC_POST_KNIFE_UPDATE=45,MC_POST_EFFECT_UPDATE=55,MC_POST_ENTITY_REMOVE=67,MC_POST_UPDATE=1,MC_POST_NEW_ROOM=19,MC_POST_GAME_STARTED=15,MC_PRE_GAME_EXIT=17,MC_PRE_USE_ITEM=64,MC_EVALUATE_CACHE=8,MC_POST_BOMB_UPDATE=58,MC_POST_GAME_END=16,MC_EXECUTE_CMD=22}
EntityType={ENTITY_PLAYER=1,ENTITY_TEAR=2,ENTITY_FAMILIAR=3,ENTITY_BOMBDROP=4,ENTITY_PICKUP=5,ENTITY_SLOT=6,ENTITY_LASER=7,ENTITY_KNIFE=8,ENTITY_PROJECTILE=9,ENTITY_EFFECT=1000}
EntityFlag={FLAG_FRIENDLY=1};CallbackPriority={LATE=100}
DamageFlag={DAMAGE_FIRE=2,DAMAGE_LASER=8,DAMAGE_FAKE=1<<21,DAMAGE_EXPLOSION=1<<2,DAMAGE_RED_HEARTS=1<<5,DAMAGE_SPIKES=1<<7,DAMAGE_DEVIL=1<<10,DAMAGE_IV_BAG=1<<18,DAMAGE_CURSED_DOOR=1<<16,DAMAGE_CHEST=1<<20,DAMAGE_NO_PENALTIES=1<<28,DAMAGE_POISON_BURN=1<<23}
CacheFlag={CACHE_DAMAGE=4,CACHE_FIREDELAY=2,CACHE_FAMILIARS=64}
ButtonAction={ACTION_DROP=11,ACTION_SHOOTLEFT=4,ACTION_SHOOTRIGHT=5,ACTION_SHOOTUP=6,ACTION_SHOOTDOWN=7};UseFlag={USE_NOANIM=1,USE_NOCOSTUME=2}
RoomType={ROOM_SACRIFICE=13};NullItemID={ID_LOST_CURSE=112}
WeaponType={WEAPON_SPIRIT_SWORD=13,WEAPON_BONE=10,WEAPON_NOTCHED_AXE=11,WEAPON_URN_OF_SOULS=12,WEAPON_UMBILICAL_WHIP=15}
TearVariant={BLUE=0,TOOTH=2,SCHYTHE=8,RAZOR=28,STONE=22,FETUS=50,SWORD_BEAM=47}
LaserVariant={BRIM_TECH=9,LIGHT_BEAM=5};EffectVariant={ROCKET=31,POOF01=15}
PickupVariant={PICKUP_COIN=20};CoinSubType={COIN_PENNY=1}
FamiliarVariant={INCUBUS=80,TWISTED_BABY=235,ABEL=8,FATES_REWARD=81,CAINS_OTHER_EYE=76,MONGO_BABY=74,PAPA_FLY=99,MULTIDIMENSIONAL_BABY=101,SPRINKLER=120,MINISAAC=228,UMBILICAL_BABY=240,BLOOD_BABY=238}
PlayerForm={PLAYERFORM_BABY=7,PLAYERFORM_BOOK_WORM=10}
ModCallbacks.MC_POST_WEAPON_FIRE=1105;ModCallbacks.MC_INPUT_ACTION=13;ModCallbacks.MC_PRE_PLAYER_UPDATE=1160;ModCallbacks.MC_POST_PLAYER_UPDATE=31;ModCallbacks.MC_POST_FIRE_SWORD=1258;ModCallbacks.MC_POST_FIRE_TECH_LASER=1259;ModCallbacks.MC_POST_ENTITY_TAKE_DMG=1006;ModCallbacks.MC_PRE_LASER_COLLISION=1248;ModCallbacks.MC_POST_LASER_COLLISION=1249;ModCallbacks.MC_PRE_PLAYER_TAKE_DMG=1008;ModCallbacks.MC_POST_LASER_INIT=27;ModCallbacks.MC_USE_CARD=23;ModCallbacks.MC_USE_PILL=10
TearFlags={TEAR_NORMAL=0}
for i,name in ipairs({'TEAR_PERSISTENT','TEAR_EXPLOSIVE','TEAR_FETUS_BOMBER','TEAR_FETUS_BRIMSTONE','TEAR_FETUS_TECHX','TEAR_FETUS_SWORD','TEAR_GODS_FLESH','TEAR_GREED_COIN','TEAR_COIN_DROP','TEAR_HORN','TEAR_FETUS','TEAR_FETUS_KNIFE','TEAR_FETUS_BONE','TEAR_FETUS_TECH','TEAR_HOMING','TEAR_SPECTRAL','TEAR_LASERSHOT','TEAR_PIERCING','TEAR_GLOW'})do TearFlags[name]=1<<(i-1)end
local V={};V.__index=V
function Vector(x,y)return setmetatable({X=x,Y=y},V)end
function VectorFromAngle(a)return Vector(math.cos(math.rad(a)),math.sin(math.rad(a)))end
-- Lua functions cannot hold fields; expose the engine's callable Vector table.
local vectorFn=Vector;Vector=setmetatable({FromAngle=VectorFromAngle},{__call=function(_,x,y)return vectorFn(x,y)end})
function V:Length()return math.sqrt(self.X*self.X+self.Y*self.Y)end
function V:Normalized()local l=self:Length();return l>0 and Vector(self.X/l,self.Y/l)or Vector(0,0)end
function V:Rotated(a)local r=math.rad(a);return Vector(self.X*math.cos(r)-self.Y*math.sin(r),self.X*math.sin(r)+self.Y*math.cos(r))end
function V:GetAngleDegrees()return math.deg(math.atan(self.Y,self.X))end
function V.__add(a,b)return Vector(a.X+b.X,a.Y+b.Y)end
function V.__sub(a,b)return Vector(a.X-b.X,a.Y-b.Y)end
function V.__mul(a,b)if type(a)=='number'then return Vector(a*b.X,a*b.Y)end;return Vector(a.X*b,a.Y*b)end
function Color(r,g,b,a,ro,go,bo)return{R=r,G=g,B=b,A=a,RO=ro or 0,GO=go or 0,BO=bo or 0}end
function Sprite()
 spriteCreates=spriteCreates+1
 local s={file='',anim='',frame=0,Color=Color(1,1,1,1)}
 function s:Load(f)self.file=f end;function s:IsLoaded()return true end;function s:GetFilename()return self.file end
 function s:Play(a)self.anim=a;self.frame=0 end;function s:IsPlaying(a)return self.anim==a end
 function s:GetAnimation()return self.anim end;function s:GetFrame()return self.frame end
 function s:SetFrame(a,b)self.frame=b or a;if b then self.anim=a end end
 function s:Update()self.frame=self.frame+1 end;function s:Render()renderLog[self.file]=(renderLog[self.file]or 0)+1 end
 return s
end
local mod={}
function mod:AddCallback(id,fn,filter)callbacks[id]=callbacks[id]or{};callbacks[id][#callbacks[id]+1]={fn=fn,priority=0,filter=filter}end
function mod:AddPriorityCallback(id,priority,fn,filter)self:AddCallback(id,fn,filter);callbacks[id][#callbacks[id]].priority=priority end
function mod:HasData()return self.saved~=nil end;function mod:LoadData()return self.saved end;function mod:SaveData(s)self.saved=s end
local function call(id,...)
 local args={...};local list=callbacks[id]or{};table.sort(list,function(a,b)return a.priority<b.priority end)
 for _,entry in ipairs(list)do
  if not entry.filter or id~=11 or entry.filter==args[1].Type then
   local result=entry.fn(mod,table.unpack(args))
   if id==11 and type(result)=='table'then args[2]=result.Damage or args[2]
   elseif result~=nil then return result end
  end
 end
 if id==11 then return {Damage=args[2]}end
end
local function approx(a,b)assert(math.abs(a-b)<1e-6,tostring(a)..' ~= '..tostring(b))end
local function baseView(e)
 return setmetatable({}, {__index=function(_,key)
  assert(key~='CanTriggerStreakEnd'and key~='Timeout'and key~='TearFlags','no member named '..key)
  local v=e[key];if type(v)=='function'then return function(_,...)return v(e,...)end end;return v
 end,__newindex=function(_,key)error('no member named '..key)end})
end
local function entity(kind,variant,parent)
 nextSeed=nextSeed+1
 local e={Type=kind,Variant=variant or 0,SubType=0,SpawnerEntity=parent,Parent=nil,Position=parent and parent.Position or Vector(0,0),Velocity=Vector(1,0),InitSeed=nextSeed,FrameCount=0,CollisionDamage=0,Size=4,SizeMulti=Vector(1,1),Scale=1,TearFlags=0,CanTriggerStreakEnd=true,removed=false,data={},sprite=Sprite(),Visible=true,Color=Color(1,1,1,1)}
 e.sprite:Load('gfx/native.anm2');e.sprite:Play('Idle')
 function e:GetData()return self.data end;function e:GetSprite()return self.sprite end
 function e:Exists()return not self.removed end;function e:IsDead()return self.dead or false end
 function e:ToPlayer()if self.Type==1 then return self end end;function e:ToTear()if self.Type==2 then return self end end
 function e:ToFamiliar()if self.Type==3 then return self end end;function e:ToLaser()if self.Type==7 then return self end end
 function e:ToKnife()if self.Type==8 then return self end end
 function e:ToNPC()if self.Type>=10 and self.Type<1000 then return self end end
 function e:IsVulnerableEnemy()return not self.dead and not self.invulnerable end
 function e:HasEntityFlags(flag)return self.friendly or false end
 function e:AddTearFlags(f)self.TearFlags=self.TearFlags|f end;function e:ClearTearFlags(f)self.TearFlags=self.TearFlags&~f end
 function e:HasTearFlags(f)return self.TearFlags&f~=0 end
 function e:ChangeVariant(v)self.Variant=v end
 function e:SetSize(size,multi,points)self.Size=size;self.SizeMulti=multi;self.points=points end
 function e:SetTimeout(n)self.Timeout=n end;function e:Shoot(charge,range)self.Charge=charge;self.MaxDistance=range end
 function e:CollidesWithGrid()return self.grid or false end
 function e:Remove()
  if self.removed then return end
  if self.Type==2 and self.CanTriggerStreakEnd and self.SpawnerEntity and self.SpawnerEntity.Type==1 and self.SpawnerEntity:HasCollectible(373)then
   self.SpawnerEntity:ClearDeadEyeCharge()
  end
  self.removed=true;call(67,baseView(self))
 end
 function e:TakeDamage(n,flags,source,countdown)
  if self.invulnerable or self.dead then return false end
  if self.Type==1 then call(1008,self,n,flags,source,countdown)end
  local result=call(11,self,n,flags,source,countdown)
  if result==false then return false end
  n=type(result)=='table'and result.Damage or n
  if self.Type==1 then
   if self.shield then self.shield=false;return false end
   local a=math.min(self.soul,n);self.soul=self.soul-a;self.red=math.max(0,self.red-(n-a));self.lastFlags=flags
  else self.HitPoints=self.HitPoints-n;if self.HitPoints<=0 then self.dead=true end end
  call(1006,baseView(self),n,flags,source,countdown)
  return true
 end
 setmetatable(e,{__index=function(self,key)if key=='BaseDamage'then return nativeBases[self]or 0 end end,
  __newindex=function(self,key,value)assert(key~='BaseDamage','BaseDamage is read-only');rawset(self,key,value)end})
 entities[#entities+1]=e;return e
end
local bombs={};local game={}
function game:GetFrameCount()return frame end;function game:GetNumPlayers()return #players end;function game:IsPaused()return false end
function game:GetLevel()return{GetStage=function()return 1 end,GetCurrentRoomIndex=function()return roomIndex end}end
function game:GetSeeds()return{GetStartSeed=function()return 12345 end}end
function game:GetRoom()return{GetType=function()return 1 end,GetFrameCount=function()return fixtureRoomFrame or 10 end,GetGridCollisionAtPos=function()return 0 end}end
function game:BombExplosionEffects(pos,damage,flags,color,source,scale,line,selfDamage,damageFlags)bombs[#bombs+1]={damage=damage,flags=flags,selfDamage=selfDamage,source=source}end
function game:MoveToRandomRoom(errorRoom,seed,p)
 assert(not errorRoom and seed>0 and seed<=2147483646)
 p.teleports=(p.teleports or 0)+1;p.teleportPhase=fixturePhase
end
Game=function()return game end
Isaac={GetItemIdByName=function(name)return name=="Hunter Chocolate Milk"and 9002 or 9001 end,GetPlayer=function(i)return players[i+1]end,GetScreenHeight=function()return 400 end,WorldToScreen=function(p)return p end,
 Spawn=function(kind,var,sub,pos,vel,parent)local e=entity(kind,var,parent);e.SubType=sub;e.Position=pos;e.Velocity=vel;return e end,DebugString=function()end}
Input={IsActionTriggered=function()return false end}
EntityRef=function(e)return{Entity=e}end
function include(name)return assert(loadfile(MOD_ROOT..'/'..name..'.lua'))()end
local function player(items,kind)
 local p=entity(1);p.kind=kind or 20;p.items=items or{};p.effects={};p.damageFlags=0;p.red=2;p.max=2;p.bone=0;p.soul=0;p.broken=0
 p.Damage=4.2;p.MaxFireDelay=61.5;p.FireDelay=0;p.ShotSpeed=1.6;p.TearRange=480;p.ControllerIndex=#players;p.Luck=0;p.input=Vector(0,0);p.rngValues={};p.charges=0;p.clears=0
 p.weaponCharge=37
 local weapon={delay=0}
 function weapon:SetCharge(n)p.weaponCharge=n end
 function weapon:GetCharge()return p.weaponCharge end
 function weapon:SetFireDelay(n)self.delay=n end
 function weapon:GetFireDelay()return self.delay end
 function weapon:GetMaxCharge()return 30 end
 function weapon:GetOwner()return p end
 function weapon:GetMainEntity()return p.nativeMainSword and baseView(p.nativeMainSword)end
 function weapon:GetWeaponType()return p.missingSwordWeapon and 1 or(p:HasCollectible(579)and 13 or 1)end
 function p:GetWeapon(slot)assert(slot==1);return weapon end
 function p:GetPlayerType()return self.kind end
 function p:GetCollectibleNum(id)return self.items[id]or 0 end;function p:HasCollectible(id)return(self.items[id]or 0)>0 end
 function p:AddCollectible(id,_,first)assert(first==false);self.items[id]=(self.items[id]or 0)+1 end
 function p:RemoveCollectible(id)assert((self.items[id]or 0)>0);self.items[id]=self.items[id]-1 end
 function p:GetEffects()
  local e={}
  function e:GetCollectibleEffectNum(id)return p.effects[id]or 0 end
  function e:HasCollectibleEffect(id)return(p.effects[id]or 0)>0 end
  function e:AddCollectibleEffect(id,_,n)p.effects[id]=(p.effects[id]or 0)+(n or 1)end
  function e:RemoveCollectibleEffect(id,n)p.effects[id]=math.max(0,(p.effects[id]or 0)-(n or 1))end
  function e:HasNullEffect()return false end
  return e
 end
 function p:GetCollectibleRNG(id)return{RandomFloat=function()return self.rngValues[id]or .99 end,RandomInt=function(_,n)return math.floor((self.rngValues[id]or .99)*n)end}end
 function p:HasWeaponType(id)return self.weaponType==id end
 function p:HasPlayerForm(id)return self.forms and self.forms[id]or false end
 function p:GetTrinketMultiplier(id)return self.trinkets and self.trinkets[id]or 0 end
 function p:CanShoot()return true end;function p:AreControlsEnabled()return true end;function p:IsExtraAnimationFinished()return true end;function p:IsCoopGhost()return false end
 function p:GetShootingInput()return self.input end;function p:GetAimDirection()return self.input end
 function p:HasFullHearts()return self.red>=self.max end
 function p:GetHearts()return self.red end;function p:GetMaxHearts()return self.max end;function p:GetSoulHearts()return self.soul end;function p:GetBoneHearts()return self.bone end
 function p:GetLastDamageFlags()return self.lastFlags or 0 end;function p:GetLastDamageSource()return{}end
 function p:AddBrokenHearts(n)self.broken=self.broken+n end
 function p:AddDeadEyeCharge()self.charges=self.charges+1 end;function p:ClearDeadEyeCharge()self.clears=self.clears+1 end
 function p:AddCacheFlags()end;function p:EvaluateItems()end
 function p:UseActiveItem(id)self.lastUsed=id;self.useCount=(self.useCount or 0)+1 end
 function p:FireTear(position,velocity,canEye,noTractor,streak,source,multiplier)
  if self.failFire then error('simulated fire failure')end
  local t=entity(2,self.nextVariant or 0,source or self);t.Position=position;t.Velocity=velocity;t.CanTriggerStreakEnd=streak
  t.CollisionDamage=self.Damage*(self.nextFactor or 1)*(multiplier or 1);nativeBases[t]=t.CollisionDamage;t.TearFlags=self.nativeFlags or 0
  call(39,t);call(61,t);return t
 end
 function p:FireTechLaser(position,offset,dir,left,oneHit,source,multiplier)
 local l=entity(7,2,source);l.Position=position;l.OneHit=oneHit;l.Direction=dir;l.CollisionDamage=self.Damage*(multiplier or 1)
 call(27,l);call(1259,l);return l
 end
 function p:FireBrimstone(dir,source,multiplier)local l=entity(7,1,source);l.CollisionDamage=self.Damage*multiplier;l.Direction=dir;self.brimCount=(self.brimCount or 0)+1;return l end
 function p:FireTechXLaser(position,dir,radius,source,multiplier)local l=entity(7,2,source);l.Position=position;l.Radius=radius;l.CollisionDamage=self.Damage*(multiplier or 1);return l end
 function p:FireKnife(parent,angle,cant,sub,variant)
 local k=entity(8,variant,parent);k.Parent=parent;k.SubType=sub;k.CollisionDamage=3*self.Damage+3.5;k.EntityCollisionClass=4
 local ordinaryPlay=k.sprite.Play
 function k.sprite:Play(anim,force)if anim~='Spin'then ordinaryPlay(self,anim,force)end end
 if REPENTOGON and not self.missingSwordAPI then
  function k:SetIsSpinAttack(v)self.nativeSpin=v end
  function k:SetIsSwinging(v)self.nativeSwing=v end
  function k:GetIsSpinAttack()return self.nativeSpin end
  function k:GetIsSwinging()return self.nativeSwing end
 end
 return k
 end
 players[#players+1]=p;call(9,p);return p
end
mod.HunterCompat163=include('tainted_hunter_compat')(mod,20)
include('tainted_hunter_combat')(mod,20)
local C=mod.HunterCompat163;local R=C.rules
local function tick(p,n)
 for i=1,n or 1 do
  frame=frame+1
  -- Model both relevant integration boundaries: input cached before PRE,
  -- and Weapon::Fire running after the player's POST update callback.
  fixturePhase='input_cache'
  local function val(action,default)local r=call(13,p,2,action);return r==nil and default or r end
  local cached=Vector(val(5,math.max(0,p.input.X))-val(4,math.max(0,-p.input.X)),val(7,math.max(0,p.input.Y))-val(6,math.max(0,-p.input.Y)))
  local held=cached:Length()>.01
  local action=math.abs(cached.X)>math.abs(cached.Y)and(cached.X>0 and 5 or 4)or(cached.Y>0 and 7 or 6)
  local triggered=call(13,p,1,action);if triggered==nil then triggered=held and not p.nativeHeld end
  fixturePhase='native_player';call(1160,p);call(4,p);call(31,p)
  fixturePhase='late_weapon'
  local w=p:GetWeapon(1)
  if w:GetWeaponType()==13 and p.FireDelay<=0 and w:GetFireDelay()<=0 then
   if held then
    if not p.nativeMainSword and triggered then
     local k=entity(8,10,p);k.Parent=p;k.nativeSpin=false;k.nativeSwing=true;k.CollisionDamage=3*p.Damage+3.5;k.EntityCollisionClass=4;k.sprite:Play('SwingDown')
     function k:GetIsSpinAttack()return self.nativeSpin end
     function k:GetIsSwinging()return self.nativeSwing end
     p.nativeMainSword=k;call(1258,k)
    end
    local k=p.nativeMainSword
    if k then k.nativeSpin=false;call(45,k)end
   elseif p.nativeHeld and w:GetCharge()>=w:GetMaxCharge()then
    local k=p.nativeMainSword
    if k then
     -- A reused native main entity changes to Spin without another factory
     -- callback. The script must discover the actual engine state.
     k.nativeSpin=true;k.nativeSwing=true;k.CollisionDamage=8*p.Damage+10;k.sprite:Play('Spin')
     call(45,k)
     local hit=entity(8,10,p);hit.SubType=4;hit.Parent=k;call(45,hit)
     p.nativeSpinCount=(p.nativeSpinCount or 0)+1
    end
   end
   call(1105,w,cached,held,false)
   p.nativeHeld=held
  end
  fixturePhase='post_update';call(1);fixturePhase=nil
 end
end
local function latest(kind,p)
 for i=#entities,1,-1 do local e=entities[i];if e.Type==kind and(not p or e:GetData().owner163==p or e.SpawnerEntity==p)and not e.removed then return e end end
end
local function mainCount(p,since)
 local n=0;for i=since or 1,#entities do local e=entities[i];if e.Type==2 and e:GetData().owner163==p and not e:GetData().aux163 and not e.removed then n=n+1 end end;return n
end
local function nativeShot(p)return p:FireTear(p.Position,Vector(16,0),true,false,true,p,1)end
local function lightShot(p)
 p.input=Vector(1,0);tick(p);p.input=Vector(0,0);return latest(2,p)
end

do
local p=player({[373]=1});local t=nativeShot(p)
approx(t.CollisionDamage,16.8);approx(t.Size,6);assert(t:HasTearFlags(TearFlags.TEAR_PERSISTENT))
assert(p:GetData().hunterCombat155.duration==63 and p:GetData().hunterCombat155.ammo==0)
t.CollisionDamage=2;call(40,t);approx(t.CollisionDamage,2)
tick(p,63);assert(p:GetData().hunterCombat155.ammo==1)

-- Birthright's two rounds are separate from the unchanged reload duration.
local p=player({[619]=1});local one=nativeShot(p);local b=p:GetData().hunterCombat155
assert(b.ammo==1 and not b.untilFrame and b.nextShotFrame==frame+13)
local early=nativeShot(p);assert(not early.removed and b.ammo==1,'Same-frame multishot shares one round')
tick(p,12);local rejected=nativeShot(p);assert(rejected.removed and b.ammo==1)
tick(p,1);local two=nativeShot(p);assert(b.ammo==0 and b.duration==63 and b.untilFrame==frame+63)
approx(p.MaxFireDelay,61.5);tick(p,63);assert(b.ammo==2)
call(2) -- both ammo icons and native charge UI can render without state changes.

for _,v in ipairs({{.25,4},{1,1.2},{.1,4},{2,1.2}})do approx(R.chocolate(v[1],1),v[2])end
local last=math.huge;for i=25,100 do local n=R.chocolate(i/100,1);assert(n<=last);last=n end
local p=player({[69]=1});p:GetData().hunterTears161={capRate=1};p.input=Vector(1,0)
local start=#entities+1;tick(p);assert(mainCount(p,start)==1)
approx(latest(2,p).CollisionDamage,16.8*R.chocolate(.48,1));assert(p.FireDelay==1000000)

local p=player({[52]=1});p.input=Vector(1,0);tick(p);local t=latest(2,p)
approx(t:GetData().explosionDamage163,38.4);assert(not t:HasTearFlags(TearFlags.TEAR_EXPLOSIVE))
local npc=entity(10);npc.HitPoints=200;local blasts=#bombs
call(42,t,npc);npc:TakeDamage(t.CollisionDamage,0,EntityRef(t),0);call(40,t);call(1)
assert(#bombs==blasts+1 and bombs[#bombs].selfDamage and bombs[#bombs].flags==0)
call(40,t);call(1);assert(#bombs==blasts+1)
local p=player({[149]=1});p.Damage=52.2;p.input=Vector(1,0);tick(p);approx(latest(2,p).CollisionDamage,144.4)
local p=player({[149]=1,[52]=1});p.Damage=52.2;p.input=Vector(1,0);tick(p)
approx(latest(2,p).CollisionDamage,144.4);approx(latest(2,p):GetData().explosionDamage163,144.4)
local hp=p.red;p:TakeDamage(2,DamageFlag.DAMAGE_EXPLOSION,{},0);assert(p.red==hp and p.broken==0)

local p=player({[118]=1});p.input=Vector(1,0);tick(p)
assert(p.brimCount==1 and p:GetData().hunterCombat155.untilFrame)
local l=latest(7,p);approx(l.CollisionDamage,2.1);local timeout=l.Timeout;tick(p);call(48,l)
assert(not l.removed and l.Timeout>0 and l.Timeout<=timeout)
local p=player({[395]=1,[118]=1});p.input=Vector(1,0);tick(p)
assert(not p.brimCount);local t=latest(2,p);local l=latest(7,p)
assert(l.Variant==9 and l.SubType==2 and l:GetData().followTear163==t);approx(l.CollisionDamage,p.Damage)
t.Position=Vector(99,100);call(48,l);assert(l.Position==t.Position);t:Remove();call(48,l);assert(l.removed)

local p=player({[316]=1});p.input=Vector(1,0);local start=#entities+1;tick(p)
assert(mainCount(p,start)==5);approx(latest(2,p).CollisionDamage,3.36)
assert(p:GetData().hunterCombat155.duration==63)
p:TakeDamage(.5,0,{Entity=entity(10)},0);p.input=Vector(0,0);tick(p);assert(p.teleports==1)
tick(p);assert(p.teleports==1)
local p=player({[316]=1,[260]=1});p.input=Vector(1,0);tick(p);p:TakeDamage(.5,0,{},0);p.input=Vector(0,0);tick(p);assert(not p.teleports)
local p=player({[229]=1});p.MaxFireDelay=199;p.input=Vector(1,0);local start=#entities+1;tick(p)
assert(mainCount(p,start)==14 and p:GetData().hunterCombat155.duration==200)

local p=player({[579]=1});p.input=Vector(1,0);tick(p)
tick(p,2)
local k=latest(8,p)
local found=false;for _,e in ipairs(entities)do if e.SpawnerEntity==p and e:GetData().nativeSword166 then found=e:GetIsSpinAttack()and not e.removed end end
assert(found and p.nativeSpinCount==1)
local swordBeam=false;for _,e in ipairs(entities)do if e.SpawnerEntity==p and e.Variant==47 then swordBeam=true;approx(e.CollisionDamage,16.1)end end;assert(swordBeam)
local p=player({[678]=1});p.input=Vector(1,0);tick(p);local t=latest(2,p)
assert(t.Variant==50 and t:HasTearFlags(TearFlags.TEAR_FETUS_KNIFE));approx(t.CollisionDamage,16.8);assert(t:GetData().cSection165)
assert(not t:GetData().hunterKnifeApplied155)
local p=player({[533]=1});p.nativeFlags=TearFlags.TEAR_LASERSHOT;local t=lightShot(p)
approx(t.CollisionDamage,4.2);assert(t:GetData().trisagion164 and not t:GetData().hunterKnifeApplied155)
local p=player({[150]=1});p.nextVariant=2;p.nextFactor=3.2;local t=nativeShot(p);approx(t.CollisionDamage,53.76);assert(t:GetData().hunterKnifeApplied155)
local p=player({[443]=1});p.nextVariant=28;p.nextFactor=4;local t=nativeShot(p);approx(t.CollisionDamage,67.2)
local p=player({[237]=1});p.nativeFlags=TearFlags.TEAR_PIERCING;local t=nativeShot(p);assert(t.Color.R==.16 and t:HasTearFlags(TearFlags.TEAR_PIERCING))

local p=player({[398]=1,[503]=1});p.rngValues[398]=.49;p.rngValues[503]=.24
local t=nativeShot(p);assert(t:HasTearFlags(TearFlags.TEAR_GODS_FLESH)and t:HasTearFlags(TearFlags.TEAR_HORN))
local p=player({[398]=1,[503]=1});p.rngValues[398]=.5;p.rngValues[503]=.25
local t=nativeShot(p);assert(not t:HasTearFlags(TearFlags.TEAR_GODS_FLESH)and not t:HasTearFlags(TearFlags.TEAR_HORN))
approx(R.hornChance(0),.25);approx(R.hornChance(15),1)
local p=player({[429]=1});p.rngValues[429]=.24;local t=nativeShot(p);local npc=entity(10);npc.HitPoints=100
local pickupBefore=0;for _,e in ipairs(entities)do if e.Type==5 then pickupBefore=pickupBefore+1 end end
npc:TakeDamage(t.CollisionDamage,0,EntityRef(t),0);call(1)
local pickups=0;for _,e in ipairs(entities)do if e.Type==5 then pickups=pickups+1 end end;assert(pickups==pickupBefore+1)
local p=player({[331]=1});p.nativeFlags=TearFlags.TEAR_GLOW;local t=nativeShot(p);local npc=entity(10);npc.HitPoints=1000
npc:TakeDamage(2,0,EntityRef(t),0);approx(npc.HitPoints,990)
npc:TakeDamage(t.CollisionDamage,0,EntityRef(t),0);approx(npc.HitPoints,973.2)
npc:TakeDamage(2,DamageFlag.DAMAGE_POISON_BURN,EntityRef(t),0);approx(npc.HitPoints,971.2)

-- Parent damage and group identity survive all children; no new reload or refill.
local p=player({[373]=1,[104]=1});local root=nativeShot(p);local g=root:GetData().hunterGroup163
local child=p:FireTear(root.Position,Vector(4,0),false,false,false,root,.5)
child.CollisionDamage=root.CollisionDamage*.5;call(40,child)
approx(child.CollisionDamage,8.4);assert(child:GetData().hunterGroup163==g)
root:Remove();tick(p,3);assert(p.clears==0)
local npc=entity(10);npc.HitPoints=100;npc:TakeDamage(child.CollisionDamage,0,EntityRef(child),0);call(1)
child:Remove();tick(p,3);assert(p.clears==0 and g.hit)
local p=player({[373]=1,[104]=1});local root=nativeShot(p);local child=p:FireTear(root.Position,Vector(4,0),false,false,false,root,.5)
root:Remove();tick(p,3);assert(p.clears==0);child:Remove();tick(p,3);assert(p.clears==1)
local p=player({});local fixed=entity(3,1);fixed.Player=p;local ft=p:FireTear(p.Position,Vector(4,0),true,false,false,fixed,1)
approx(ft.CollisionDamage,p.Damage);assert(not p:GetData().hunterCombat155)
local inherited=entity(3,80);inherited.Player=p;local it=p:FireTear(p.Position,Vector(4,0),true,false,false,inherited,.75)
approx(it.CollisionDamage,p.Damage*.75*4);assert(not p:GetData().hunterCombat155)

local p=player({[352]=1});call(64,352,nil,p);p.nextFactor=(10*p.Damage+10)/p.Damage
local t=p:FireTear(p.Position,Vector(20,0),false,false,false,p,1)
approx(t.CollisionDamage,208);assert(not p:GetData().hunterCombat155)
local p=player({[114]=2,[637]=1,[154]=1});tick(p)
assert(p.items[114]==0 and p.items[172]==6 and p.items[637]==0 and p.items[359]==1 and p.items[154]==0 and p.items[9001]==1)
approx(C.flatDamage(p),1.5);tick(p);assert(p.items[172]==6 and p.items[359]==1 and p.items[9001]==1)
p.kind=10;call(4,p);assert(p.items[9001]==0 and p.items[154]==1)

-- Epic Fetus preserves targeting and releases exactly three inherited-speed knives.
local p=player({[168]=1});local rocket=entity(1000,31,p);call(55,rocket)
local start=#entities+1;rocket:Remove();assert(mainCount(p,start)==3)
for i=start,#entities do local t=entities[i];if t.Type==2 then approx(t.CollisionDamage,16.8);approx(t.Velocity:Length(),16)end end
-- Ordinary range expiration must not create a wall-impact explosion.
local p=player({[52]=1});p.input=Vector(1,0);tick(p);local t=latest(2,p);local count=#bombs;t:Remove();call(1);assert(#bombs==count)

local p=player({[619]=1});nativeShot(p);call(17,true);local savedAmmo=p:GetData().hunterCombat155.ammo
p:GetData().hunterCombat155=nil;call(15,true);assert(p:GetData().hunterCombat155.ammo==savedAmmo)
local p=player({[619]=1});nativeShot(p);nativeShot(p);tick(p,13);nativeShot(p)
local remain=p:GetData().hunterCombat155.untilFrame-frame;call(17,true);p:GetData().hunterCombat155=nil;call(15,true)
assert(p:GetData().hunterCombat155.untilFrame-frame==remain)
local normal=player({[118]=1},10);local t=nativeShot(normal);approx(t.CollisionDamage,4.2);assert(not normal:GetData().hunterCombat155)

-- Native fixed familiars and copied tears must not receive a second x4.
for _,variant in ipairs({8,74,101,228})do
 local p=player({});local familiar=entity(3,variant);familiar.Player=p
 local t=p:FireTear(p.Position,Vector(4,0),true,false,false,familiar,1)
 approx(t.CollisionDamage,4.2);assert(not p:GetData().hunterCombat155)
end
local p=player({});local gello=entity(3,240);gello.Player=p
local t=p:FireTear(p.Position,Vector(4,0),true,false,false,gello,1)
approx(t.CollisionDamage,16.8);call(40,t);approx(t.CollisionDamage,16.8)
local p=player({[316]=1,[245]=1});p.input=Vector(1,0);local start=#entities+1;tick(p)
assert(mainCount(p,start)==10)
local p=player({});p.effects[556]=1;p.input=Vector(1,0);tick(p)
assert(p.brimCount==1 and p.FireDelay==1000000)
p.effects[556]=nil;tick(p);assert(p.FireDelay~=1000000 and not p:GetData().hunterCompat163.locked163)
local p=player({[118]=1});p.input=Vector(1,0);tick(p);call(17,true)
assert(p.FireDelay<1000000);p:GetData().hunterCombat155=nil;call(15,true);assert(p.FireDelay<1000000)
tick(p);assert(p.FireDelay==1000000);p.kind=10;tick(p);assert(p.FireDelay==0)
local p=player({});p.effects[114]=2;p.effects[637]=1;tick(p)
assert(p.effects[172]==6 and p.effects[359]==1);p.kind=10;tick(p)
assert(p.effects[172]==0 and p.effects[359]==0)
local p=player({});p.effects[154]=1;p.input=Vector(1,0);p.failFire=true
local ok=pcall(tick,p);assert(not ok and p.effects[154]==1 and p.effects[9001]==0)
assert(p:GetData().hunterCompat163.context==nil)
local p=player({});local friend=entity(10,0,p);friend.friendly=true
local t=p:FireTear(p.Position,Vector(4,0),true,false,false,friend,1)
approx(t.CollisionDamage,4.2);assert(not p:GetData().hunterCombat155)
for _,callback in ipairs({23,10})do
 local p=player({});call(callback,1,p);local t=nativeShot(p)
 approx(t.CollisionDamage,4.2);assert(not p:GetData().hunterCombat155)
end
local p=player({[68]=1});p.input=Vector(1,0);tick(p);local l=latest(7,p)
approx(l.CollisionDamage,16.8);assert(l:GetData().tech168 and l.OneHit and p:GetData().hunterCombat155.untilFrame)
local count=#entities;tick(p);assert(#entities==count)
local p=player({[329]=1,[619]=1});local t=nativeShot(p);local npc=entity(10);npc.HitPoints=1000
npc:TakeDamage(t.CollisionDamage,0,EntityRef(t),0);local hp=npc.HitPoints
tick(p);npc:TakeDamage(t.CollisionDamage,0,EntityRef(t),0);assert(npc.HitPoints==hp)
tick(p,12);npc:TakeDamage(t.CollisionDamage,0,EntityRef(t),0);assert(npc.HitPoints<hp)
local p=player({});local k=entity(8,0,p);k.Parent=p;call(45,k)
assert(not p:GetData().hunterCombat155);k.sprite:Play('Attack');call(45,k)
assert(p:GetData().hunterCombat155.ammo==0)
tick(p);k.sprite.frame=1;call(45,k);k.sprite.frame=0;call(45,k)
local npc=entity(10);npc.HitPoints=100;npc:TakeDamage(10,0,EntityRef(k),0);approx(npc.HitPoints,100)
-- A low-damage physical Godhead hit is not an aura pulse.
local p=player({[331]=1});p.nativeFlags=TearFlags.TEAR_GLOW;local t=nativeShot(p)
local npc=entity(10);npc.HitPoints=100;call(42,t,npc)
npc:TakeDamage(2,0,EntityRef(t),0);approx(npc.HitPoints,98)
print('v166 integrated compatibility model passed: chamber/interval, instant weapons, custom damage/procs, rings/beams, replacements, descendants/miss grouping, familiars, explosions, cannon, aura, saves and character isolation')

-- Reproduces the v163 defect independently of changed weapon values.
local p=player({[373]=1})
local root=nativeShot(p);local target=entity(10);target.HitPoints=1000
call(42,root,target);target:TakeDamage(root.CollisionDamage,0,EntityRef(root),0)
call(1);root:Remove();tick(p,1)
local discarded=nativeShot(p)
assert(discarded.removed,'A genuine reload must reject this native extra tear')
assert(p.clears==0,'Rejected native tear must never reset Dead Eye after a hit')
local p=player({[373]=1});local root=nativeShot(p)
local target=entity(10);target.HitPoints=1000
call(42,root,target);target:TakeDamage(root.CollisionDamage,0,EntityRef(root),0)
target.HitPoints=1000 -- stationary testing targets can restore HP in the same update.
root:Remove();tick(p,3)
assert(p.clears==0,'A hit must survive a stationary target restoring its HP')
print('v164 targeted Dead Eye regressions passed: discarded native tear and restored target HP')

-- Continuous stationary-target hits and suppressed native duplicates.
for _,loadout in ipairs({{[373]=1},{[373]=1,[69]=1}})do
 local p=player(loadout);local target=entity(10);target.HitPoints=100000
 for volley=1,120 do
  local root
  if loadout[69]then p.input=Vector(1,0);tick(p);p.input=Vector(0,0);root=latest(2,p)
  else root=nativeShot(p)end
  call(42,root,target);target:TakeDamage(root.CollisionDamage,0,EntityRef(root),0)
  target.HitPoints=100000;root:Remove();tick(p)
  local rejected=nativeShot(p);assert(rejected.removed and not rejected.CanTriggerStreakEnd)
  tick(p,63)
  assert(p.clears==0,'Continuous successful volleys must not reset Dead Eye')
 end
end
-- All-miss Parasite groups still attempt exactly one native reset, not one per child.
local p=player({[373]=1,[104]=1});local root=nativeShot(p)
local a=p:FireTear(root.Position,Vector(2,0),false,false,false,root,.5)
local b=p:FireTear(root.Position,Vector(-2,0),false,false,false,root,.5)
root:Remove();a:Remove();tick(p,3);assert(p.clears==0)
b:Remove();tick(p,3);assert(p.clears==1);tick(p,3);assert(p.clears==1)
-- A non-HP-changing enemy contact is sufficient, but walls/friendly NPCs are not.
local p=player({[373]=1});local root=nativeShot(p);local friend=entity(10);friend.friendly=true
call(42,root,friend);root:Remove();tick(p,3);assert(p.clears==1)
-- Controlled tears create their hit group at the damage window, before reset HP.
local p=player({[373]=1,[329]=1});local root=nativeShot(p)
local target=entity(10);target.HitPoints=1000
target:TakeDamage(root.CollisionDamage,0,EntityRef(root),0);target.HitPoints=1000
tick(p,3);assert(p.clears==0)

-- Real straight tears: no inherited bomb damage, no parabola and full range budget.
for _,id in ipairs({52,149})do
 local p=player({[id]=1});p.Damage=10;p.nextFactor=100;p.nextVariant=4
 p.nativeFlags=TearFlags.TEAR_EXPLOSIVE;p.input=Vector(1,0);tick(p);p.input=Vector(0,0)
 local t=latest(2,p);assert(t.Type==2 and t.Variant==0)
 approx(t.CollisionDamage,id==52 and 40 or 60)
 approx(t:GetData().explosionDamage163,id==52 and 50 or 60)
 assert(not t:HasTearFlags(TearFlags.TEAR_EXPLOSIVE))
 local count=#bombs
 for step=1,29 do
  t.Position=t.Position+Vector(16,0);t.FallingSpeed=20;t.FallingAcceleration=10
  call(40,t);assert(not t.removed);approx(t.Height,-10);approx(t.FallingSpeed,0);approx(t.FallingAcceleration,0)
 end
 t.Position=t.Position+Vector(16,0);call(40,t);assert(t.removed)
 call(1);assert(#bombs==count,'Open-air range expiration must not explode')
end
local p=player({[52]=1});local ordinaryBomb=entity(4,0,p);ordinaryBomb.IsFetus=false
call(58,ordinaryBomb);assert(not ordinaryBomb.removed)
local fetus=entity(4,0,p);fetus.IsFetus=true;fetus.ExplosionDamage=50
call(58,fetus);assert(fetus.removed and fetus.ExplosionDamage==0)
local npc=entity(10,0,p);local friendlyFetus=entity(4,0,npc);friendlyFetus.IsFetus=true
call(58,friendlyFetus);assert(not friendlyFetus.removed)

-- Trisagion: scale actual light hits exactly16, before first laser-update as well.
local p=player({[533]=1});p.nativeFlags=TearFlags.TEAR_LASERSHOT
local root=lightShot(p);approx(root.CollisionDamage,p.Damage)
local target=entity(10);target.HitPoints=1000
local l=entity(7,5,p);l.Parent=root;l.CollisionDamage=root.BaseDamage/3
-- Exercise the damage-time fallback, before init/update metadata was observed.
target:TakeDamage(l.CollisionDamage,DamageFlag.DAMAGE_LASER,EntityRef(l),0)
approx(target.HitPoints,1000-p.Damage/3*4)
for i=1,6 do
 call(27,l);call(48,l);l.CollisionDamage=root.BaseDamage/3
 target:TakeDamage(l.CollisionDamage,DamageFlag.DAMAGE_LASER,EntityRef(l),0)
end
approx(target.HitPoints,1000-7*p.Damage/3*4)
-- Poison/DOT isn't the light beam, and unrelated red lasers retain their own damage.
local hp=target.HitPoints;target:TakeDamage(1,DamageFlag.DAMAGE_POISON_BURN,EntityRef(l),0)
approx(target.HitPoints,hp-1)
local other=entity(7,1,p);other.CollisionDamage=2;target:TakeDamage(2,DamageFlag.DAMAGE_LASER,EntityRef(other),0)
approx(target.HitPoints,hp-3)
local child=p:FireTear(root.Position,Vector(3,0),false,false,false,root,.5)
child.CollisionDamage=root.BaseDamage*.5;nativeBases[child]=child.CollisionDamage
local light=entity(7,5,p);light.Parent=child;light.CollisionDamage=child.CollisionDamage/3;call(27,light)
hp=target.HitPoints;target:TakeDamage(light.CollisionDamage,DamageFlag.DAMAGE_LASER,EntityRef(light),0)
approx(target.HitPoints,hp-child.BaseDamage/3*4)
-- Trisagion and Godhead aura multipliers are separate rather than multiplying to20.
local p=player({[533]=1,[331]=1});p.nativeFlags=TearFlags.TEAR_LASERSHOT|TearFlags.TEAR_GLOW
local root=lightShot(p);local target=entity(10);target.HitPoints=100
 target:TakeDamage(2,0,EntityRef(root),0);approx(target.HitPoints,90)
-- Spirit Sword's first loaded round now spins too; emptying the chamber adds no third spin.
local p=player({[579]=1,[619]=1});p.input=Vector(1,0)
local function spinCount()
 return p.nativeSpinCount or 0
end
tick(p);assert(spinCount()==0 and p:GetData().hunterCombat155.ammo==1 and not p:GetData().hunterCombat155.untilFrame)
tick(p,2);assert(spinCount()==1)
tick(p,10);assert(spinCount()==1)
tick(p);assert(spinCount()==1 and p:GetData().hunterCombat155.untilFrame)
tick(p,2);assert(spinCount()==2)
assert(C.onReload==nil)
-- Native charge UI option is reversible; the reload UI still renders independently.
Options={ChargeBars=true};players={p}
local ui=include('tainted_hunter_charge_ui')(mod,20,R)
ui.update();assert(Options.ChargeBars==false);local prior=renderLog['gfx/chargebar.anm2']or 0
call(2);assert((renderLog['gfx/chargebar.anm2']or 0)>prior)
p.items[579]=nil;ui.update();assert(Options.ChargeBars==true)
p.items[579]=1;ui.update();assert(Options.ChargeBars==false);call(17,true);assert(Options.ChargeBars==true)
Options.ChargeBars=false;ui.update();p.kind=10;ui.update();assert(Options.ChargeBars==false)
Options.ChargeBars=true;p.kind=20;ui.update();p.dead=true;ui.update();assert(Options.ChargeBars==true)
print('v164 feedback model passed:240 stationary-hit volleys, grouped misses, straight-range/entity tests, light-laser actual-hit16x/children/DOT isolation, two attack-time spins, reversible charge UI and visible reload wheel')

end

-- The old tests only called Remove(). Native death can precede removal forever
-- when an Idle-only custom sprite keeps overriding the native death animation.
local p=player({[373]=1});local t=nativeShot(p);t.dead=true
assert(t:Exists());tick(p,3)
assert(p.clears==1,'Dead-but-existing tear must finish the miss group without a Remove callback')
local p=player({[373]=1});local t=nativeShot(p)
t.dead=true;t.sprite:Play('Death');call(40,t);assert(t.sprite:GetAnimation()=='Death')
tick(p,2);call(40,t);assert(t.removed,'Dead custom knives must be cleaned up')
-- Keep a delayed child alive after its parent dies: no premature reset.
local p=player({[373]=1,[104]=1});local root=nativeShot(p);root.dead=true;tick(p)
local child=p:FireTear(root.Position,Vector(4,0),false,false,false,root,.5)
tick(p,3);assert(p.clears==0)
child.dead=true;tick(p,3);assert(p.clears==1)
-- Request the original native probabilistic clear, exactly once per missed volley.
local p=player({[373]=1});p.bonus=1;p.nativeRequests=0
function p:ClearDeadEyeCharge()
 self.nativeRequests=self.nativeRequests+1
 -- Stand-in for native RNG, not a reimplementation in production code.
 if self.nativeRequests==3 then self.bonus=0 end
end
for i=1,3 do
 local t=nativeShot(p);t.dead=true;tick(p,63)
 assert(p.nativeRequests==i);assert(p.bonus==(i<3 and 1 or 0))
end
local t=nativeShot(p);local target=entity(10);target.HitPoints=1000
call(42,t,target);t.dead=true;tick(p,63);assert(p.nativeRequests==3)
-- Fireplaces count as hits even when IsVulnerableEnemy excludes environmental NPCs.
local p=player({[373]=1});local t=nativeShot(p);local fire=entity(33);fire.HitPoints=10;fire.invulnerable=true
call(42,t,fire);t.dead=true;tick(p,3);assert(p.clears==0)
-- Poop collision counts, a plain wall collision does not.
local getRoom=game.GetRoom;local grid
function game:GetRoom()
 local room=getRoom(self)
 function room:GetGridEntityFromPos(pos)if grid and(pos-grid.Position):Length()<24 then return grid end end
 return room
end
local function makeGrid(kind)return{State=0,Position=Vector(0,0),GetType=function()return kind end}end
local p=player({[373]=1});local t=nativeShot(p);grid=makeGrid(14);t.grid=true
call(40,t);t.dead=true;tick(p,3);assert(p.clears==0)
local p=player({[373]=1});local t=nativeShot(p);grid=makeGrid(15);t.grid=true
call(40,t);t.dead=true;tick(p,3);assert(p.clears==1)
grid=nil;game.GetRoom=getRoom
-- Native Chocolate exists only as a replacement passive after update.
local p=player({[69]=2});local reflags=0
function p:AddCacheFlags(flags)reflags=reflags|flags end
p.input=Vector(1,0);tick(p)
assert(reflags&256~=0,'Replacing native Chocolate must rebuild the native weapon cache')
assert(p.items[69]==0 and p.items[9002]==2 and R.count(p,69)==2)
local baseline=latest(2,p).CollisionDamage
local accepted=1
for i=1,190 do
 p.input=(i%2==0)and Vector(1,0)or Vector(0,0)
 local before=mainCount(p);tick(p)
 if mainCount(p)>before then accepted=accepted+1 end
 local leaked=p:FireTear(p.Position,Vector(16,0),true,false,false,p,20)
 assert(leaked.removed,'Untagged tap/charge tear may not bypass scripted reload, even with native streak flag false')
end
assert(accepted<=4,'Rapid key taps may not accelerate the chamber')
p.input=Vector(0,0);tick(p,63);p.input=Vector(1,0);tick(p)
approx(latest(2,p).CollisionDamage,baseline)
p.kind=10;tick(p);assert(p.items[9002]==0 and p.items[69]==2)
p.kind=20;tick(p);assert(p.items[9002]==2 and p.items[69]==0)
-- Temporary native Chocolate is suspended while creating the real shot and restored even on errors.
local p=player({});p.effects[69]=1;p.failFire=true;p.input=Vector(1,0)
local ok=pcall(tick,p);assert(not ok and p.effects[69]==1 and p.effects[9002]==0)
-- Explicit numerical change: C Section x0.25 once, with knife-fetus flags unchanged.
local p=player({[678]=1});p.Damage=10;p.input=Vector(1,0);tick(p);p.input=Vector(0,0)
local root=latest(2,p);approx(root.CollisionDamage,40);assert(root:HasTearFlags(TearFlags.TEAR_FETUS_KNIFE))
local child=p:FireTear(root.Position,Vector(5,0),false,false,false,root,.5)
child.CollisionDamage=root.CollisionDamage*.5;call(40,child);approx(child.CollisionDamage,20)
local knife=entity(8,0,child);knife.CollisionDamage=2;call(45,knife);approx(knife.CollisionDamage,2)
local target=entity(10);target.HitPoints=1000
 target:TakeDamage(root.CollisionDamage,0,EntityRef(root),0);approx(target.HitPoints,990)
 target:TakeDamage(child.CollisionDamage,0,EntityRef(child),0);approx(target.HitPoints,985)
 target:TakeDamage(knife.CollisionDamage,0,EntityRef(knife),0);approx(target.HitPoints,984.5)
-- Native child lasers may calculate their own damage instead of copying a reduced carrier.
local laser=entity(7,1,p);laser.Parent=root;laser.CollisionDamage=8
 target:TakeDamage(8,DamageFlag.DAMAGE_LASER,EntityRef(laser),0);approx(target.HitPoints,982.5)
-- Some native light hits name the player as their source. Nearby carrier
-- attribution still applies the new16x, without requiring a laser variant.
local p=player({[533]=1});p.nativeFlags=TearFlags.TEAR_LASERSHOT;local root=lightShot(p)
local npc=entity(10);npc.HitPoints=1000
local laser=entity(7,5,p);laser.Parent=root
call(1248,laser,npc)
npc:TakeDamage(root.BaseDamage/3,0,EntityRef(p),0)
call(1249,laser,npc)
approx(npc.HitPoints,1000-root.BaseDamage/3*4)
print('v165 feedback regressions passed: dead-without-remove/native probability calls, late descendants, fire/poop/wall, native Chocolate removal +190 taps/error/identity, C Section quarter once, confirmed v165 mechanisms and actual-hit light16x')

local output
Isaac.ConsoleOutput=function(value)output=value end
call(22,'hunterdiag')
assert(output and output:find('Hunter v1.70',1,true)and output:find('native_miss_requests'))
-- A training dummy can record and cancel damage at ordinary priority.
-- Damage scaling must run before it, and the dummy must see one scaled hit.
local p=player({[533]=1});p.nativeFlags=TearFlags.TEAR_LASERSHOT;local root=lightShot(p)
local dummy=entity(10);dummy.HitPoints=1000;local recorded={}
mod:AddCallback(11,function(_,entity,amount)
 if entity==dummy then recorded[#recorded+1]=amount;return false end
end)
dummy:TakeDamage(root.BaseDamage/3,DamageFlag.DAMAGE_LASER,EntityRef(root),0)
assert(#recorded==1);approx(recorded[1],root.BaseDamage/3*4);approx(dummy.HitPoints,1000)
local p=player({[678]=1});p.input=Vector(1,0);tick(p);p.input=Vector(0,0)
local root=latest(2,p);recorded={}
dummy:TakeDamage(8,0,EntityRef(root),0)
assert(#recorded==1);approx(recorded[1],2)
print('v165 early damage transform passed: cancelling default-priority dummy observes a single16x light hit or quarter fetal hit')

-- Strict generic Entity callback view reproduces the reported LuaBridge ABI.
-- The previous code writes a tear member directly and fails this contract.
do
local p=player({[373]=1});local t=nativeShot(p)
local generic=baseView(t)
assert(not pcall(function()generic.CanTriggerStreakEnd=false end))
call(67,generic);assert(t.CanTriggerStreakEnd==false)
t:Remove();tick(p,3)
assert(p:GetData().hunterCompat163.missRequests165==1)
end
-- A real native light can name only the player, without any LASER flag. Its
-- precise collision supplies the source; root/descendants remain unscaled.
do
local p=player({[533]=1,[69]=1,[395]=1});p.nativeFlags=TearFlags.TEAR_LASERSHOT
local root=lightShot(p);local curve=R.chocolate(.48,1)
approx(root.BaseDamage,4.2);approx(p.Damage,4.2)
local ring=latest(7,p);approx(ring.CollisionDamage,4.2)
local l=entity(7,5,p);l.Parent=baseView(root);l.CollisionDamage=1.4
local npc=entity(10);npc.HitPoints=1000
call(1248,l,npc);npc:TakeDamage(1.4,0,EntityRef(p),0);call(1249,l,npc)
approx(npc.HitPoints,1000-1.4*4*curve)
local state=p:GetData().hunterCompat163;approx(state.lastLight165.applied,1.4*4*curve)
-- Unrelated player-source damage in that same frame cannot reuse attribution.
local hp=npc.HitPoints;npc:TakeDamage(3,0,EntityRef(p),0);approx(npc.HitPoints,hp-3)
-- A cancelled hit clears attribution, and a shielded/no-event DoDamage also
-- clears it in POST; red lasers and rings never get the multiplier.
call(1248,l,npc);call(1249,l,npc)
hp=npc.HitPoints;npc:TakeDamage(2,0,EntityRef(p),0);approx(npc.HitPoints,hp-2)
local red=entity(7,1,p);call(1248,red,npc)
hp=npc.HitPoints;npc:TakeDamage(2,0,EntityRef(p),0);call(1249,red,npc);approx(npc.HitPoints,hp-2)
local dummy=entity(10);dummy.HitPoints=1000;local seen={}
mod:AddCallback(11,function(_,e,n)if e==dummy then seen[#seen+1]=n;return false end end)
call(1248,l,dummy);dummy:TakeDamage(1.4,0,EntityRef(p),0);call(1249,l,dummy)
assert(#seen==1);approx(seen[1],1.4*4*curve);approx(dummy.HitPoints,1000)
-- Modern ExtraSource also identifies a beam without a collision context.
local result=call(11,npc,1.4,0,EntityRef(p),0,EntityRef(l));approx(result.Damage,1.4*4*curve)
end

-- Real weapon release contract: a stand-in FireKnife without a Spin clip is
-- never called. Native POST_FIRE_SWORD is the only accepted spin factory.
do
local p=player({[579]=1});p.input=Vector(0,1)
p.FireKnife=function()error('ordinary knife factory may not emulate Spirit Sword')end
local start=p.FireDelay;tick(p)
assert(not p.nativeSpinCount and C._testing.sword.pending[p.InitSeed])
local attack=p:GetData().hunterCombat155.lastVolleyFrame
local untilFrame=p:GetData().hunterCombat155.untilFrame
tick(p,2);assert(p.nativeSpinCount==1)
assert(p:GetData().hunterCombat155.lastVolleyFrame==attack and p:GetData().hunterCombat155.untilFrame==untilFrame)
assert(not C._testing.sword.engineWindow(p)and not C._testing.sword.pending[p.InitSeed])
assert(call(13,p,2,5)==nil and call(13,p,0,4)==nil,'Input override must end with native update')
local other=player({});assert(call(13,other,2,5)==nil)
assert(p.FireDelay==1000000,'Native release must restore the scripted cooldown')
local k
for _,e in ipairs(entities)do if e.SpawnerEntity==p and e:GetData().nativeSword166 then k=e end end
assert(k and k:GetSprite():IsPlaying('Spin')and k:GetIsSpinAttack()and not k.removed)
local box=entity(8,10,p);box.SubType=4;box.Parent=k;call(45,box);assert(not box.removed)
local delayed=player({[579]=1});delayed.delayedSpinInit=true;delayed.input=Vector(1,0);tick(delayed,3)
assert(delayed.nativeSpinCount==1)
local captured=false
for _,e in ipairs(entities)do if e.SpawnerEntity==delayed and e:GetData().nativeSword166 then captured=not e.removed end end
assert(captured,'Native reused main sword must be captured after its real state changes')
local p=player({[579]=1});p.missingSwordWeapon=true;p.input=Vector(1,0);tick(p,3)
assert(not p.nativeSpinCount and not C._testing.sword.pending[p.InitSeed])
local p=player({[579]=1});p.input=Vector(1,0);tick(p);p.items[579]=nil;tick(p)
assert(not C._testing.sword.pending[p.InitSeed]and call(13,p,2,5)==nil)
end
-- POST damage proves the hit was accepted; altered LastDamageFlags cannot
-- suppress Cursed Eye. Teleport uses the native random-room API, once, after
-- damage/player update has ended, never through an active-item callback.
do
local p=player({[316]=1});p.red=12;p.max=12;p.input=Vector(1,0);tick(p);p.input=Vector(0,0)
p.UseActiveItem=function()error('Cursed Eye must not invoke active-item hooks')end
local source=EntityRef(entity(10));p:TakeDamage(.5,0,source,0);p.lastFlags=12345
local state=p:GetData().hunterItems163;assert(state.cursedPending168 and not state.hurt)
source.Entity=nil;setmetatable(source,{__index=function()error('borrowed EntityRef expired')end})
call(4,p);call(1);assert(not p.teleports)
tick(p);assert(p.teleports==1 and p.teleportPhase=='post_update'and p.weaponCharge==0)
tick(p,2);assert(p.teleports==1)
for _,case in ipairs({'shield','black','not_reloading','dead','room','source_removed'})do
 local p=player({[316]=1});p.red=12;p.max=12;p.input=Vector(1,0);tick(p);p.input=Vector(0,0)
 if case=='shield'then p.shield=true elseif case=='black'then p.items[260]=1 elseif case=='not_reloading'then p:GetData().hunterCombat155.untilFrame=nil end
 local flags=case=='payment'and DamageFlag.DAMAGE_IV_BAG or 0
 local src=EntityRef(entity(10));p:TakeDamage(.5,flags,src,0)
 if case=='dead'then p.dead=true elseif case=='room'then roomIndex=roomIndex+1;call(19)elseif case=='source_removed'then src.Entity=nil end
 tick(p,2)
 if case=='source_removed'then assert(p.teleports==1)else assert(not p.teleports,case)end
end
for _,flags in ipairs({DamageFlag.DAMAGE_CURSED_DOOR,DamageFlag.DAMAGE_IV_BAG,DamageFlag.DAMAGE_DEVIL,DamageFlag.DAMAGE_SPIKES,DamageFlag.DAMAGE_RED_HEARTS,DamageFlag.DAMAGE_NO_PENALTIES})do
 local p=player({[316]=1});p.red=12;p.max=12;p.input=Vector(1,0);tick(p);p.input=Vector(0,0)
 local paid=entity(6,2);p:TakeDamage(.5,flags,EntityRef(paid),0);tick(p)
 assert(p.teleports==1,'Accepted self-damage must teleport during reload')
 if flags~=DamageFlag.DAMAGE_SPIKES then assert(p.broken==0,'Self-damage teleport must not alter broken-heart exclusions')end
end
local p=player({[316]=1});p.input=Vector(1,0);tick(p);p.input=Vector(0,0)
p:TakeDamage(.5,DamageFlag.DAMAGE_FAKE,{},0);tick(p);assert(not p.teleports)

end
-- Door damage must survive the door's own room-change cleanup and defer
-- native random-room movement until the destination room is stable.
do
local p=player({[316]=1});p.red=12;p.max=12;p.input=Vector(1,0);tick(p);p.input=Vector(0,0)
p:TakeDamage(.5,DamageFlag.DAMAGE_CURSED_DOOR,{},0)
assert(p:GetData().hunterItems163.cursedPending168.throughDoor)
roomIndex=roomIndex+1;call(19);assert(p:GetData().hunterItems163.cursedPending168)
fixtureRoomFrame=0;tick(p);assert(not p.teleports)
fixtureRoomFrame=2;tick(p);assert(p.teleports==1);fixtureRoomFrame=nil
assert(p.broken==0)
end
-- Technology's native damage can use Source=player and a cached amount that
-- ignores CollisionDamage. Override to400% sheet, not four times that amount.
do
local p=player({[68]=1,[373]=1});p.input=Vector(1,0);tick(p);p.input=Vector(0,0)
local l=latest(7,p);assert(l:GetData().tech168)
local npc=entity(10);npc.HitPoints=1000;l.CollisionDamage=.1
call(1248,l,npc);npc:TakeDamage(.7,0,EntityRef(p),0);call(1249,l,npc)
approx(npc.HitPoints,1000-16.8)
local seen={};local dummy=entity(10);dummy.HitPoints=1000
mod:AddCallback(11,function(_,e,n)if e==dummy then seen[#seen+1]=n;return false end end)
call(1248,l,dummy);dummy:TakeDamage(.7,0,EntityRef(p),0);call(1249,l,dummy)
assert(#seen==1);approx(seen[1],16.8);approx(dummy.HitPoints,1000)
local extra=call(11,npc,.7,0,EntityRef(p),0,EntityRef(l));approx(extra.Damage,16.8)
assert(p.charges==1,'The native laser hit group grants Dead Eye once')
local count=#entities;for i=1,12 do tick(p)end;assert(#entities==count)
local p=player({[68]=1,[69]=1});p.input=Vector(1,0);tick(p)
local l=latest(7,p);approx(l:GetData().techDamage168,16.8*R.chocolate(.48,1))
local p=player({[68]=1,[395]=1});p.input=Vector(1,0);tick(p);local ring=latest(7,p)
assert(not ring:GetData().tech168);approx(ring.CollisionDamage,4.2)
local p=player({[68]=1,[118]=1});p.input=Vector(1,0);tick(p);local brim=latest(7,p)
assert(not brim:GetData().tech168);approx(brim.CollisionDamage,2.1)
end
print('v168 contracts PASS: native charged-weapon release/captured spin only, scoped input and chamber preservation, accepted-damage random teleport, native light8x, Technology actual400% damage and unrelated beam isolation')

-- Do not clear a genuine armed charge at the POST_PLAYER boundary. Keep it
-- into the cached-release frame; suppress only the ordinary priming attack.
do
local p=player({[579]=1});p.input=Vector(1,0);tick(p)
local q=C._testing.sword.pending[p.InitSeed];assert(q and q.stage=='arm')
tick(p);q=C._testing.sword.pending[p.InitSeed]
assert(q and q.stage=='release'and p:GetWeapon(1):GetCharge()>=30)
local main=p.nativeMainSword;assert(main and main:GetData().nativeSwordPriming169 and not main.Visible)
local npc=entity(10);npc.HitPoints=1000
npc:TakeDamage(16.1,0,EntityRef(main),0);approx(npc.HitPoints,1000)
local child=entity(8,10,p);child.SubType=4;child.Parent=main;call(45,child)
npc:TakeDamage(16.1,0,EntityRef(child),0);approx(npc.HitPoints,1000)
tick(p);assert(p.nativeSpinCount==1 and main:GetData().nativeSword166 and main.Visible and main.EntityCollisionClass==4)
assert(not main:GetData().nativeSwordPriming169 and not main:GetData().blockedSwing163)
npc:TakeDamage(main.CollisionDamage,0,EntityRef(main),0);approx(npc.HitPoints,1000-(8*4.2+10))
assert(call(13,p,2,5)==nil and call(13,p,1,5)==nil)
assert(p:GetWeapon(1):GetCharge()==0 and p.FireDelay==1000000)
local text=p:GetData().hunterNativeSword166
assert(text:find('native spin observed')and text:find('arm_calls=1')and text:find('release_calls=1'))
end
print('v169 lifecycle contract PASS: pre-cached input, late weapon tick, charge preserved through arm, native reused sword Spin detection, priming damage suppressed, chamber/input/gate restored, light4x; other v168 mechanics retained')

-- New Ipecac formulas use the already-corrected sheet once, including the
-- combined explosion immunity; Dr Fetus alone retains the prior formulas.
for _,ids in ipairs({{[149]=1},{[149]=1,[52]=1}})do
 local p=player(ids);p.Damage=7.25;p.input=Vector(1,0);tick(p);p.input=Vector(0,0)
 local t=latest(2,p);approx(t.CollisionDamage,54.5);approx(t:GetData().explosionDamage163,54.5)
 local npc=entity(10);npc.HitPoints=1000;call(42,t,npc);call(1)
 approx(bombs[#bombs].damage,54.5)
end
local p=player({[52]=1});p.Damage=7.25;p.input=Vector(1,0);tick(p)
local t=latest(2,p);approx(t.CollisionDamage,29);approx(t:GetData().explosionDamage163,44.5)
-- Polyphemus uses real PIERCING, with no remaining-damage PERSISTENT flag.
local p=player({[169]=1});p.nativeFlags=TearFlags.TEAR_PERSISTENT
local t=nativeShot(p);assert(t:HasTearFlags(TearFlags.TEAR_PIERCING)and not t:HasTearFlags(TearFlags.TEAR_PERSISTENT))
local child=p:FireTear(t.Position,Vector(3,0),false,false,false,t,.5)
assert(child:HasTearFlags(TearFlags.TEAR_PIERCING)and not child:HasTearFlags(TearFlags.TEAR_PERSISTENT))
t:AddTearFlags(TearFlags.TEAR_PERSISTENT);call(40,t)
assert(not t:HasTearFlags(TearFlags.TEAR_PERSISTENT))
local p=player({[169]=1,[149]=1});p.input=Vector(1,0);tick(p);local t=latest(2,p)
local npc=entity(10);npc.HitPoints=1000;call(42,t,npc);call(40,t)
assert(not t.removed and not t:GetData().removeAfterHit163,'True piercing explosion knives must continue after an enemy')
print('v170 combat PASS: prior v169 mechanics plus Ipecac/combined2D+40, standalone Dr Fetus unchanged, real Polyphemus piercing and descendant/update flags')
