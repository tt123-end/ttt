from pathlib import Path
import shutil,xml.etree.ElementTree as E
T=Path('/workspace/hunter-fix-tools');O=Path('/workspace/deliverables171/zzzz_revolver_samson');D=Path('/workspace/deliverables172');P=D/'zzzz_revolver_samson'
D.mkdir(exist_ok=True)
if not P.exists():shutil.copytree(O,P)
s=(O/'tainted_hunter_balance.lua').read_text()
s=s.replace('    B.ids={2,153,152,169,229,310,118,52,149,531,245,556}', '''    B.ids={2,153,152,169,229,310,118,52,149,531,245,556}
    -- Native negative tears use an additional -6*ups branch. Use that same
    -- piecewise delay for baseline inversion and cap accounting.
    local function basicDelay(ups)
        if ups<-.77 then return 16-6*ups end
        local delay=16-6*math.sqrt(math.max(0,1+1.3*ups))
        if ups<0 then delay=delay-6*ups end
        return delay
    end
    local lo,hi=-10,10
    local targetDelay=30/2.4-1
    for _=1,64 do
        local mid=(lo+hi)/2
        if basicDelay(mid)>targetDelay then lo=mid else hi=mid end
    end
    local baseTearsUp=(lo+hi)/2
    -- These weapon-type bits survive BlockCollectible and retain their own
    -- native delay penalties. Mask only their numerical evaluation; restore
    -- the exact flags before returning, without replacing any Weapon object.
    local statWeapons={
        {id=229,kind=WeaponType.WEAPON_MONSTROS_LUNGS},
        {id=118,kind=WeaponType.WEAPON_BRIMSTONE},
        {id=52,kind=WeaponType.WEAPON_BOMBS},
    }''')
s=s.replace('local effectEdits={};local field=fields[flag]','local effectEdits={};local weaponEdits={};local field=fields[flag]')
needle='''            for _,edit in ipairs(edits)do blocked[#blocked+1]=edit.id;p:BlockCollectible(edit.id)end
            p:AddCacheFlags(flag);p:EvaluateItems()'''
replacement='''            for _,edit in ipairs(edits)do blocked[#blocked+1]=edit.id;p:BlockCollectible(edit.id)end
            if flag==CacheFlag.CACHE_FIREDELAY then
                for _,entry in ipairs(statWeapons)do
                    if (counts[entry.id]or 0)>0 and p:HasWeaponType(entry.kind)then
                        weaponEdits[#weaponEdits+1]=entry.kind
                        p:EnableWeaponType(entry.kind,false)
                    end
                end
            end
            p:AddCacheFlags(flag);p:EvaluateItems()'''
assert s.count(needle)==1;s=s.replace(needle,replacement)
needle='''        local cleanupError
        for i=#blocked,1,-1 do'''
replacement='''        local cleanupError
        for i=#weaponEdits,1,-1 do
            local clean,err=pcall(p.EnableWeaponType,p,weaponEdits[i],true)
            if not clean then clean,err=pcall(p.EnableWeaponType,p,weaponEdits[i],true)end
            if not clean then cleanupError=err end
        end
        for i=#blocked,1,-1 do'''
assert s.count(needle)==1;s=s.replace(needle,replacement)
needle='''                local delay=30/2.4-1
                local offset=(((16-delay)/6)^2-1)/1.3
                d.tearsUp=value+offset'''
assert s.count(needle)==1;s=s.replace(needle,'''                d.tearsUp=value+baseTearsUp''')
needle='16-6*math.sqrt(math.max(0,1+1.3*d.tearsUp))'
assert s.count(needle)==1;s=s.replace(needle,'basicDelay(d.tearsUp)')
s=s.replace('[Hunter v1.71 balance]','[Hunter v1.72 balance]')
(P/'tainted_hunter_balance.lua').write_text(s);(T/'tainted_hunter_balance172.lua').write_text(s)
for name in ['main.lua','tainted_hunter_compat.lua']:
 s=(O/name).read_text().replace('v1.71','v1.72');(P/name).write_text(s)
s=(O/'tainted_hunter_rules.lua').read_text().replace('version=171','version=172');(P/'tainted_hunter_rules.lua').write_text(s)
t=E.parse(O/'metadata.xml');t.getroot().find('version').text='1.72';t.getroot().find('description').text='v1.72: Fix negative tears baseline/cap math and suppress Monstro Lung, Brimstone and Dr Fetus cached weapon-type delay penalties during numeric evaluation. Existing damage, attacks and UI retained.';t.write(P/'metadata.xml',encoding='utf-8',xml_declaration=True)
readme=(O/'README.md').read_text().replace('v1.71','v1.72')
start=readme.index('本版修复');end=readme.index('\n\n基于已确认',start)
readme=readme[:start]+'''本版修复初始射速/上限偏低，以及萌死戳的肺、硫磺火、胎儿博士仍施加原生射速惩罚的问题。基础泪属性使用原生的完整分段公式，初始射速为0.48、普通射速上限为1；这三个道具的缓存武器类型只在同步数值重算时屏蔽，结束/异常后恢复，不更换武器对象，也不改变攻击方式、伤害规则和UI。保留v1.71不依赖debug库的修复。\n\n测试加入负泪属性分段、缓存武器惩罚及状态恢复的模型，旧版在两组回归中分别失败，新版通过；本机未运行Isaac游戏。'''+readme[end:]
readme=readme.replace('少数未列出的特殊前置射速公式的上限显示也需实测','少数未列出的特殊前置射速公式的上限显示也需实测')
(P/'README.md').write_text(readme);(D/'README_v172.md').write_text(readme)
print('Built v1.72: complete negative tears formula + scoped cached weapon flag mask')
