function EID:CreateDescriptionTableIfMissing(tableName, language)
	if language and not EID.descriptions[language] then
		EID.descriptions[language] = {}
	end
	if tableName and not EID.descriptions[language][tableName] then
		EID.descriptions[language][tableName] = {}
	end
end

function EID:addCharacterInfo(characterId, description, playerName, language)
	playerName = playerName or "Modded Character"
	language = language or EID.DefaultLanguageCode
	if characterId == -1 then
		EID:WriteErrorMsg("Trying to add character description to id = -1, which is not allowed! (Name: "..tostring(playerName).."; Description: "..tostring(description)..")")
		return
	end
	EID:CreateDescriptionTableIfMissing("CharacterInfo", language)
	EID.descriptions[language].CharacterInfo[characterId] = {playerName, description}
end

function EID:getDescriptionEntry(objTable, objIdentifier, noFallback)
	if not objIdentifier then
		if noFallback then return EID.descriptions[EID:getLanguage()][objTable]
		else return EID.descriptions[EID:getLanguage()][objTable] or EID.descriptions[EID.DefaultLanguageCode][objTable] end
	else
		local translatedTable = EID.descriptions[EID:getLanguage()][objTable]
		local description
		if noFallback then description = translatedTable and translatedTable[objIdentifier]
		else description = (translatedTable and translatedTable[objIdentifier]) or (EID.descriptions[EID.DefaultLanguageCode][objTable] and EID.descriptions[EID.DefaultLanguageCode][objTable][objIdentifier]) end
		--Try looking for a -1 that would encompass all subtypes of the variant
		-- Safety check for if the identifier contains "."(dot) 1-2 times and only contains numbers
		local strNoDots, numDots = string.gsub(objIdentifier, "%.","")
		if not description and tonumber(strNoDots) and (numDots == 1 or numDots == 2) then
			local subtype
			for i = string.len(objIdentifier), 1, -1 do
				if string.sub(objIdentifier, i, i) == "." then
					subtype = string.sub(objIdentifier, i + 1, -1)
					objIdentifier = string.gsub(objIdentifier, "." .. subtype, "") .. ".-1"
					if subtype ~= "-1" then
						return EID:getDescriptionEntry(objTable, objIdentifier, noFallback)
					end
					break
				end
			end
		end
		return description
	end
end

function EID:getPlayerName(id, altFallback)
	local playerInfo = EID:getDescriptionEntry("CharacterInfo")[id]
	local birthrightInfo = EID.isRepentance and EID:getDescriptionEntry("birthright")[id+1]
	return (playerInfo and playerInfo[1]) or (birthrightInfo and birthrightInfo[1]) or altFallback or EID:findPlayerName(id) or "???"
end

function EID:getLanguage()
	local lang = EID.Config["Language"]
	-- Reset invalid languages (like en_us_detailed)
	if EID.descriptions[lang] == nil then
		EID.Config["Language"] = "auto"
		lang = "auto"
	end
	if lang == "auto" then
		local langToReturn = Options and EID.LanguageMap[Options.Language] or EID.DefaultLanguageCode -- Use game language, if available.
		-- don't do any updating if on a Repentance version before v1.7.9b
		if Isaac.RunCallback ~= nil then
			for _, callbackData in pairs(Isaac.GetCallbacks("EID_EVALUATE_AUTO_LANG")) do
				local newString = callbackData.Function(callbackData.Mod, langToReturn)
				if newString and type(newString) == "string" and EID.descriptions[newString] ~= nil then
					langToReturn = newString
				end
			end
		end
		return langToReturn
	end
	---@cast lang EID_LanguageCode
	return lang
end

function EID:ItemReminderHandleCharacterInfo(player)
	local playerType = player:GetPlayerType()
	local playerDesc = EID:getDescriptionEntry("CharacterInfo")[playerType]
	if playerDesc and playerDesc[2] ~= "" then
		EID:ItemReminderAddTempDescriptionEntry(EID:GetPlayerIcon(playerType), playerDesc[1], playerDesc[2])
	end
end
