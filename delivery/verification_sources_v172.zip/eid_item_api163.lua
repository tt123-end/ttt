function EID:addDescriptionModifier(modifierName, condition, callback, position)
	position = position or #EID.DescModifiers + 1
	for _,v in ipairs(EID.DescModifiers) do
		if v["name"] == modifierName then
			v["condition"] = condition
			v["callback"] = callback
			return
		end
	end
	table.insert(EID.DescModifiers, position, {
		name = modifierName,
		condition = condition,
		callback = callback
	})
end

function EID:addCollectible(id, description, itemName, language)
	itemName = itemName or nil
	language = language or EID.DefaultLanguageCode
	if id == -1 then
		EID:WriteErrorMsg("Trying to add collectible description to id = -1, which is not allowed! (Name: "..tostring(itemName).."; Description: "..tostring(description)..")")
		return
	end
	local modName = EID._currentMod
	-- Glitched Items exception so they don't have a mod name
	if id > 4294960000 then modName = nil end
	local fullID = "5.100." .. id
	if EID.FullyAutomatedDescriptions[fullID] then
		EID.FullyAutomatedDescriptions[fullID] = nil -- remove vanilla item id from the modular desc list, since it got overriden by this function.
	end
	EID:CreateDescriptionTableIfMissing("custom", language)
	EID.descriptions[language].custom[fullID] = {id, itemName, description, modName}
	if itemName then
		EID.ItemNames[language][fullID] = itemName
	end
end