from pathlib import Path
import zipfile,hashlib,json
T=Path('/workspace/hunter-fix-tools');D=Path('/workspace/deliverables172');P=D/'zzzz_revolver_samson'
with zipfile.ZipFile(D/'verification_sources_v172.zip','w',zipfile.ZIP_DEFLATED)as out:
 names=['build172.py','verify172.py','package172.py','test_stats172.lua','tainted_hunter_balance172.lua','verify166.py','test_compat170.lua','test_eid170.lua','test_compat_eid170.lua','test_red_damage157.lua','test_bone_containers162_tail.lua','eid_actual_api158.lua','eid_item_api163.lua']
 for n in names:out.write(T/n,n)
 out.writestr('REFERENCE_CONTEXT.txt','Lua/interface regression checks only; no Isaac runtime. v1.71 fails the native negative-tears and cached weapon-delay regressions; v1.72 passes baseline0.48/cap1, all selected weapon combinations, state restoration and the existing compatibility/integration contracts. Tests refer to uploaded Stats+/EID, accepted baseline and official API reference snapshots at workspace paths. Official REPENTOGON API: https://github.com/TeamREPENTOGON/REPENTOGON/tree/1.1.3 .\n')
z=D/'hunter_v172.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as out:
 for p in sorted(P.rglob('*')):
  if p.is_file():out.write(p,p.relative_to(D))
with zipfile.ZipFile(z)as out:
 assert out.testzip()is None
 for p in P.rglob('*'):
  if p.is_file():assert out.read(str(p.relative_to(D)))==p.read_bytes()
 assert not any(any(x in name for x in ['validation_v','修复说明_','geometry_','tears_probe.lua'])for name in out.namelist())
 count=len(out.namelist())
manifest={'version':'1.72','baseline':'v1.71 clean','files':count,'zip_bytes':z.stat().st_size,'zip_crc':'PASS','byte_comparison':'PASS','historical_files_in_mod':False,'lua_files':len(list(P.glob('*.lua'))),'fix':'Complete negative-tears baseline/cap math and selected cached weapon-type delay isolation; damage/attacks/UI unchanged'}
(D/'package_manifest_v172.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
names=['hunter_v172.zip','README_v172.md','validation_v172.json','package_manifest_v172.json','verification_sources_v172.zip']
(D/'SHA256SUMS_v172.txt').write_text(''.join(hashlib.sha256((D/n).read_bytes()).hexdigest()+'  '+n+'\n'for n in names))
print(json.dumps(manifest,ensure_ascii=False,indent=2))
