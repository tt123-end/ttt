-- Container-vs-bone regression scenarios. GetMaxHearts excludes bone capacity.
local function mixed(max,red,bones,soul)
 local p=player(20,red,soul or 0);p.max=max;p.bone=bones
 return p
end
-- Full/half-filled bone hearts without any ordinary containers.
for _,hp in ipairs({1,2,3,4})do
 local p=mixed(0,hp,math.ceil(hp/2));p:TakeDamage(1,0,enemy,0)
 assert(p.red==hp-1 and p.broken==0,'Bone-only red fill must never award broken hearts')
 assert(not p.data.hunterRedDamage157.pending)
end
-- Having ordinary containers does not make bone-fill hits eligible.
local p=mixed(4,6,1);p:TakeDamage(1,0,enemy,0)
assert(p.red==5 and p.broken==0 and not p.data.hunterRedDamage157.pending)
p:TakeDamage(1,0,enemy,0);assert(p.red==4 and p.broken==0)
p.shellFirst=true;p:TakeDamage(1,0,enemy,0)
assert(p.bone==0 and p.red==4 and p.broken==0 and not p.data.hunterRedDamage157.pending)
p.shellFirst=false;p:TakeDamage(1,0,enemy,0)
assert(p.red==3 and p.broken==1 and p.brokenAwards==1,'Container red HP must still count after the bone is gone')
-- Empty bone shells with partially filled ordinary containers.
local p=mixed(6,3,1);p.shellFirst=true;p:TakeDamage(2,0,enemy,0)
assert(p.red==3 and p.broken==0 and not p.data.hunterRedDamage157.pending)
p.shellFirst=false;p:TakeDamage(1,0,enemy,0);assert(p.red==2 and p.broken==1)
-- Reload vulnerability still doubles bone damage, while suppressing its penalty.
local p=mixed(0,2,1);p.busy=true;p:TakeDamage(1,0,enemy,0)
assert(p.red==0 and p.broken==0 and p.bone==1 and #p.applied==1 and p.applied[1].amount==2)
local p=mixed(4,6,1);p.busy=true;p:TakeDamage(1,0,enemy,0)
assert(p.red==4 and p.broken==0 and #p.applied==1)
local p=mixed(4,4,0);p.busy=true;p:TakeDamage(1,0,enemy,0)
assert(p.red==2 and p.broken==1 and p.brokenAwards==1)
-- More than one bone heart; neither a filled bone nor its empty shell counts.
local p=mixed(2,6,2);p:TakeDamage(2,0,enemy,0);assert(p.red==4 and p.broken==0)
p:TakeDamage(2,0,enemy,0);assert(p.red==2 and p.broken==0)
p.shellFirst=true;p:TakeDamage(1,0,enemy,0);p:TakeDamage(1,0,enemy,0)
assert(p.bone==0 and p.red==2 and p.broken==0)
p.shellFirst=false;p:TakeDamage(1,0,enemy,0);assert(p.red==1 and p.broken==1)
-- Only actual ordinary red loss matters even if a native/mod damage path
-- explicitly removes enough red HP to cross the bone/container boundary.
local p=mixed(4,5,1);p:TakeDamage(2,0,enemy,0)
assert(p.red==3 and p.broken==1 and p.brokenAwards==1)
-- A bone hit cannot remain armed and charge a later unrelated health change.
local p=mixed(4,6,1);p:TakeDamage(1,0,enemy,0)
p.red=3;call(4,p);assert(p.broken==0)
-- Deferred bone fill and shell hits are discarded once they settle.
local p=mixed(4,6,1);p.defer=true;p:TakeDamage(1,0,enemy,0)
assert(p.data.hunterRedDamage157.pending)
p:flushDamage();call(4,p)
assert(p.red==5 and p.broken==0 and not p.data.hunterRedDamage157.pending)
p.red=3;call(4,p);assert(p.broken==0)
local p=mixed(4,4,1);p.shellFirst=true;p.defer=true;p:TakeDamage(1,0,enemy,0)
p:flushDamage();call(4,p);assert(p.bone==0 and p.broken==0 and not p.data.hunterRedDamage157.pending)
-- Deferred container damage retains the original one-penalty behavior.
local p=mixed(4,4,0);p.defer=true;p.busy=true;p:TakeDamage(1,0,enemy,0)
p:flushDamage();call(4,p);assert(p.red==2 and p.broken==1 and p.brokenAwards==1)
call(4,p);assert(p.brokenAwards==1)
-- Shield and payment boundaries stay exempt with mixed health.
local p=mixed(4,6,1);p.shield=true;p.shieldReturnsTrue=true;p:TakeDamage(1,0,enemy,0)
p:TakeDamage(4,DamageFlag.DAMAGE_IV_BAG,{},0);call(4,p);assert(p.broken==0)
local p=mixed(4,6,1);p:TakeDamage(3,DamageFlag.DAMAGE_CURSED_DOOR,{},0);assert(p.broken==0)
-- Discard pending events from older code/schema rather than misreading them.
local p=mixed(4,4,0)
p.data.hunterRedDamage157={pending={redHearts=5,maxHearts=4,frame=frame,flags=0,sourceType=10,sourceVariant=0}}
call(4,p);assert(p.broken==0 and not p.data.hunterRedDamage157.pending)
print('v162 bone/container regressions passed: bone-only/partial/multiple/mixed health, shells, deferred attribution, reload x2, genuine container loss, shields/payments, stale events')
