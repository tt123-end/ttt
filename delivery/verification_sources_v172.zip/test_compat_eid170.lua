-- Executes uploaded EID registration functions; engine entities are fixtures.
local callbacks={};ModCallbacks={MC_POST_UPDATE=1}
local mod={AddCallback=function(_,id,fn)callbacks[id]=callbacks[id]or{};table.insert(callbacks[id],fn)end}
EID={DescModifiers={},FullyAutomatedDescriptions={},ItemNames={zh_cn={},en_us={}},descriptions={zh_cn={},en_us={}},DefaultLanguageCode='en_us',Config={Language='zh_cn'}}
assert(loadfile(ACTUAL_API))();assert(loadfile(ACTUAL_ITEM_API))()
Isaac={GetItemIdByName=function(name)return name=="Hunter Chocolate Milk"and 9002 or 9001 end}
local p={kind=20,items={}}
function p:GetPlayerType()return self.kind end
function p:HasCollectible(id)return self.items[id]or false end
EID.player=p
assert(loadfile(MOD_ROOT..'/tainted_hunter_compat_eid.lua'))()(mod,20)
assert(#EID.DescModifiers==1)
local modifier=EID.DescModifiers[1]
for _,id in ipairs({52,69,114,118,168,229,316,395,556,579,678,352,149,533,104,150,154,237,331,398,429,443,503,637,619})do
 local desc={ObjType=5,ObjVariant=100,ObjSubType=id,Description='native'}
 assert(modifier.condition(desc));assert(modifier.callback(desc).Description~='native')
end
local desc={ObjType=5,ObjVariant=100,ObjSubType=619}
assert(modifier.callback(desc).Description:find('20%%'))
p.items[52]=true;p.items[149]=true;desc.ObjSubType=52
assert(modifier.callback(desc).Description:find('2×面板%+40')and modifier.callback(desc).Description:find('取消吐根%+40面板与博士×0.8降伤'))
EID.Config.Language='en_us';assert(modifier.callback(desc).Description:find('explosion immunity'))
p.kind=10;assert(not modifier.condition(desc));p.kind=20
assert(EID.descriptions.zh_cn.custom['5.100.9001'][3]:find('1.5',1,true))
for i=1,5 do for _,fn in ipairs(callbacks[1])do fn(mod)end end
assert(#EID.DescModifiers==1)
print('Uploaded EID item API passed:25 localized overrides, character isolation, combo wording, replacement token and idempotent install')

assert(EID.descriptions.zh_cn.custom['5.100.9002'][3]:find('完全移除'))
assert(EID.descriptions.en_us.custom['5.100.9002'][3]:find('removes native charge/tap fire'))

EID.Config.Language='zh_cn';p.kind=20;p.items={}
local function text(id)return modifier.callback({ObjType=5,ObjVariant=100,ObjSubType=id}).Description end
for _,id in ipairs({2,153,152,169,229,310,118,52,149,531,245})do assert(modifier.condition({ObjType=5,ObjVariant=100,ObjSubType=id}))end
assert(text(2):find('×0.5')and text(153):find('×0.42')and text(229):find('×0.23'))
assert(text(2):find('最低倍率')and text(2):find('完美视力'))
assert(text(152):find('×0.75')and text(310):find('×1.35')and text(310):find('弹速上限2'))
assert(text(169):find('%+8')and text(169):find('真正穿透'))
assert(text(149):find('2×面板%+40')and text(531):find('%+3'))
assert(text(245):find('0.8倍降伤'))
print('v170 actual EID item API PASS: all requested numbers, minimum group/20-20 exceptions, Dr+Ipecac immunity/formula, true piercing and no old cap traits')
