-- Optional integration with the public API of the user's Stats+ v2.1.2 archive.
-- No Stats+ files/settings are overwritten; absent Stats+ leaves this dormant.
return function(mod, playerType, stats)
    local function isHunter(player)
        return player and playerType ~= -1 and player:GetPlayerType() == playerType
    end
    mod:AddCallback("STATS_PLUS_REGISTER", function(_, api)
        local damage = api:middleware({
            id = "tainted-hunter-character-damage",
            name = "Tainted Hunter character damage",
            description = "Includes Tainted Hunter's x1.50 character multiplier in the existing Damage Multiplier provider.",
            target = {
                provider = {addon = "stats-plus-essentials", id = "damage-multiplier-provider"},
                computable = "getCharacterMultiplier"
            },
            priority = 100,
            intercept = function(ctx)
                if isHunter(ctx.args[1]) then
                    return ctx:updateWith(ctx.current * stats.damageMultiplier)
                end
                return ctx:ignore()
            end
        })
        local tears = api:provider({
            id = "tainted-hunter-tears-multiplier",
            name = "Tainted Hunter Tears Multiplier",
            description = "Shows the Tainted Hunter character tears multiplier (x0.25); select this provider for the Tears stat in Stats+ Loadout.",
            targets = {api.stat.tears},
            color = "BLUE",
            state = {multiplier = {initial = function() return 1 end}},
            display = {value = {
                get = function(state) return state.multiplier end,
                format = function(value)
                    if value == 1 then return nil end
                    return string.format("x%.2f", value)
                end
            }},
            mount = function(ctx)
                local function update(_, player)
                    if player and player.Index ~= ctx.player.Index then return end
                    local value = isHunter(ctx.player) and stats.tearsMultiplier or 1
                    if ctx.state.multiplier:current() ~= value then
                        ctx.state.multiplier:set(value)
                    end
                end
                update()
                mod:AddCallback(ModCallbacks.MC_POST_PLAYER_UPDATE, update)
                return function() mod:RemoveCallback(ModCallbacks.MC_POST_PLAYER_UPDATE, update) end
            end
        })
        api:register({
            id = "tainted-hunter-stats",
            name = "Tainted Hunter Stats",
            middleware = {damage},
            providers = {tears}
        })
    end)
end
