-- v1.54: first Tainted Hunter mechanics prototype. All values live here.
-- Starting health/item/card are declared once by the engine in players.xml.
return function(mod, playerType)
    local stats = {
        speed = 1.0,
        baseTears = 2.4,
        tearsMultiplier = 0.25,
        baseDamage = 3.5,
        damageMultiplier = 1.5,
        shotSpeed = 1.6,
        range = 20.0
    }
    local nativeBaseRate = 30 / 11
    local nativeRange = 6.5
    local function isHunter(player)
        return playerType ~= -1 and player:GetPlayerType() == playerType
    end
    local function evaluate(_, player, flag)
        if not isHunter(player) then return end
        -- Each cache pass starts from recalculated engine values. Preserve item
        -- bonuses; never assign baseline stats on every player update.
        if flag == CacheFlag.CACHE_SPEED then
            player.MoveSpeed = player.MoveSpeed + (stats.speed - 1.0)
        elseif flag == CacheFlag.CACHE_FIREDELAY then
            local nativeRate = 30 / math.max(0.01, player.MaxFireDelay + 1)
            -- Normalize Isaac's native starting rate to 2.4 first, then apply
            -- the explicit x0.25 character multiplier. Relative tears bonuses,
            -- other tears multipliers and cap-breaking increases remain intact.
            local rate = nativeRate * (stats.baseTears / nativeBaseRate) * stats.tearsMultiplier
            player.MaxFireDelay = 30 / math.max(0.001, rate) - 1
        elseif flag == CacheFlag.CACHE_DAMAGE then
            player.Damage = (player.Damage + (stats.baseDamage - 3.5)) * stats.damageMultiplier
        elseif flag == CacheFlag.CACHE_SHOTSPEED then
            player.ShotSpeed = player.ShotSpeed + (stats.shotSpeed - 1.0)
        elseif flag == CacheFlag.CACHE_RANGE then
            -- Both the vanilla stat HUD and the uploaded Stats+ display /40.
            player.TearRange = player.TearRange + (stats.range - nativeRange) * 40
        end
    end
    mod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, evaluate)
    local flags = CacheFlag.CACHE_SPEED | CacheFlag.CACHE_FIREDELAY
        | CacheFlag.CACHE_DAMAGE | CacheFlag.CACHE_SHOTSPEED | CacheFlag.CACHE_RANGE
    local function refresh(player)
        if not isHunter(player) then return end
        player:AddCacheFlags(flags)
        player:EvaluateItems()
    end
    mod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, function(_, player)
        refresh(player)
    end)
    -- Recalculate stats when continuing an older save, without changing its
    -- health, possessions, or held card. No loadout-grant calls are used here.
    mod:AddCallback(ModCallbacks.MC_POST_GAME_STARTED, function()
        local game = Game()
        for i=0,game:GetNumPlayers()-1 do refresh(Isaac.GetPlayer(i)) end
    end)
    return stats
end
